"""SQLite persistence: indexing, conflicts, append-only events, read-only queries (SPEC Â§18)."""

from __future__ import annotations

import difflib
import hashlib
import os
import re
import sqlite3
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Any, Iterable, Iterator, Optional, Sequence

from somnus import DB_USER_VERSION, carriers, ids, yamlsub
from somnus.document import Document, canonical_yaml, load
from somnus.model.lifecycle import now_utc
from somnus.model.validate import ArtifactFacts, Resolver, validate
from somnus.output import Diagnostic, SomnusError, EXIT_USAGE

MAX_EMBEDDED_BYTES = 8 * 1024 * 1024


# --------------------------------------------------------------------------- glob helpers


def glob_regex(pattern: str) -> re.Pattern:
    """Compile a ``**``-aware glob over POSIX relative paths."""
    out = ""
    i = 0
    while i < len(pattern):
        if pattern.startswith("**/", i):
            out += "(?:.*/)?"
            i += 3
        elif pattern.startswith("/**", i) and i + 3 == len(pattern):
            out += "(?:/.*)?"
            i += 3
        elif pattern.startswith("**", i):
            out += ".*"
            i += 2
        elif pattern[i] == "*":
            out += "[^/]*"
            i += 1
        elif pattern[i] == "?":
            out += "[^/]"
            i += 1
        else:
            out += re.escape(pattern[i])
            i += 1
    return re.compile(out + r"\Z")


def excluded(rel: str, patterns: Sequence[re.Pattern]) -> bool:
    """True when ``rel`` (or one of its parent directories) matches a pattern."""
    parts = rel.split("/")
    for n in range(1, len(parts) + 1):
        prefix = "/".join(parts[:n])
        for p in patterns:
            if p.match(prefix) or p.match(prefix + "/"):
                return True
    return False


def normalize_title(title: str) -> str:
    """Casefolded, accent-stripped, punctuation-free title for similarity checks."""
    text = unicodedata.normalize("NFKD", title).casefold()
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def title_similarity(a: str, b: str) -> float:
    """Similarity ratio in [0, 1] between two normalized titles."""
    return difflib.SequenceMatcher(None, normalize_title(a), normalize_title(b)).ratio()


# --------------------------------------------------------------------------- results


@dataclass
class IndexOutcome:
    """What happened to one file during indexing."""

    status: str  # added | updated | unchanged | conflict | skipped | invalid
    path: str
    artifact_id: Optional[str] = None
    revision: Optional[int] = None
    message: str = ""


@dataclass
class ScanReport:
    """Summary of a root scan."""

    root: str
    outcomes: list = field(default_factory=list)
    diagnostics: list = field(default_factory=list)
    missing: list = field(default_factory=list)
    unmanaged: int = 0

    def count(self, status: str) -> int:
        """Number of outcomes with ``status``."""
        return sum(1 for o in self.outcomes if o.status == status)


# --------------------------------------------------------------------------- store


class Store:
    """Read-write access to the registry; every mutation appends an event."""

    def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
        self.conn = conn
        self.path = path
        self.actor = actor

    # ----------------------------------------------------------- lifecycle
    @classmethod
    def open(cls, path: Path, actor: str = "operator") -> "Store":
        """Open (creating and migrating when needed) the registry at ``path``."""
        path = Path(path)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(path), timeout=30)
        except (OSError, sqlite3.Error) as exc:
            raise SomnusError(f"cannot open registry {path}: {exc}", EXIT_USAGE) from exc
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        store = cls(conn, path, actor)
        store._migrate()
        return store

    def _migrate(self) -> None:
        version = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if version == 0:
            ddl = resources.files("somnus.db").joinpath("schema.sql").read_text(encoding="utf-8")
            self.conn.executescript(ddl)
            self.conn.execute("PRAGMA foreign_keys = ON")
            self.log("init", detail=f"registry schema version {DB_USER_VERSION} created")
            self.conn.commit()
        elif version > DB_USER_VERSION:
            raise SomnusError(f"registry {self.path} has schema version {version}; this tool supports "
                              f"{DB_USER_VERSION}", EXIT_USAGE)

    def close(self) -> None:
        """Commit and close the connection."""
        try:
            self.conn.commit()
        finally:
            self.conn.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is not None:
            self.conn.rollback()
        self.close()

    # ----------------------------------------------------------- events
    def log(self, action: str, artifact_id: Optional[str] = None, revision: Optional[int] = None,
            path: Optional[str] = None, detail: Optional[str] = None) -> None:
        """Append one event row."""
        self.conn.execute(
            "INSERT INTO events (at, actor, action, artifact_id, revision, path, detail) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (now_utc(), self.actor, action, artifact_id, revision, path, detail),
        )

    # ----------------------------------------------------------- roots
    def add_root(self, path: Path, label: Optional[str] = None) -> int:
        """Register a root (idempotent) and return its id."""
        key = _root_key(path)
        row = self.conn.execute("SELECT root_id FROM roots WHERE path = ?", (key,)).fetchone()
        if row:
            return int(row[0])
        cur = self.conn.execute("INSERT INTO roots (path, label, added_at) VALUES (?, ?, ?)",
                                (key, label, now_utc()))
        self.log("root-add", path=key, detail=label)
        self.conn.commit()
        return int(cur.lastrowid)

    def roots(self) -> list[tuple[int, Path]]:
        """Registered roots, deepest paths first."""
        rows = self.conn.execute("SELECT root_id, path FROM roots").fetchall()
        return sorted(((int(r[0]), Path(r[1])) for r in rows), key=lambda t: -len(str(t[1])))

    def locate(self, path: Path) -> Optional[tuple[int, str, Path]]:
        """Return (root_id, rel_path, root) for the deepest registered root containing ``path``."""
        target = Path(path).resolve()
        for root_id, root in self.roots():
            try:
                rel = target.relative_to(root)
            except ValueError:
                continue
            return root_id, rel.as_posix(), root
        return None

    def ensure_root_for(self, path: Path) -> tuple[int, str, Path]:
        """Locate ``path`` under a registered root, registering its directory when none contains it."""
        found = self.locate(path)
        if found:
            return found
        directory = Path(path).resolve().parent
        root_id = self.add_root(directory)
        return root_id, Path(path).resolve().relative_to(directory).as_posix(), directory

    # ----------------------------------------------------------- indexing
    def index_document(self, doc: Document, root_id: int, rel_path: str, *, full: bool = False,
                       diagnostics: Optional[list] = None) -> IndexOutcome:
        """Reconcile one loaded document into the registry."""
        display = doc.display
        mtime, size = _stat(doc)
        if not full:
            row = self.conn.execute(
                "SELECT file_mtime, file_size, present, artifact_id FROM locations WHERE root_id = ? AND rel_path = ?",
                (root_id, rel_path)).fetchone()
            if row and row["file_mtime"] == mtime and row["file_size"] == size and row["present"] == 1:
                return IndexOutcome("unchanged", display, row["artifact_id"])
        diags = validate(doc, "core")
        errors = [d for d in diags if d.is_error]
        if diagnostics is not None:
            diagnostics.extend(diags)
        if errors:
            return IndexOutcome("invalid", display, message=f"{len(errors)} core error(s); not indexed")
        somnus = doc.payload
        assert somnus is not None
        aid, rev = somnus["id"], somnus["revision"]
        if ids.is_example_urn(aid):
            return IndexOutcome("skipped", display, aid, rev, "example identities are never indexed")
        now = now_utc()
        header = canonical_yaml({"somnus": somnus})
        payload_digest = hashlib.sha256(header.encode("utf-8")).hexdigest()
        body_digest = doc.body_digest()
        content_digest = hashlib.sha256(f"{payload_digest}:{body_digest}".encode()).hexdigest()
        carrier = doc.carrier.name
        with self.conn:
            prior = self.conn.execute("SELECT artifact_id FROM locations WHERE root_id = ? AND rel_path = ?",
                                      (root_id, rel_path)).fetchone()
            existing = self.conn.execute(
                "SELECT payload_digest, body_digest FROM revisions WHERE artifact_id = ? AND revision = ?",
                (aid, rev)).fetchone()
            status = "added"
            if existing is not None:
                if existing["payload_digest"] == payload_digest and existing["body_digest"] == body_digest:
                    status = "unchanged"
                else:
                    status = "conflict"
            artifact_row = self.conn.execute("SELECT current_revision FROM artifacts WHERE artifact_id = ?",
                                             (aid,)).fetchone()
            if status == "added" and artifact_row is not None:
                status = "updated"
            if status in ("added", "updated"):
                self._upsert_artifact(somnus, now, artifact_row)
                self.conn.execute(
                    "INSERT INTO revisions (artifact_id, revision, schema_uri, header_yaml, payload_digest, body_digest,"
                    " observed_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (aid, rev, somnus["schema"], header, payload_digest, body_digest, now))
                self._knowledge(doc, somnus)
            elif artifact_row is not None:
                self.conn.execute("UPDATE artifacts SET last_seen_at = ? WHERE artifact_id = ?", (now, aid))
            if status == "conflict":
                if artifact_row is None:
                    self._upsert_artifact(somnus, now, None)
                detail = (f"{rel_path}: revision {rev} differs from the stored state "
                          f"(payload {payload_digest[:12]} vs {existing['payload_digest'][:12]}, "
                          f"body {body_digest[:12]} vs {existing['body_digest'][:12]}). "
                          f"Candidate header:\n{header}")
                self.open_conflict("revision", aid, detail, key=f"{rel_path}:{rev}:{payload_digest}:{body_digest}")
            self.conn.execute(
                "INSERT INTO locations (root_id, rel_path, artifact_id, carrier, file_mtime, file_size, content_digest,"
                " observed_at, present) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)"
                " ON CONFLICT(root_id, rel_path) DO UPDATE SET artifact_id = excluded.artifact_id,"
                " carrier = excluded.carrier, file_mtime = excluded.file_mtime, file_size = excluded.file_size,"
                " content_digest = excluded.content_digest, observed_at = excluded.observed_at, present = 1",
                (root_id, rel_path, aid, carrier, mtime, size, content_digest, now))
            if prior is not None and prior["artifact_id"] != aid:
                self.open_conflict("identity", aid,
                                   f"{rel_path} previously held {prior['artifact_id']} and now holds {aid}",
                                   key=f"{rel_path}:{prior['artifact_id']}->{aid}")
                self.log("index-identity", aid, rev, rel_path, f"previous {prior['artifact_id']}")
            self._duplicates(aid)
            action = {"added": "index-add", "updated": "index-update", "conflict": "index-conflict",
                      "unchanged": "index-observe"}[status]
            if status != "unchanged" or prior is None:
                self.log(action, aid, rev, rel_path)
        return IndexOutcome(status, display, aid, rev)

    def _upsert_artifact(self, somnus: dict, now: str, row: Optional[sqlite3.Row]) -> None:
        aid, rev = somnus["id"], somnus["revision"]
        if row is not None and row["current_revision"] > rev:
            self.conn.execute("UPDATE artifacts SET last_seen_at = ? WHERE artifact_id = ?", (now, aid))
            return
        c = somnus["classification"]
        values = (somnus["title"], c["category"], c["type"], c["role"], c["scope"], somnus["lifecycle"]["status"],
                  somnus["authority"]["standing"], somnus["access"]["visibility"], somnus["ingestion"]["disposition"],
                  rev)
        if row is None:
            self.conn.execute(
                "INSERT INTO artifacts (title, category, type, role, scope, status, standing, visibility, disposition,"
                " current_revision, artifact_id, first_seen_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                values + (aid, now, now))
        else:
            self.conn.execute(
                "UPDATE artifacts SET title = ?, category = ?, type = ?, role = ?, scope = ?, status = ?, standing = ?,"
                " visibility = ?, disposition = ?, current_revision = ?, last_seen_at = ? WHERE artifact_id = ?",
                values + (now, aid))
        self.conn.execute("DELETE FROM tags WHERE artifact_id = ?", (aid,))
        self.conn.executemany("INSERT OR IGNORE INTO tags (artifact_id, tag) VALUES (?, ?)",
                              [(aid, t) for t in c.get("tags", [])])

    def _knowledge(self, doc: Document, somnus: dict) -> None:
        from somnus.regions import scan_markers

        aid, rev = somnus["id"], somnus["revision"]
        knowledge = somnus.get("knowledge", {})
        ranges: dict = {}
        style = getattr(doc.carrier, "region_style", ())
        if style:
            ranges = scan_markers(doc.lines, style, doc.ignore_span, getattr(doc.carrier, "host", None)).ranges
        for reg in knowledge.get("regions", []):
            sel = reg.get("selector", {})
            line_from = line_until = None
            if sel.get("kind") == "marker" and sel.get("name") in ranges:
                rng = ranges[sel["name"]]
                line_from, line_until = rng.begin_line, rng.end_line
            elif sel.get("kind") == "line-range":
                line_from, line_until = sel.get("from"), sel.get("until")
            self.conn.execute(
                "INSERT INTO regions (artifact_id, revision, region_id, kind, title, line_from, line_until)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)", (aid, rev, reg["id"], reg["kind"], reg.get("title"), line_from, line_until))
        for rel in knowledge.get("relations", []):
            self.conn.execute(
                "INSERT INTO relations (artifact_id, revision, relation_id, subject_ref, predicate, object_ref, assessment)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (aid, rev, rel["id"], rel["subject"]["ref"], rel["predicate"], rel["object"]["ref"], rel["assessment"]))
        for claim in knowledge.get("claims", []):
            self.conn.execute(
                "INSERT INTO claims (artifact_id, revision, claim_id, subject_ref, predicate, statement, kind, assessment,"
                " region_ref) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (aid, rev, claim["id"], claim["subject_ref"], claim["predicate"], claim["statement"], claim["kind"],
                 claim["assessment"], claim.get("region_ref")))
        for ent in knowledge.get("entities", []):
            if ids.is_example_urn(ent["ref"]):
                continue
            self.conn.execute(
                "INSERT OR IGNORE INTO entities (entity_ref, label, kind, source_artifact, source_revision)"
                " VALUES (?, ?, ?, ?, ?)", (ent["ref"], ent["label"], ent["kind"], aid, rev))

    # ----------------------------------------------------------- conflicts
    def open_conflict(self, kind: str, artifact_id: str, detail: str, key: Optional[str] = None) -> bool:
        """Open a conflict unless an identical one is already open; return True when new."""
        marker = f"[{key}]" if key else None
        rows = self.conn.execute("SELECT detail FROM conflicts WHERE kind = ? AND artifact_id = ? AND resolved_at IS NULL",
                                 (kind, artifact_id)).fetchall()
        for row in rows:
            if (marker and row[0].startswith(marker)) or (not marker and row[0] == detail):
                return False
        text = f"{marker} {detail}" if marker else detail
        self.conn.execute("INSERT INTO conflicts (kind, artifact_id, detail, opened_at) VALUES (?, ?, ?, ?)",
                          (kind, artifact_id, text, now_utc()))
        self.log("conflict-open", artifact_id, detail=f"{kind}: {detail.splitlines()[0]}")
        return True

    def resolve_conflicts(self, artifact_id: str, kind: str, resolution: str) -> int:
        """Resolve all open conflicts of ``kind`` for an artifact; return how many."""
        cur = self.conn.execute(
            "UPDATE conflicts SET resolved_at = ?, resolution = ? WHERE artifact_id = ? AND kind = ? AND resolved_at IS NULL",
            (now_utc(), resolution, artifact_id, kind))
        if cur.rowcount:
            self.log("conflict-resolve", artifact_id, detail=f"{kind}: {resolution} ({cur.rowcount})")
        return cur.rowcount

    def _duplicates(self, aid: str) -> None:
        rows = self.conn.execute(
            "SELECT r.path || '/' || l.rel_path AS p, l.content_digest FROM locations l JOIN roots r USING (root_id)"
            " WHERE l.artifact_id = ? AND l.present = 1", (aid,)).fetchall()
        digests = {row[1] for row in rows}
        if len(digests) > 1:
            paths = ", ".join(sorted(row[0] for row in rows))
            self.open_conflict("duplicate-id", aid, f"{aid} is present with different content at: {paths}",
                               key="present")
        else:
            self.resolve_conflicts(aid, "duplicate-id", "only one distinct state remains present")

    def authority_conflicts(self) -> int:
        """Recompute overlapping accepted authorities; open/resolve conflicts; return open count."""
        rows = self.conn.execute(
            "SELECT a.artifact_id, v.header_yaml FROM artifacts a JOIN revisions v"
            " ON v.artifact_id = a.artifact_id AND v.revision = a.current_revision WHERE a.standing = 'accepted'").fetchall()
        claims: list[tuple[str, str, str, tuple]] = []
        for aid, header in rows:
            try:
                somnus = yamlsub.loads(header)["somnus"]
            except (yamlsub.YAMLError, KeyError, TypeError):
                continue
            auth = somnus.get("authority", {})
            interval = _interval(auth.get("valid_time", {}))
            for scope in auth.get("scopes", []):
                for aspect in scope.get("aspects", []):
                    claims.append((aid, scope.get("target_ref", ""), aspect, interval))
        overlapping: dict[str, set[str]] = {}
        for i, (a1, t1, s1, iv1) in enumerate(claims):
            for a2, t2, s2, iv2 in claims[i + 1 :]:
                if a1 != a2 and t1 == t2 and s1 == s2 and _overlaps(iv1, iv2):
                    overlapping.setdefault(a1, set()).add(f"{a2} over {t1} [{s1}]")
                    overlapping.setdefault(a2, set()).add(f"{a1} over {t1} [{s1}]")
        for aid, others in overlapping.items():
            self.open_conflict("authority", aid, "overlapping accepted authority with " + "; ".join(sorted(others)),
                               key="overlap:" + ",".join(sorted(others)))
        open_rows = self.conn.execute(
            "SELECT DISTINCT artifact_id FROM conflicts WHERE kind = 'authority' AND resolved_at IS NULL").fetchall()
        for (aid,) in open_rows:
            if aid not in overlapping:
                self.resolve_conflicts(aid, "authority", "no overlapping accepted authority remains")
        self.conn.commit()
        return len(overlapping)

    # ----------------------------------------------------------- scanning
    def scan(self, root: Path, exclude: Sequence[str] = (), *, full: bool = False) -> ScanReport:
        """Index every managed file under ``root``; mark vanished files as not present."""
        root = Path(root).resolve()
        root_id = self.add_root(root)
        report = ScanReport(_root_key(root))
        patterns = [glob_regex(p) for p in exclude]
        seen: set[str] = set()
        for path in _walk(root, patterns):
            rel = path.relative_to(root).as_posix()
            if carriers.is_sidecar_path(path):
                host = carriers.host_for(path)
                if host.exists():
                    continue  # handled with its host
                target, rel = path, rel
            else:
                target = path
            doc = _load_managed(target, report)
            if doc is None:
                continue
            # a host whose metadata lives in a sidecar is tracked under the host's path
            outcome = self.index_document(doc, root_id, rel, full=full, diagnostics=report.diagnostics)
            report.outcomes.append(outcome)
            if outcome.status not in ("invalid", "skipped"):
                seen.add(rel)
        report.missing = self.mark_missing(root_id, seen)
        self.authority_conflicts()
        self.conn.commit()
        return report

    def mark_missing(self, root_id: int, seen: set[str]) -> list[str]:
        """Set ``present = 0`` for locations not observed in this scan (never deletes)."""
        rows = self.conn.execute("SELECT rel_path, artifact_id FROM locations WHERE root_id = ? AND present = 1",
                                 (root_id,)).fetchall()
        missing = []
        for rel, aid in rows:
            if rel not in seen:
                self.conn.execute("UPDATE locations SET present = 0, observed_at = ? WHERE root_id = ? AND rel_path = ?",
                                  (now_utc(), root_id, rel))
                self.log("index-missing", aid, path=rel, detail="file not observed; location marked not present")
                self._duplicates(aid)
                missing.append(rel)
        self.conn.commit()
        return missing

    # ----------------------------------------------------------- reads
    def resolver(self) -> Resolver:
        """Build a validation resolver from registry facts."""
        res = Resolver()
        for row in self.conn.execute("SELECT artifact_id, type, status, standing, current_revision FROM artifacts"):
            res.artifacts[row[0]] = ArtifactFacts(row[0], row[1], row[2], row[3], row[4])
        for aid, rev in self.conn.execute("SELECT artifact_id, revision FROM revisions"):
            if aid in res.artifacts:
                res.artifacts[aid].revisions.add(rev)
                res.artifacts[aid].regions.setdefault(rev, set())
                res.artifacts[aid].claims.setdefault(rev, set())
        for aid, rev, rid in self.conn.execute("SELECT artifact_id, revision, region_id FROM regions"):
            if aid in res.artifacts:
                res.artifacts[aid].regions.setdefault(rev, set()).add(rid)
        for aid, rev, cid in self.conn.execute("SELECT artifact_id, revision, claim_id FROM claims"):
            if aid in res.artifacts:
                res.artifacts[aid].claims.setdefault(rev, set()).add(cid)
        res.entities.update(r[0] for r in self.conn.execute("SELECT DISTINCT entity_ref FROM entities"))
        for aid, kind in self.conn.execute("SELECT artifact_id, kind FROM conflicts WHERE resolved_at IS NULL"):
            res.open_conflicts.setdefault(aid, []).append(kind)
        return res

    def similar_titles(self, title: str, threshold: float = 0.88, exclude_id: Optional[str] = None) -> list[tuple]:
        """Present artifacts whose titles are near-duplicates of ``title``."""
        hits = []
        for row in self.conn.execute("SELECT DISTINCT title, artifact_id, path FROM docs"):
            if row[1] == exclude_id:
                continue
            score = title_similarity(title, row[0])
            if score >= threshold:
                hits.append((round(score, 3), row[0], row[1], row[2]))
        return sorted(hits, reverse=True)

    def current_header(self, artifact_id: str) -> Optional[dict]:
        """Parsed payload of an artifact's current revision."""
        row = self.conn.execute(
            "SELECT v.header_yaml FROM artifacts a JOIN revisions v ON v.artifact_id = a.artifact_id"
            " AND v.revision = a.current_revision WHERE a.artifact_id = ?", (artifact_id,)).fetchone()
        if row is None:
            return None
        return yamlsub.loads(row[0])["somnus"]


# --------------------------------------------------------------------------- read-only access


def connect_readonly(path: Path) -> sqlite3.Connection:
    """Open the registry read-only (``mode=ro`` plus ``query_only``)."""
    path = Path(path)
    if not path.is_file():
        raise SomnusError(f"registry {path} does not exist; run 'somnus init' or 'somnus index'", EXIT_USAGE)
    conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True, timeout=30)
    conn.execute("PRAGMA query_only = ON")
    return conn


def run_query(path: Path, sql: str, params: Sequence[Any] = (), limit: Optional[int] = None) -> tuple[list[str], list[tuple]]:
    """Execute one read-only statement; return (column names, rows)."""
    conn = connect_readonly(path)
    try:
        cur = conn.execute(sql, params)
        headers = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchall() if limit is None else cur.fetchmany(limit)
        return headers, [tuple(r) for r in rows]
    except sqlite3.Error as exc:
        raise SomnusError(f"query failed: {exc}") from exc
    finally:
        conn.close()


# --------------------------------------------------------------------------- internals


def _root_key(path: Path) -> str:
    return Path(path).resolve().as_posix()


def _stat(doc: Document) -> tuple[str, int]:
    paths = [doc.meta_path]
    if doc.is_sidecar and doc.path.exists():
        paths.append(doc.path)
    mtime = max(p.stat().st_mtime_ns for p in paths if p.exists())
    size = sum(p.stat().st_size for p in paths if p.exists())
    stamp = datetime.fromtimestamp(mtime / 1e9, tz=timezone.utc).isoformat(timespec="microseconds")
    return stamp, size


def _walk(root: Path, patterns: Sequence[re.Pattern]) -> Iterator[Path]:
    for directory, dirnames, filenames in os.walk(root):
        base = Path(directory)
        rel_dir = base.relative_to(root).as_posix()
        dirnames[:] = sorted(d for d in dirnames
                             if not excluded((f"{rel_dir}/{d}" if rel_dir != "." else d), patterns))
        for name in sorted(filenames):
            rel = f"{rel_dir}/{name}" if rel_dir != "." else name
            if not excluded(rel, patterns):
                yield base / name


def _load_managed(path: Path, report: ScanReport) -> Optional[Document]:
    """Load a file if it carries metadata; count unmanaged files."""
    try:
        if carriers.for_path(path) is not None and not carriers.sidecar_for(path).exists():
            if path.stat().st_size > MAX_EMBEDDED_BYTES:
                report.unmanaged += 1
                return None
            raw = path.read_bytes()
            if b"somnus" not in raw:
                report.unmanaged += 1
                return None
        elif carriers.for_path(path) is None and not carriers.is_sidecar_path(path) \
                and not carriers.sidecar_for(path).exists():
            report.unmanaged += 1
            return None
        doc = load(path)
    except SomnusError as exc:
        report.diagnostics.extend(exc.diagnostics)
        return None
    except OSError as exc:
        report.diagnostics.append(Diagnostic(str(path), 0, 0, "error", "E_IO", "-", str(exc)))
        return None
    if doc.envelope is None and not doc.issues:
        report.unmanaged += 1
        return None
    return doc


def _interval(vt: dict) -> tuple:
    basis = vt.get("basis") if isinstance(vt, dict) else None
    if basis == "bounded":
        return (_ts(vt.get("from")), _ts(vt.get("until")))
    if basis == "open":
        return (_ts(vt.get("from")), None)
    return (None, None)


def _ts(value: Any) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _overlaps(a: tuple, b: tuple) -> bool:
    """Half-open interval overlap; None bounds are unbounded (unknown is treated conservatively)."""
    a_from, a_until = a
    b_from, b_until = b
    if a_until is not None and b_from is not None and a_until <= b_from:
        return False
    if b_until is not None and a_from is not None and b_until <= a_from:
        return False
    return True

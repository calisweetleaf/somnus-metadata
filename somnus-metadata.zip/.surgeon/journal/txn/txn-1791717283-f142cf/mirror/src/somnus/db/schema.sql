-- Somnus registry schema, user_version 1 (SPEC Â§18). Plain relational tables; no JSON columns.
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE roots (
    root_id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    label TEXT,
    added_at TEXT NOT NULL
);

CREATE TABLE artifacts (
    artifact_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    type TEXT NOT NULL,
    role TEXT NOT NULL,
    scope TEXT NOT NULL,
    status TEXT NOT NULL,
    standing TEXT NOT NULL,
    visibility TEXT NOT NULL,
    disposition TEXT NOT NULL,
    current_revision INTEGER NOT NULL,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL
);

CREATE TABLE revisions (
    artifact_id TEXT REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
    revision INTEGER NOT NULL,
    schema_uri TEXT NOT NULL,
    header_yaml TEXT NOT NULL,
    payload_digest TEXT NOT NULL,
    body_digest TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    PRIMARY KEY (artifact_id, revision)
);

CREATE TABLE locations (
    root_id INTEGER REFERENCES roots(root_id) ON DELETE CASCADE,
    rel_path TEXT NOT NULL,
    artifact_id TEXT NOT NULL REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
    carrier TEXT NOT NULL,
    file_mtime TEXT NOT NULL,
    file_size INTEGER NOT NULL DEFAULT 0,
    content_digest TEXT NOT NULL DEFAULT '',
    observed_at TEXT NOT NULL,
    present INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (root_id, rel_path)
);

CREATE TABLE tags (
    artifact_id TEXT REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY (artifact_id, tag)
);

CREATE TABLE regions (
    artifact_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    region_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    title TEXT,
    line_from INTEGER,
    line_until INTEGER,
    PRIMARY KEY (artifact_id, revision, region_id),
    FOREIGN KEY (artifact_id, revision) REFERENCES revisions(artifact_id, revision) ON DELETE CASCADE
);

CREATE TABLE relations (
    artifact_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    relation_id TEXT NOT NULL,
    subject_ref TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object_ref TEXT NOT NULL,
    assessment TEXT NOT NULL,
    PRIMARY KEY (artifact_id, revision, relation_id),
    FOREIGN KEY (artifact_id, revision) REFERENCES revisions(artifact_id, revision) ON DELETE CASCADE
);

CREATE TABLE entities (
    entity_ref TEXT NOT NULL,
    label TEXT NOT NULL,
    kind TEXT NOT NULL,
    source_artifact TEXT REFERENCES artifacts(artifact_id) ON DELETE CASCADE,
    source_revision INTEGER NOT NULL,
    PRIMARY KEY (entity_ref, source_artifact, source_revision)
);

CREATE TABLE claims (
    artifact_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    claim_id TEXT NOT NULL,
    subject_ref TEXT NOT NULL,
    predicate TEXT NOT NULL,
    statement TEXT NOT NULL,
    kind TEXT NOT NULL,
    assessment TEXT NOT NULL,
    region_ref TEXT,
    PRIMARY KEY (artifact_id, revision, claim_id),
    FOREIGN KEY (artifact_id, revision) REFERENCES revisions(artifact_id, revision) ON DELETE CASCADE
);

CREATE TABLE conflicts (
    conflict_id INTEGER PRIMARY KEY,
    kind TEXT CHECK (kind IN ('revision', 'duplicate-id', 'authority', 'identity')) NOT NULL,
    artifact_id TEXT NOT NULL,
    detail TEXT NOT NULL,
    opened_at TEXT NOT NULL,
    resolved_at TEXT,
    resolution TEXT
);

CREATE TABLE events (
    event_id INTEGER PRIMARY KEY,
    at TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    artifact_id TEXT,
    revision INTEGER,
    path TEXT,
    detail TEXT
);

CREATE INDEX locations_by_artifact ON locations(artifact_id);
CREATE INDEX conflicts_by_artifact ON conflicts(artifact_id, resolved_at);
CREATE INDEX events_by_artifact ON events(artifact_id);

CREATE VIEW docs AS
SELECT
    a.title,
    a.type,
    a.status,
    a.standing,
    a.current_revision AS rev,
    r.path || '/' || l.rel_path AS path,
    a.last_seen_at,
    a.artifact_id
FROM artifacts a
JOIN locations l USING (artifact_id)
JOIN roots r USING (root_id)
WHERE l.present = 1;

CREATE VIEW open_conflicts AS
SELECT * FROM conflicts WHERE resolved_at IS NULL;

CREATE VIEW history AS
SELECT event_id, at, actor, action, path, revision, detail
FROM events
ORDER BY event_id DESC;

PRAGMA user_version = 1;

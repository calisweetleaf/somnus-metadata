"""Global SQLite registry ($SOMNUS_HOME/somnus.db)."""

<style>
.t{background:#141414;border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.45),0 0 0 1px #2a2a2a;margin:22px 0;font-family:Menlo,Monaco,Cascadia Code,Courier New,monospace;overflow:hidden}
.t-hdr{background:#252525;padding:11px 16px;display:flex;align-items:center;border-bottom:1px solid #1e1e1e}
.t-btn{width:13px;height:13px;border-radius:50%;margin-right:8px;flex-shrink:0}.t-btn.r{background:#ff5f57}.t-btn.y{background:#febc2e}.t-btn.g{background:#28c840}
.t-title{color:#888;font-size:12.5px;margin-left:10px;letter-spacing:.4px}.t-tag{margin-left:auto;background:#1e1e1e;border:1px solid #333;color:#777;font-size:10px;padding:2px 8px;border-radius:3px;letter-spacing:1px;text-transform:uppercase}
.t-body{padding:18px 20px;font-size:13px;line-height:1.65;color:#d4d4d4;overflow-x:auto}.prompt{color:#28c840}.dim{color:#777}.info{color:#8ec5fc}.warn{color:#febc2e}.err{color:#ff5f57}.accent{color:#c9a0dc}
</style>

# Python Production Doctor Report

Run ID: `20261011T112500Z`
Project: `C:\Users\trent\OneDrive\Desktop\Treys-Workspace\somnus-metadata\src`
Started: `2026-10-11T11:25:00.759122Z`
Finished: `2026-10-11T11:25:01.191517Z`
Config hash: `ba962456a29c03cea464a25183c1c955f1de718102ef798e14a6522b10426e38`

<div class="t">
  <div class="t-hdr"><div class="t-btn r"></div><div class="t-btn y"></div><div class="t-btn g"></div><span class="t-title">python-production-doctor</span><span class="t-tag">DIAGNOSIS</span></div>
  <div class="t-body">
    <div><span class="prompt">doctor@somnus:~$</span> scan C:\Users\trent\OneDrive\Desktop\Treys-Workspace\somnus-metadata\src</div>
    <div class="out info">files scanned: 21</div>
    <div class="out err">critical: 0</div>
    <div class="out warn">serious: 31</div>
    <div class="out dim">minor: 179 | info: 0</div>
    <div class="out accent">production score: 0/100</div>
  </div>
</div>

## Summary

| Metric | Value |
|---|---:|
| Files scanned | 21 |
| Total issues | 210 |
| Critical issues | 0 |
| Serious issues | 31 |
| Minor issues | 179 |
| Syntax-error files | 0 |
| Missing imports | 0 |
| Dependency cycles | 3 |
| Suspiciously short classes | 10 |
| Suspiciously short functions | 72 |

## Issue Categories

| Category | Count |
|---|---:|
| `broad_exceptions` | 1 |
| `complexity` | 23 |
| `dependency_cycles` | 1 |
| `missing_docstrings` | 46 |
| `silent_failures` | 17 |
| `stubs` | 2 |
| `suspicious_short_classes` | 10 |
| `suspicious_short_functions` | 72 |
| `type_hint_gaps` | 14 |
| `unused_imports` | 24 |

## Local State Delta

| Delta | Count | Files |
|---|---:|---|
| New | 21 | somnus/__init__.py, somnus/__main__.py, somnus/carriers/__init__.py, somnus/carriers/blockcomment.py, somnus/carriers/linecomment.py, somnus/carriers/markdown.py, somnus/carriers/sidecar.py, somnus/config.py, somnus/db/__init__.py, somnus/db/store.py, somnus/document.py, somnus/ids.py |
| Modified | 0 | none |
| Deleted | 0 | none |
| Unchanged | 0 | none |

## Dependency Map

```mermaid
graph TD
    N1["somnus/__init__.py"]
    N2["somnus/__main__.py"]
    N3["somnus/carriers/__init__.py"]
    N4["somnus/carriers/blockcomment.py"]
    N5["somnus/carriers/linecomment.py"]
    N6["somnus/carriers/markdown.py"]
    N7["somnus/carriers/sidecar.py"]
    N8["somnus/config.py"]
    N9["somnus/db/__init__.py"]
    N10["somnus/db/store.py"]
    N11["somnus/document.py"]
    N12["somnus/ids.py"]
    N13["somnus/infer.py"]
    N14["somnus/model/__init__.py"]
    N15["somnus/model/lifecycle.py"]
    N16["somnus/model/schema.py"]
    N17["somnus/model/validate.py"]
    N18["somnus/model/vocab.py"]
    N19["somnus/output.py"]
    N20["somnus/regions.py"]
    N21["somnus/yamlsub.py"]
    N2 --> N1
    N3 --> N4
    N3 --> N5
    N3 --> N6
    N4 --> N3
    N5 --> N3
    N6 --> N3
    N6 --> N20
    N7 --> N3
    N8 --> N14
    N9 --> N10
    N10 --> N1
    N10 --> N1
    N10 --> N14
    N10 --> N17
    N10 --> N19
    N11 --> N1
    N11 --> N3
    N11 --> N7
    N11 --> N16
    N11 --> N19
    N16 --> N1
    N16 --> N14
    N17 --> N1
    N17 --> N7
    N17 --> N11
    N17 --> N14
    N17 --> N14
    N17 --> N19
    N17 --> N20
    N17 --> N11
    N20 --> N12
    C1{"cycle: somnus/carriers/__init__.py -> somnus/carriers/blockcomment.py"}
    C2{"cycle: somnus/carriers/__init__.py -> somnus/carriers/linecomment.py"}
    C3{"cycle: somnus/carriers/__init__.py -> somnus/carriers/markdown.py"}
```

### Missing or Unresolved Imports

| Source | Line | Import | Status |
|---|---:|---|---|
| none | 0 | none | all imports resolved or classified |

### Dependency Cycles

| Cycle |
|---|
| `somnus/carriers/__init__.py -> somnus/carriers/blockcomment.py` |
| `somnus/carriers/__init__.py -> somnus/carriers/linecomment.py` |
| `somnus/carriers/__init__.py -> somnus/carriers/markdown.py` |

## Suspiciously Short Classes

- `somnus/carriers/linecomment.py:105` `HashCarrier`: Class HashCarrier is suspiciously short.
- `somnus/model/schema.py:33` `Str`: Class Str is suspiciously short.
- `somnus/model/schema.py:44` `Int`: Class Int is suspiciously short.
- `somnus/model/schema.py:52` `Num`: Class Num is suspiciously short.
- `somnus/model/schema.py:61` `Bool`: Class Bool is suspiciously short.
- `somnus/model/schema.py:68` `AnyValue`: Class AnyValue is suspiciously short.
- `somnus/model/schema.py:75` `Arr`: Class Arr is suspiciously short.
- `somnus/model/schema.py:85` `Field`: Class Field is suspiciously short.
- `somnus/model/schema.py:116` `MapOf`: Class MapOf is suspiciously short.
- `somnus/model/schema.py:145` `Union_`: Class Union_ is suspiciously short.

## Suspiciously Short Functions

- `somnus/carriers/__init__.py:30` `Envelope.__post_init__`: Function Envelope.__post_init__ is suspiciously short.
- `somnus/carriers/__init__.py:35` `Envelope.payload`: Function Envelope.payload is suspiciously short.
- `somnus/carriers/__init__.py:75` `Carrier.extract`: Function Carrier.extract is suspiciously short.
- `somnus/carriers/__init__.py:79` `Carrier.render`: Function Carrier.render is suspiciously short.
- `somnus/carriers/__init__.py:87` `CarrierError.__init__`: Function CarrierError.__init__ is suspiciously short.
- `somnus/carriers/__init__.py:134` `get`: Function get is suspiciously short.
- `somnus/carriers/__init__.py:141` `is_sidecar_path`: Function is_sidecar_path is suspiciously short.
- `somnus/carriers/__init__.py:146` `sidecar_for`: Function sidecar_for is suspiciously short.
- `somnus/carriers/__init__.py:151` `host_for`: Function host_for is suspiciously short.
- `somnus/carriers/__init__.py:156` `carrier_name_for`: Function carrier_name_for is suspiciously short.
- `somnus/carriers/__init__.py:164` `for_path`: Function for_path is suspiciously short.
- `somnus/carriers/linecomment.py:108` `HashCarrier.__init__`: Function HashCarrier.__init__ is suspiciously short.
- `somnus/carriers/sidecar.py:28` `SidecarCarrier.render`: Function SidecarCarrier.render is suspiciously short.
- `somnus/carriers/sidecar.py:67` `primary_target`: Function primary_target is suspiciously short.
- `somnus/config.py:79` `Config.db_path`: Function Config.db_path is suspiciously short.
- `somnus/config.py:84` `somnus_home`: Function somnus_home is suspiciously short.
- `somnus/db/store.py:24` `now_iso`: Function now_iso is suspiciously short.
- `somnus/db/store.py:59` `matches_any`: Function matches_any is suspiciously short.
- `somnus/db/store.py:91` `ScanReport.summary`: Function ScanReport.summary is suspiciously short.
- `somnus/db/store.py:140` `Store.__init__`: Function Store.__init__ is suspiciously short.
- `somnus/db/store.py:175` `Store.close`: Function Store.close is suspiciously short.
- `somnus/db/store.py:180` `Store.__enter__`: Function Store.__enter__ is suspiciously short.
- `somnus/db/store.py:183` `Store.__exit__`: Function Store.__exit__ is suspiciously short.
- `somnus/db/store.py:189` `Store.log`: Function Store.log is suspiciously short.
- `somnus/db/store.py:209` `Store.roots`: Function Store.roots is suspiciously short.
- `somnus/document.py:60` `Document.is_sidecar`: Function Document.is_sidecar is suspiciously short.
- `somnus/document.py:65` `Document.newline`: Function Document.newline is suspiciously short.
- `somnus/document.py:70` `Document.payload`: Function Document.payload is suspiciously short.
- `somnus/document.py:77` `Document.display`: Function Document.display is suspiciously short.
- `somnus/document.py:82` `Document.ignore_span`: Function Document.ignore_span is suspiciously short.
- `somnus/document.py:96` `Document.body_digest`: Function Document.body_digest is suspiciously short.
- `somnus/document.py:103` `Document.payload_digest`: Function Document.payload_digest is suspiciously short.
- `somnus/document.py:117` `Document.diag`: Function Document.diag is suspiciously short.
- `somnus/document.py:163` `Document.save`: Function Document.save is suspiciously short.
- `somnus/document.py:169` `Document.copy_payload`: Function Document.copy_payload is suspiciously short.
- `somnus/document.py:187` `canonical_yaml`: Function canonical_yaml is suspiciously short.
- `somnus/document.py:324` `new_sidecar_text`: Function new_sidecar_text is suspiciously short.
- `somnus/ids.py:52` `new_artifact_urn`: Function new_artifact_urn is suspiciously short.
- `somnus/ids.py:57` `parse_urn`: Function parse_urn is suspiciously short.
- `somnus/ids.py:65` `is_artifact_urn`: Function is_artifact_urn is suspiciously short.
- `somnus/ids.py:70` `is_example_urn`: Function is_example_urn is suspiciously short.
- `somnus/ids.py:75` `is_external_ref`: Function is_external_ref is suspiciously short.
- `somnus/ids.py:80` `is_reference_string`: Function is_reference_string is suspiciously short.
- `somnus/ids.py:85` `uuid_version`: Function uuid_version is suspiciously short.
- `somnus/ids.py:126` `is_local_id`: Function is_local_id is suspiciously short.
- `somnus/infer.py:140` `infer`: Function infer is suspiciously short.
- `somnus/model/lifecycle.py:27` `is_abandonment`: Function is_abandonment is suspiciously short.
- `somnus/model/lifecycle.py:32` `is_reactivation`: Function is_reactivation is suspiciously short.
- `somnus/model/lifecycle.py:59` `now_utc`: Function now_utc is suspiciously short.
- `somnus/model/schema.py:102` `Obj.get`: Function Obj.get is suspiciously short.
- `somnus/model/schema.py:110` `Obj.order`: Function Obj.order is suspiciously short.
- `somnus/model/schema.py:155` `F`: Function F is suspiciously short.
- `somnus/model/schema.py:160` `enum`: Function enum is suspiciously short.
- `somnus/model/validate.py:92` `_Run.__init__`: Function _Run.__init__ is suspiciously short.
- `somnus/model/validate.py:96` `_Run.err`: Function _Run.err is suspiciously short.
- `somnus/model/validate.py:99` `_Run.warn`: Function _Run.warn is suspiciously short.
- `somnus/model/validate.py:102` `_Run.at`: Function _Run.at is suspiciously short.
- `somnus/output.py:29` `Diagnostic.is_error`: Function Diagnostic.is_error is suspiciously short.
- `somnus/output.py:58` `render`: Function render is suspiciously short.
- `somnus/output.py:64` `has_errors`: Function has_errors is suspiciously short.
- `somnus/output.py:80` `table.line`: Function table.line is suspiciously short.
- `somnus/output.py:87` `emit`: Function emit is suspiciously short.
- `somnus/yamlsub.py:34` `YAMLError.__init__`: Function YAMLError.__init__ is suspiciously short.
- `somnus/yamlsub.py:216` `_Flow.err`: Function _Flow.err is suspiciously short.
- `somnus/yamlsub.py:219` `_Flow.ws`: Function _Flow.ws is suspiciously short.
- `somnus/yamlsub.py:360` `_Parser.take`: Function _Parser.take is suspiciously short.
- `somnus/yamlsub.py:586` `parse`: Function parse is suspiciously short.
- `somnus/yamlsub.py:594` `loads`: Function loads is suspiciously short.
- `somnus/yamlsub.py:663` `_Dumper.__init__`: Function _Dumper.__init__ is suspiciously short.
- `somnus/yamlsub.py:668` `_Dumper.keys`: Function _Dumper.keys is suspiciously short.
- `somnus/yamlsub.py:673` `_Dumper.flow`: Function _Dumper.flow is suspiciously short.
- `somnus/yamlsub.py:729` `dumps`: Function dumps is suspiciously short.

## Full Issue Index

| Severity | Category | File | Line | Symbol | Message |
|---|---|---|---:|---|---|
| serious | `dependency_cycles` | `somnus/carriers/__init__.py` | 1 | `somnus/carriers/__init__.py` | Local dependency cycle detected. |
| minor | `unused_imports` | `somnus/carriers/__init__.py` | 8 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/carriers/__init__.py` | 30 | `Envelope.__post_init__` | Function Envelope.__post_init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 30 | `Envelope.__post_init__` | Function Envelope.__post_init__ is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 35 | `Envelope.payload` | Function Envelope.payload is suspiciously short. |
| serious | `stubs` | `somnus/carriers/__init__.py` | 75 | `Carrier.extract` | Function Carrier.extract has a stub implementation. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 75 | `Carrier.extract` | Function Carrier.extract is suspiciously short. |
| serious | `stubs` | `somnus/carriers/__init__.py` | 79 | `Carrier.render` | Function Carrier.render has a stub implementation. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 79 | `Carrier.render` | Function Carrier.render is suspiciously short. |
| minor | `missing_docstrings` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 134 | `get` | Function get is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 141 | `is_sidecar_path` | Function is_sidecar_path is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 146 | `sidecar_for` | Function sidecar_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 151 | `host_for` | Function host_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 156 | `carrier_name_for` | Function carrier_name_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 164 | `for_path` | Function for_path is suspiciously short. |
| minor | `unused_imports` | `somnus/carriers/blockcomment.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/carriers/blockcomment.py` | 16 | `BlockCarrier.__init__` | Function BlockCarrier.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/carriers/blockcomment.py` | 16 | `BlockCarrier.__init__` | Function BlockCarrier.__init__ has incomplete type hints. |
| minor | `complexity` | `somnus/carriers/blockcomment.py` | 56 | `BlockCarrier.extract` | Function BlockCarrier.extract has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/carriers/blockcomment.py` | 61 | `BlockCarrier.extract` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/carriers/linecomment.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/carriers/linecomment.py` | 15 | `preamble_end` | Function preamble_end has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/carriers/linecomment.py` | 40 | `LineCarrier.__init__` | Function LineCarrier.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/carriers/linecomment.py` | 40 | `LineCarrier.__init__` | Function LineCarrier.__init__ has incomplete type hints. |
| minor | `complexity` | `somnus/carriers/linecomment.py` | 53 | `LineCarrier.extract` | Function LineCarrier.extract has high cyclomatic complexity. |
| serious | `suspicious_short_classes` | `somnus/carriers/linecomment.py` | 105 | `HashCarrier` | Class HashCarrier is suspiciously short. |
| minor | `missing_docstrings` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ has incomplete type hints. |
| minor | `unused_imports` | `somnus/carriers/markdown.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/carriers/markdown.py` | 34 | `MarkdownCarrier.extract` | Function MarkdownCarrier.extract has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/carriers/sidecar.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/carriers/sidecar.py` | 28 | `SidecarCarrier.render` | Function SidecarCarrier.render is suspiciously short. |
| minor | `complexity` | `somnus/carriers/sidecar.py` | 38 | `binding_issues` | Function binding_issues has high cyclomatic complexity. |
| minor | `suspicious_short_functions` | `somnus/carriers/sidecar.py` | 67 | `primary_target` | Function primary_target is suspiciously short. |
| minor | `unused_imports` | `somnus/config.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/config.py` | 79 | `Config.db_path` | Function Config.db_path is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/config.py` | 84 | `somnus_home` | Function somnus_home is suspiciously short. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `ScanReport` | Imported name appears unused: ScanReport. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `Store` | Imported name appears unused: Store. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `connect_readonly` | Imported name appears unused: connect_readonly. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `glob_regex` | Imported name appears unused: glob_regex. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `matches_any` | Imported name appears unused: matches_any. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `now_iso` | Imported name appears unused: now_iso. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `run_query` | Imported name appears unused: run_query. |
| minor | `unused_imports` | `somnus/db/store.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 24 | `now_iso` | Function now_iso is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 59 | `matches_any` | Function matches_any is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 91 | `ScanReport.summary` | Function ScanReport.summary is suspiciously short. |
| serious | `silent_failures` | `somnus/db/store.py` | 107 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 175 | `Store.close` | Function Store.close is suspiciously short. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 180 | `Store.__enter__` | Function Store.__enter__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 180 | `Store.__enter__` | Function Store.__enter__ is suspiciously short. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 189 | `Store.log` | Function Store.log is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 209 | `Store.roots` | Function Store.roots is suspiciously short. |
| minor | `complexity` | `somnus/db/store.py` | 266 | `Store.scan` | Function Store.scan has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/db/store.py` | 333 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/db/store.py` | 346 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/db/store.py` | 538 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/document.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 60 | `Document.is_sidecar` | Function Document.is_sidecar is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 65 | `Document.newline` | Function Document.newline is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 70 | `Document.payload` | Function Document.payload is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 77 | `Document.display` | Function Document.display is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 82 | `Document.ignore_span` | Function Document.ignore_span is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 96 | `Document.body_digest` | Function Document.body_digest is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 103 | `Document.payload_digest` | Function Document.payload_digest is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 117 | `Document.diag` | Function Document.diag is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 163 | `Document.save` | Function Document.save is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 169 | `Document.copy_payload` | Function Document.copy_payload is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 187 | `canonical_yaml` | Function canonical_yaml is suspiciously short. |
| serious | `silent_failures` | `somnus/document.py` | 195 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/document.py` | 211 | `atomic_write` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `broad_exceptions` | `somnus/document.py` | 214 | `atomic_write` | Broad exception handler catches BaseException. |
| serious | `silent_failures` | `somnus/document.py` | 249 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 324 | `new_sidecar_text` | Function new_sidecar_text is suspiciously short. |
| minor | `unused_imports` | `somnus/ids.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 52 | `new_artifact_urn` | Function new_artifact_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 57 | `parse_urn` | Function parse_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 65 | `is_artifact_urn` | Function is_artifact_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 70 | `is_example_urn` | Function is_example_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 75 | `is_external_ref` | Function is_external_ref is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 80 | `is_reference_string` | Function is_reference_string is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 85 | `uuid_version` | Function uuid_version is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 126 | `is_local_id` | Function is_local_id is suspiciously short. |
| minor | `unused_imports` | `somnus/infer.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/infer.py` | 97 | `infer_title` | Function infer_title has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/infer.py` | 121 | `infer_title` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/infer.py` | 140 | `infer` | Function infer is suspiciously short. |
| minor | `unused_imports` | `somnus/model/lifecycle.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 27 | `is_abandonment` | Function is_abandonment is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 32 | `is_reactivation` | Function is_reactivation is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 59 | `now_utc` | Function now_utc is suspiciously short. |
| serious | `silent_failures` | `somnus/model/lifecycle.py` | 111 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/model/schema.py` | 8 | `annotations` | Imported name appears unused: annotations. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 33 | `Str` | Class Str is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 44 | `Int` | Class Int is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 52 | `Num` | Class Num is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/schema.py` | 61 | `Bool` | Class Bool is missing a meaningful docstring. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 61 | `Bool` | Class Bool is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 68 | `AnyValue` | Class AnyValue is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 75 | `Arr` | Class Arr is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 85 | `Field` | Class Field is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 102 | `Obj.get` | Function Obj.get is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 110 | `Obj.order` | Function Obj.order is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 116 | `MapOf` | Class MapOf is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 145 | `Union_` | Class Union_ is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 155 | `F` | Function F is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 160 | `enum` | Function enum is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/model/schema.py` | 542 | `make_order` | Function make_order has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/model/schema.py` | 551 | `make_order.order` | Function make_order.order is missing a meaningful docstring. |
| minor | `complexity` | `somnus/model/schema.py` | 562 | `describe` | Function describe has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/model/validate.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/model/validate.py` | 51 | `Resolver.add_payload` | Function Resolver.add_payload has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 81 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 96 | `_Run.err` | Function _Run.err is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 96 | `_Run.err` | Function _Run.err is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 99 | `_Run.warn` | Function _Run.warn is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 99 | `_Run.warn` | Function _Run.warn is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 102 | `_Run.at` | Function _Run.at is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 102 | `_Run.at` | Function _Run.at is suspiciously short. |
| minor | `complexity` | `somnus/model/validate.py` | 109 | `walk` | Function walk has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 130 | `walk` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 278 | `consistency` | Function consistency has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 438 | `find_cycle.visit` | Function find_cycle.visit is missing a meaningful docstring. |
| minor | `complexity` | `somnus/model/validate.py` | 500 | `marker_regions` | Function marker_regions has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 563 | `references` | Function references has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 592 | `references` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 618 | `selectors` | Function selectors has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 652 | `selectors` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/model/validate.py` | 667 | `selectors` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 691 | `semantic_policies` | Function semantic_policies has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 760 | `validate` | Function validate has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 815 | `permits_use` | Function permits_use has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/model/vocab.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `unused_imports` | `somnus/output.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 29 | `Diagnostic.is_error` | Function Diagnostic.is_error is suspiciously short. |
| minor | `missing_docstrings` | `somnus/output.py` | 37 | `SomnusError.__init__` | Function SomnusError.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/output.py` | 37 | `SomnusError.__init__` | Function SomnusError.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 58 | `render` | Function render is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 64 | `has_errors` | Function has_errors is suspiciously short. |
| minor | `complexity` | `somnus/output.py` | 69 | `table` | Function table has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/output.py` | 80 | `table.line` | Function table.line is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 80 | `table.line` | Function table.line is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 87 | `emit` | Function emit is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/output.py` | 87 | `emit` | Function emit has incomplete type hints. |
| minor | `unused_imports` | `somnus/regions.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/regions.py` | 37 | `markdown_code_mask` | Function markdown_code_mask has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/regions.py` | 81 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/regions.py` | 103 | `scan_markers` | Function scan_markers has high cyclomatic complexity. |
| minor | `complexity` | `somnus/regions.py` | 190 | `sync_registry` | Function sync_registry has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/yamlsub.py` | 13 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 59 | `_Line` | Class _Line is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 206 | `_Flow` | Class _Flow is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 207 | `_Flow.__init__` | Function _Flow.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 207 | `_Flow.__init__` | Function _Flow.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 216 | `_Flow.err` | Function _Flow.err is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 216 | `_Flow.err` | Function _Flow.err is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 219 | `_Flow.ws` | Function _Flow.ws is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 219 | `_Flow.ws` | Function _Flow.ws is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 223 | `_Flow.value` | Function _Flow.value is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 247 | `_Flow.seq` | Function _Flow.seq is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 269 | `_Flow.key` | Function _Flow.key is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 288 | `_Flow.mapping` | Function _Flow.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 326 | `_Parser` | Class _Parser is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 327 | `_Parser.__init__` | Function _Parser.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 327 | `_Parser.__init__` | Function _Parser.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 337 | `_Parser.peek` | Function _Parser.peek is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 360 | `_Parser.take` | Function _Parser.take is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 360 | `_Parser.take` | Function _Parser.take is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 367 | `_Parser.document` | Function _Parser.document is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 379 | `_Parser.block` | Function _Parser.block is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 386 | `_Parser.mapping` | Function _Parser.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 404 | `_Parser.value_after_key` | Function _Parser.value_after_key is missing a meaningful docstring. |
| minor | `complexity` | `somnus/yamlsub.py` | 416 | `_Parser.sequence` | Function _Parser.sequence has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 416 | `_Parser.sequence` | Function _Parser.sequence is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 450 | `_Parser.split_key` | Function _Parser.split_key is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 480 | `_Parser.inline` | Function _Parser.inline is missing a meaningful docstring. |
| minor | `complexity` | `somnus/yamlsub.py` | 498 | `_Parser.block_scalar` | Function _Parser.block_scalar has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 498 | `_Parser.block_scalar` | Function _Parser.block_scalar is missing a meaningful docstring. |
| serious | `silent_failures` | `somnus/yamlsub.py` | 578 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 586 | `parse` | Function parse is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 594 | `loads` | Function loads is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 662 | `_Dumper` | Class _Dumper is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 663 | `_Dumper.__init__` | Function _Dumper.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 663 | `_Dumper.__init__` | Function _Dumper.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 663 | `_Dumper.__init__` | Function _Dumper.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 668 | `_Dumper.keys` | Function _Dumper.keys is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 668 | `_Dumper.keys` | Function _Dumper.keys is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 673 | `_Dumper.flow` | Function _Dumper.flow is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 673 | `_Dumper.flow` | Function _Dumper.flow is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 676 | `_Dumper.mapping` | Function _Dumper.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 694 | `_Dumper.list_after` | Function _Dumper.list_after is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 703 | `_Dumper.sequence` | Function _Dumper.sequence is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 729 | `dumps` | Function dumps is suspiciously short. |

## File Diagnostics

### `somnus/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 9 |
| Code lines | 7 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/__main__.py`

| Metric | Value |
|---|---:|
| Lines | 8 |
| Code lines | 5 |
| Classes | 0 |
| Functions | 0 |
| Imports | 2 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/carriers/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 167 |
| Code lines | 123 |
| Classes | 6 |
| Functions | 11 |
| Imports | 7 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 3 |

#### Issue 1: `dependency_cycles` at line 1

Severity: `serious`
Symbol: `somnus/carriers/__init__.py`
Message: Local dependency cycle detected.
Remediation: Break the cycle by moving shared contracts into a lower-level module or inverting the import boundary.

Evidence:
```text
No source evidence available.
```
Details:
```json
{
  "cycle": [
    "somnus/carriers/__init__.py",
    "somnus/carriers/blockcomment.py"
  ]
}
```

#### Issue 2: `unused_imports` at line 8

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  6: """
  7: 
> 8: from __future__ import annotations
  9: 
  10: from dataclasses import dataclass, field
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 3: `missing_docstrings` at line 30

Severity: `minor`
Symbol: `Envelope.__post_init__`
Message: Function Envelope.__post_init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  28:     mask_end: int = -1
  29: 
> 30:     def __post_init__(self) -> None:
  31:         if self.mask_start < 0:
  32:             self.mask_start, self.mask_end = self.start, self.end
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `suspicious_short_functions` at line 30

Severity: `minor`
Symbol: `Envelope.__post_init__`
Message: Function Envelope.__post_init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  28:     mask_end: int = -1
  29: 
> 30:     def __post_init__(self) -> None:
  31:         if self.mask_start < 0:
  32:             self.mask_start, self.mask_end = self.start, self.end
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 35

Severity: `minor`
Symbol: `Envelope.payload`
Message: Function Envelope.payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  33: 
  34:     @property
> 35:     def payload(self) -> str:
  36:         """Payload YAML text with a trailing newline."""
  37:         return "\n".join(self.payload_lines) + "\n"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 75

Severity: `minor`
Symbol: `Carrier.extract`
Message: Function Carrier.extract is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  73:     region_style: tuple
  74: 
> 75:     def extract(self, lines: list[str]) -> Extraction:
  76:         """Locate the envelope."""
  77:         ...
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `stubs` at line 75

Severity: `serious`
Symbol: `Carrier.extract`
Message: Function Carrier.extract has a stub implementation.
Remediation: Replace pass, ellipsis, or NotImplementedError with a real diagnostic path or domain exception.

Evidence:
```text
  73:     region_style: tuple
  74: 
> 75:     def extract(self, lines: list[str]) -> Extraction:
  76:         """Locate the envelope."""
  77:         ...
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 79

Severity: `minor`
Symbol: `Carrier.render`
Message: Function Carrier.render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  77:         ...
  78: 
> 79:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  80:         """Return the splice that writes ``payload`` into the file."""
  81:         ...
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `stubs` at line 79

Severity: `serious`
Symbol: `Carrier.render`
Message: Function Carrier.render has a stub implementation.
Remediation: Replace pass, ellipsis, or NotImplementedError with a real diagnostic path or domain exception.

Evidence:
```text
  77:         ...
  78: 
> 79:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  80:         """Return the splice that writes ``payload`` into the file."""
  81:         ...
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `missing_docstrings` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 11: `suspicious_short_functions` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 12: `type_hint_gaps` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 13: `suspicious_short_functions` at line 134

Severity: `minor`
Symbol: `get`
Message: Function get is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  132: 
  133: 
> 134: def get(name: str) -> Carrier:
  135:     """Return the carrier registered under ``name``."""
  136:     if not _CACHE:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 14: `suspicious_short_functions` at line 141

Severity: `minor`
Symbol: `is_sidecar_path`
Message: Function is_sidecar_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  139: 
  140: 
> 141: def is_sidecar_path(path: Path) -> bool:
  142:     """Return True for ``*.somnus.yaml`` sidecar files."""
  143:     return path.name.endswith(SIDECAR_SUFFIX)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 15: `suspicious_short_functions` at line 146

Severity: `minor`
Symbol: `sidecar_for`
Message: Function sidecar_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  144: 
  145: 
> 146: def sidecar_for(path: Path) -> Path:
  147:     """Return the sidecar path for a host file."""
  148:     return path.with_name(path.name + SIDECAR_SUFFIX)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 16: `suspicious_short_functions` at line 151

Severity: `minor`
Symbol: `host_for`
Message: Function host_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  149: 
  150: 
> 151: def host_for(sidecar: Path) -> Path:
  152:     """Return the host path a sidecar file describes by name."""
  153:     return sidecar.with_name(sidecar.name[: -len(SIDECAR_SUFFIX)])
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 17: `suspicious_short_functions` at line 156

Severity: `minor`
Symbol: `carrier_name_for`
Message: Function carrier_name_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  154: 
  155: 
> 156: def carrier_name_for(path: Path) -> Optional[str]:
  157:     """Return the embedded carrier name for a path, or None when a sidecar is required."""
  158:     if is_sidecar_path(path):
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 18: `suspicious_short_functions` at line 164

Severity: `minor`
Symbol: `for_path`
Message: Function for_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  162: 
  163: 
> 164: def for_path(path: Path) -> Optional[Carrier]:
  165:     """Return the embedded carrier for a path, or None when a sidecar is required."""
  166:     name = carrier_name_for(path)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

### `somnus/carriers/blockcomment.py`

| Metric | Value |
|---|---:|
| Lines | 105 |
| Code lines | 92 |
| Classes | 1 |
| Functions | 4 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 13 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Block-comment carriers: CSS ``/* */`` and XML/HTML/SVG ``<!-- -->`` (SPEC Â§17.4â€“Â§17.5)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 16

Severity: `minor`
Symbol: `BlockCarrier.__init__`
Message: Function BlockCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  14:     """Envelope delimited by a block-comment opener and closer line."""
  15: 
> 16:     def __init__(self, name: str, opener: str, closer: str, forbidden: str, forbid: str, region_style: tuple):
  17:         self.name = name
  18:         self.capability = "somnus-adapter-block-comment@1"
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `type_hint_gaps` at line 16

Severity: `minor`
Symbol: `BlockCarrier.__init__`
Message: Function BlockCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  14:     """Envelope delimited by a block-comment opener and closer line."""
  15: 
> 16:     def __init__(self, name: str, opener: str, closer: str, forbidden: str, forbid: str, region_style: tuple):
  17:         self.name = name
  18:         self.capability = "somnus-adapter-block-comment@1"
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 4: `complexity` at line 56

Severity: `minor`
Symbol: `BlockCarrier.extract`
Message: Function BlockCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  54:         return s.startswith("/*") and s.endswith("*/") and s != self.opener
  55: 
> 56:     def extract(self, lines: list[str]) -> Extraction:
  57:         """Scan the leading area (after declarations) for one envelope."""
  58:         result = Extraction()
```
Details:
```json
{
  "complexity": 13,
  "maximum": 12
}
```

#### Issue 5: `silent_failures` at line 61

Severity: `serious`
Symbol: `BlockCarrier.extract`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  59:         try:
  60:             i = self.preamble_end(lines)
> 61:         except CarrierError:
  62:             i = 0
  63:         found: list[Envelope] = []
```
Details:
```json
{
  "handler_body_length": 1
}
```

### `somnus/carriers/linecomment.py`

| Metric | Value |
|---|---:|
| Lines | 109 |
| Code lines | 93 |
| Classes | 2 |
| Functions | 5 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 17 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Comment-prefixed carriers: ``# ``, ``% ``, ``// ``, ``-- `` (SPEC Â§17.3, Â§17.5)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 15

Severity: `minor`
Symbol: `preamble_end`
Message: Function preamble_end has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  13: 
  14: 
> 15: def preamble_end(host: str, lines: list[str]) -> int:
  16:     """Return the index of the first line after mandatory host preamble lines."""
  17:     i = 0
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 3: `missing_docstrings` at line 40

Severity: `minor`
Symbol: `LineCarrier.__init__`
Message: Function LineCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  38:     forbid: Optional[str] = None
  39: 
> 40:     def __init__(self, host: str, prefix: str, capability: str, name: Optional[str] = None):
  41:         self.host = host
  42:         self.prefix = prefix
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `type_hint_gaps` at line 40

Severity: `minor`
Symbol: `LineCarrier.__init__`
Message: Function LineCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  38:     forbid: Optional[str] = None
  39: 
> 40:     def __init__(self, host: str, prefix: str, capability: str, name: Optional[str] = None):
  41:         self.host = host
  42:         self.prefix = prefix
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `complexity` at line 53

Severity: `minor`
Symbol: `LineCarrier.extract`
Message: Function LineCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  51:         return line.lstrip().startswith(self.bare)
  52: 
> 53:     def extract(self, lines: list[str]) -> Extraction:
  54:         """Scan the leading comment area for exactly one envelope."""
  55:         result = Extraction()
```
Details:
```json
{
  "complexity": 14,
  "maximum": 12
}
```

#### Issue 6: `suspicious_short_classes` at line 105

Severity: `serious`
Symbol: `HashCarrier`
Message: Class HashCarrier is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  103: 
  104: 
> 105: class HashCarrier(LineCarrier):
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 1,
  "public_method_count": 0
}
```

#### Issue 7: `missing_docstrings` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `type_hint_gaps` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

### `somnus/carriers/markdown.py`

| Metric | Value |
|---|---:|
| Lines | 106 |
| Code lines | 94 |
| Classes | 1 |
| Functions | 3 |
| Imports | 5 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 21 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Markdown carriers: YAML frontmatter and the hidden HTML comment envelope (SPEC Â§17.1â€“Â§17.2)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 34

Severity: `minor`
Symbol: `MarkdownCarrier.extract`
Message: Function MarkdownCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  32:     region_style = ("markdown",)
  33: 
> 34:     def extract(self, lines: list[str]) -> Extraction:
  35:         """Find the unique frontmatter ``somnus`` block or HTML envelope."""
  36:         result = Extraction()
```
Details:
```json
{
  "complexity": 21,
  "maximum": 12
}
```

### `somnus/carriers/sidecar.py`

| Metric | Value |
|---|---:|
| Lines | 72 |
| Code lines | 58 |
| Classes | 1 |
| Functions | 4 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 16 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Detached sidecar bindings: ``<file>.somnus.yaml`` (SPEC Â§17.6)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 28

Severity: `minor`
Symbol: `SidecarCarrier.render`
Message: Function SidecarCarrier.render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  26:         return Extraction(Envelope("sidecar", 0, end, lines[:end], 0))
  27: 
> 28:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  29:         """Replace the whole sidecar content."""
  30:         body = payload.rstrip("\n").split("\n")
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 3: `complexity` at line 38

Severity: `minor`
Symbol: `binding_issues`
Message: Function binding_issues has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  36: 
  37: 
> 38: def binding_issues(somnus: Any, sidecar_path: Path) -> list[tuple[tuple, str]]:
  39:     """Check the primary binding contract; return (field path, message) pairs."""
  40:     problems: list[tuple[tuple, str]] = []
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

#### Issue 4: `suspicious_short_functions` at line 67

Severity: `minor`
Symbol: `primary_target`
Message: Function primary_target is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  65: 
  66: 
> 67: def primary_target(somnus: Any, sidecar_path: Path) -> Optional[Path]:
  68:     """Return the resolved primary target path of a sidecar, when it is a relative locator."""
  69:     for b in somnus.get("bindings", []) if isinstance(somnus, dict) else []:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

### `somnus/config.py`

| Metric | Value |
|---|---:|
| Lines | 176 |
| Code lines | 151 |
| Classes | 2 |
| Functions | 4 |
| Imports | 8 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 11 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Hierarchical configuration: CLI flag > nearest .somnus.toml > $SOMNUS_HOME/config.toml > defaults."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 79

Severity: `minor`
Symbol: `Config.db_path`
Message: Function Config.db_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  77: 
  78:     @property
> 79:     def db_path(self) -> Path:
  80:         """Location of the global registry database."""
  81:         return self.home / "somnus.db"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 84

Severity: `minor`
Symbol: `somnus_home`
Message: Function somnus_home is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  82: 
  83: 
> 84: def somnus_home() -> Path:
  85:     """Return $SOMNUS_HOME, defaulting to ~/.somnus."""
  86:     env = os.environ.get("SOMNUS_HOME")
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

### `somnus/db/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 5 |
| Code lines | 3 |
| Classes | 0 |
| Functions | 0 |
| Imports | 1 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 0 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `ScanReport`
Message: Imported name appears unused: ScanReport.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 2: `unused_imports` at line 3

Severity: `minor`
Symbol: `Store`
Message: Imported name appears unused: Store.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 3: `unused_imports` at line 3

Severity: `minor`
Symbol: `connect_readonly`
Message: Imported name appears unused: connect_readonly.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 4: `unused_imports` at line 3

Severity: `minor`
Symbol: `glob_regex`
Message: Imported name appears unused: glob_regex.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 5: `unused_imports` at line 3

Severity: `minor`
Symbol: `matches_any`
Message: Imported name appears unused: matches_any.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 6: `unused_imports` at line 3

Severity: `minor`
Symbol: `now_iso`
Message: Imported name appears unused: now_iso.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 7: `unused_imports` at line 3

Severity: `minor`
Symbol: `run_query`
Message: Imported name appears unused: run_query.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

### `somnus/db/store.py`

| Metric | Value |
|---|---:|
| Lines | 675 |
| Code lines | 589 |
| Classes | 2 |
| Functions | 23 |
| Imports | 15 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 17 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry: open/migrate, indexing, conflicts, and read-only queries (SPEC Â§18)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import difflib
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 24

Severity: `minor`
Symbol: `now_iso`
Message: Function now_iso is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  22: 
  23: 
> 24: def now_iso() -> str:
  25:     """Current UTC instant as an RFC 3339 timestamp with a ``Z`` offset."""
  26:     return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 59

Severity: `minor`
Symbol: `matches_any`
Message: Function matches_any is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  57: 
  58: 
> 59: def matches_any(rel_path: str, patterns: Sequence[re.Pattern]) -> bool:
  60:     """True when a POSIX relative path matches any compiled glob."""
  61:     return any(p.match(rel_path) for p in patterns)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 91

Severity: `minor`
Symbol: `ScanReport.summary`
Message: Function ScanReport.summary is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  89:     diagnostics: list[Diagnostic] = field(default_factory=list)
  90: 
> 91:     def summary(self) -> str:
  92:         """One-line plain-English summary."""
  93:         return (f"scanned {self.scanned}, indexed {self.indexed}, unchanged {self.unchanged}, "
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 5: `silent_failures` at line 107

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  105:     try:
  106:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 107:     except ValueError:
  108:         return None
  109: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 6: `missing_docstrings` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 7: `suspicious_short_functions` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 8: `type_hint_gaps` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 9: `suspicious_short_functions` at line 175

Severity: `minor`
Symbol: `Store.close`
Message: Function Store.close is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  173:         self.conn.commit()
  174: 
> 175:     def close(self) -> None:
  176:         """Commit pending work and close the connection."""
  177:         self.conn.commit()
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 10: `missing_docstrings` at line 180

Severity: `minor`
Symbol: `Store.__enter__`
Message: Function Store.__enter__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  178:         self.conn.close()
  179: 
> 180:     def __enter__(self) -> "Store":
  181:         return self
  182: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 11: `suspicious_short_functions` at line 180

Severity: `minor`
Symbol: `Store.__enter__`
Message: Function Store.__enter__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  178:         self.conn.close()
  179: 
> 180:     def __enter__(self) -> "Store":
  181:         return self
  182: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `missing_docstrings` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 13: `suspicious_short_functions` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 14: `type_hint_gaps` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "missing_hints": [
    "param:exc_type",
    "param:exc",
    "param:tb"
  ]
}
```

#### Issue 15: `suspicious_short_functions` at line 189

Severity: `minor`
Symbol: `Store.log`
Message: Function Store.log is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  187: 
  188:     # ------------------------------------------------------------- ledger
> 189:     def log(self, action: str, artifact_id: Optional[str] = None, revision: Optional[int] = None,
  190:             path: Optional[str] = None, detail: Optional[str] = None) -> None:
  191:         """Append one row to the append-only event ledger."""
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 16: `suspicious_short_functions` at line 209

Severity: `minor`
Symbol: `Store.roots`
Message: Function Store.roots is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  207:         return cur.lastrowid
  208: 
> 209:     def roots(self) -> list[tuple[int, Path]]:
  210:         """Registered roots as ``(id, path)``."""
  211:         return [(r[0], Path(r[1])) for r in self.conn.execute("SELECT id, path FROM roots ORDER BY path")]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 17: `complexity` at line 266

Severity: `minor`
Symbol: `Store.scan`
Message: Function Store.scan has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  264: 
  265:     # ------------------------------------------------------------- indexing
> 266:     def scan(self, roots: Optional[Iterable[Path]] = None, exclude: Sequence[str] = (),
  267:              full: bool = False) -> ScanReport:
  268:         """Reconcile roots (default: all registered) into the registry."""
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 18: `silent_failures` at line 333

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  331:                 hst = host.stat()
  332:                 mtime, size = max(mtime, hst.st_mtime), size + hst.st_size
> 333:         except OSError as exc:
  334:             report.diagnostics.append(Diagnostic(str(file_path), 0, 0, "error", "E_IO", "-", exc.strerror or str(exc)))
  335:             report.invalid += 1
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 19: `silent_failures` at line 346

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  344:         try:
  345:             doc = D.load(file_path)
> 346:         except SomnusError as exc:
  347:             report.diagnostics.extend(exc.diagnostics)
  348:             report.invalid += 1
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 20: `silent_failures` at line 538

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  536:             try:
  537:                 authority = yamlsub.parse(header).data["somnus"]["authority"]
> 538:             except (yamlsub.YAMLError, KeyError, TypeError) as exc:
  539:                 report.diagnostics.append(Diagnostic("-", 0, 0, "error", "E_AUTHORITY", "-",
  540:                                                      f"stored header for {aid} is unreadable; authority overlap"
```
Details:
```json
{
  "handler_body_length": 2
}
```

### `somnus/document.py`

| Metric | Value |
|---|---:|
| Lines | 326 |
| Code lines | 274 |
| Classes | 1 |
| Functions | 19 |
| Imports | 13 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 7 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Document loading and atomic saving with byte preservation (SPEC Â§16.3, Â§17)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 60

Severity: `minor`
Symbol: `Document.is_sidecar`
Message: Function Document.is_sidecar is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  58:     # ------------------------------------------------------------- properties
  59:     @property
> 60:     def is_sidecar(self) -> bool:
  61:         """True when metadata lives in a ``.somnus.yaml`` sidecar."""
  62:         return self.carrier is SIDECAR
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 65

Severity: `minor`
Symbol: `Document.newline`
Message: Function Document.newline is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  63: 
  64:     @property
> 65:     def newline(self) -> str:
  66:         """Line ending used for lines the tool writes."""
  67:         return _dominant_newline(self.endings)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 70

Severity: `minor`
Symbol: `Document.payload`
Message: Function Document.payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  68: 
  69:     @property
> 70:     def payload(self) -> Optional[dict]:
  71:         """The ``somnus`` mapping, when it parsed."""
  72:         if isinstance(self.data, dict) and isinstance(self.data.get("somnus"), dict):
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 77

Severity: `minor`
Symbol: `Document.display`
Message: Function Document.display is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  75: 
  76:     @property
> 77:     def display(self) -> str:
  78:         """Path shown in diagnostics."""
  79:         return _display(self.meta_path)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 82

Severity: `minor`
Symbol: `Document.ignore_span`
Message: Function Document.ignore_span is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  80: 
  81:     @property
> 82:     def ignore_span(self) -> tuple[int, int]:
  83:         """0-based [start, end) span hidden from body scans."""
  84:         if self.envelope is None or self.is_sidecar:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 96

Severity: `minor`
Symbol: `Document.body_digest`
Message: Function Document.body_digest is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  94:         return self.lines[: self.envelope.start] + self.lines[self.envelope.end :]
  95: 
> 96:     def body_digest(self) -> str:
  97:         """SHA-256 of host content outside the envelope, LF-normalized."""
  98:         if self.is_sidecar:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 103

Severity: `minor`
Symbol: `Document.payload_digest`
Message: Function Document.payload_digest is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  101:         return hashlib.sha256("\n".join(self.body_lines()).encode("utf-8")).hexdigest()
  102: 
> 103:     def payload_digest(self) -> str:
  104:         """SHA-256 of the canonical serialization of the payload."""
  105:         return hashlib.sha256(canonical_yaml(self.data or {}).encode("utf-8")).hexdigest()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 117

Severity: `minor`
Symbol: `Document.diag`
Message: Function Document.diag is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  115:         return (self.envelope.payload_start + line, col + self.envelope.col_offset)
  116: 
> 117:     def diag(self, path: tuple, code: str, message: str, severity: str = "error",
  118:              line: Optional[int] = None, col: Optional[int] = None) -> Diagnostic:
  119:         """Build a diagnostic anchored at a payload path (or explicit position)."""
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 163

Severity: `minor`
Symbol: `Document.save`
Message: Function Document.save is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  161:                                           "refusing to write: content outside the envelope would change")])
  162: 
> 163:     def save(self, payload: dict, style: Optional[str] = None) -> str:
  164:         """Atomically write ``payload`` into the envelope; return the new text."""
  165:         text = self.render(payload, style)
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 11: `suspicious_short_functions` at line 169

Severity: `minor`
Symbol: `Document.copy_payload`
Message: Function Document.copy_payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  167:         return text
  168: 
> 169:     def copy_payload(self) -> dict:
  170:         """Deep copy of the current payload (empty dict when unparsed)."""
  171:         return copy.deepcopy(self.payload or {})
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `suspicious_short_functions` at line 187

Severity: `minor`
Symbol: `canonical_yaml`
Message: Function canonical_yaml is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  185: 
  186: 
> 187: def canonical_yaml(root: dict, forbid: Optional[str] = None) -> str:
  188:     """Serialize a root mapping in canonical order."""
  189:     return yamlsub.dumps(root, order=make_order(root), forbid=forbid)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 13: `silent_failures` at line 195

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  193:     try:
  194:         return os.path.relpath(path, Path.cwd()).replace("\\", "/")
> 195:     except ValueError:
  196:         return str(path).replace("\\", "/")
  197: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 14: `silent_failures` at line 211

Severity: `serious`
Symbol: `atomic_write`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  209:             try:
  210:                 os.chmod(tmp, path.stat().st_mode)
> 211:             except OSError:
  212:                 pass
  213:         os.replace(tmp, path)
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 15: `broad_exceptions` at line 214

Severity: `serious`
Symbol: `atomic_write`
Message: Broad exception handler catches BaseException.
Remediation: Catch specific domain exceptions or convert known library exceptions at the boundary.

Evidence:
```text
  212:                 pass
  213:         os.replace(tmp, path)
> 214:     except BaseException:
  215:         if os.path.exists(tmp):
  216:             os.unlink(tmp)
```
Details:
```json
{
  "handler": "BaseException"
}
```

#### Issue 16: `silent_failures` at line 249

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  247:     try:
  248:         parsed = yamlsub.parse(env.payload, lenient=lenient)
> 249:     except yamlsub.YAMLError as exc:
  250:         doc.issues.append(Diagnostic(doc.display, env.payload_start + exc.line, exc.col + env.col_offset,
  251:                                      "error", "E_YAML", "-", exc.message))
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 17: `suspicious_short_functions` at line 324

Severity: `minor`
Symbol: `new_sidecar_text`
Message: Function new_sidecar_text is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  322: 
  323: 
> 324: def new_sidecar_text(payload: dict) -> str:
  325:     """Canonical text for a brand-new sidecar file."""
  326:     return canonical_yaml({"somnus": payload})
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

### `somnus/ids.py`

| Metric | Value |
|---|---:|
| Lines | 128 |
| Code lines | 98 |
| Classes | 0 |
| Functions | 12 |
| Imports | 9 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 6 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Identifier minting and parsing: RFC 9562 UUIDv7, Somnus URNs, slugs."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import os
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 52

Severity: `minor`
Symbol: `new_artifact_urn`
Message: Function new_artifact_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  50: 
  51: 
> 52: def new_artifact_urn() -> str:
  53:     """Return a freshly minted ``urn:somnus:artifact:<uuidv7>``."""
  54:     return f"urn:somnus:artifact:{uuid7()}"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 57

Severity: `minor`
Symbol: `parse_urn`
Message: Function parse_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  55: 
  56: 
> 57: def parse_urn(urn: str) -> tuple[str, str]:
  58:     """Split a Somnus URN into (kind, key); raise ValueError when malformed."""
  59:     m = SOMNUS_URN_RE.match(urn)
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 65

Severity: `minor`
Symbol: `is_artifact_urn`
Message: Function is_artifact_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  63: 
  64: 
> 65: def is_artifact_urn(value: str) -> bool:
  66:     """Return True for a lowercase ``urn:somnus:artifact:<uuid>``."""
  67:     return bool(ARTIFACT_URN_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 70

Severity: `minor`
Symbol: `is_example_urn`
Message: Function is_example_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  68: 
  69: 
> 70: def is_example_urn(value: str) -> bool:
  71:     """Return True for a fixture-only ``urn:somnus:example:*`` identifier."""
  72:     return bool(EXAMPLE_URN_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 75

Severity: `minor`
Symbol: `is_external_ref`
Message: Function is_external_ref is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  73: 
  74: 
> 75: def is_external_ref(value: str) -> bool:
  76:     """Return True for DOI, HTTP(S), or non-Somnus URN references."""
  77:     return bool(EXTERNAL_REF_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 80

Severity: `minor`
Symbol: `is_reference_string`
Message: Function is_reference_string is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  78: 
  79: 
> 80: def is_reference_string(value: str) -> bool:
  81:     """Return True when ``value`` is a Somnus URN or an external reference."""
  82:     return bool(SOMNUS_URN_RE.match(value)) or is_external_ref(value)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 85

Severity: `minor`
Symbol: `uuid_version`
Message: Function uuid_version is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  83: 
  84: 
> 85: def uuid_version(urn: str) -> Optional[int]:
  86:     """Return the UUID version nibble of an artifact URN, or None."""
  87:     m = ARTIFACT_URN_RE.match(urn)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 126

Severity: `minor`
Symbol: `is_local_id`
Message: Function is_local_id is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  124: 
  125: 
> 126: def is_local_id(value: str) -> bool:
  127:     """Return True for a valid local region/claim/relation identifier."""
  128:     return bool(LOCAL_ID_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

### `somnus/infer.py`

| Metric | Value |
|---|---:|
| Lines | 145 |
| Code lines | 126 |
| Classes | 1 |
| Functions | 3 |
| Imports | 6 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 18 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Heuristic title and classification inference for ``somnus stamp``."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import ast
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 97

Severity: `minor`
Symbol: `infer_title`
Message: Function infer_title has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  95: 
  96: 
> 97: def infer_title(path: Path, lines: Sequence[str]) -> str:
  98:     """Infer a human title from headings, TeX titles, docstrings, or the filename."""
  99:     suffix = path.suffix.lower()
```
Details:
```json
{
  "complexity": 18,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 121

Severity: `serious`
Symbol: `infer_title`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  119:         try:
  120:             doc = ast.get_docstring(ast.parse("\n".join(lines) + "\n"))
> 121:         except SyntaxError:
  122:             doc = None
  123:         if doc and doc.strip():
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `suspicious_short_functions` at line 140

Severity: `minor`
Symbol: `infer`
Message: Function infer is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  138: 
  139: 
> 140: def infer(path: Path, lines: Sequence[str], type_override: Optional[str] = None,
  141:           title_override: Optional[str] = None) -> Inference:
  142:     """Infer title and classification defaults for an unmanaged file."""
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

### `somnus/model/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 1 |
| Code lines | 1 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/model/lifecycle.py`

| Metric | Value |
|---|---:|
| Lines | 112 |
| Code lines | 93 |
| Classes | 0 |
| Functions | 6 |
| Imports | 4 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 12 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Lifecycle transition state machine (SPEC Â§7)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 27

Severity: `minor`
Symbol: `is_abandonment`
Message: Function is_abandonment is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  25: 
  26: 
> 27: def is_abandonment(current: str, target: str) -> bool:
  28:     """Work abandoned before it became current."""
  29:     return target == "archived" and current in ABANDONABLE
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 32

Severity: `minor`
Symbol: `is_reactivation`
Message: Function is_reactivation is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  30: 
  31: 
> 32: def is_reactivation(current: str, target: str) -> bool:
  33:     """A retired artifact returned to active use."""
  34:     return target == "active" and current in REACTIVATABLE
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 59

Severity: `minor`
Symbol: `now_utc`
Message: Function now_utc is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  57: 
  58: 
> 59: def now_utc() -> str:
  60:     """Current instant as an RFC 3339 UTC timestamp with seconds precision."""
  61:     return datetime.now(timezone.utc).replace(microsecond=0).isoformat()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `silent_failures` at line 111

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  109:     try:
  110:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 111:     except ValueError:
  112:         return None
```
Details:
```json
{
  "handler_body_length": 1
}
```

### `somnus/model/schema.py`

| Metric | Value |
|---|---:|
| Lines | 601 |
| Code lines | 503 |
| Classes | 11 |
| Functions | 9 |
| Imports | 5 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 23 |

#### Issue 1: `unused_imports` at line 8

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  6: """
  7: 
> 8: from __future__ import annotations
  9: 
  10: from dataclasses import dataclass, field
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_classes` at line 33

Severity: `serious`
Symbol: `Str`
Message: Class Str is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  31: 
  32: @dataclass(frozen=True)
> 33: class Str:
  34:     """String node; optional vocabulary, full-match pattern, or format."""
  35: 
```
Details:
```json
{
  "line_count": 5,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 3: `suspicious_short_classes` at line 44

Severity: `serious`
Symbol: `Int`
Message: Class Int is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  42: 
  43: @dataclass(frozen=True)
> 44: class Int:
  45:     """Integer node (booleans are not integers)."""
  46: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 4: `suspicious_short_classes` at line 52

Severity: `serious`
Symbol: `Num`
Message: Class Num is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  50: 
  51: @dataclass(frozen=True)
> 52: class Num:
  53:     """Finite number node (integer or decimal)."""
  54: 
```
Details:
```json
{
  "line_count": 3,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 5: `missing_docstrings` at line 61

Severity: `minor`
Symbol: `Bool`
Message: Class Bool is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  59: 
  60: @dataclass(frozen=True)
> 61: class Bool:
  62:     """Boolean node."""
  63: 
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 6: `suspicious_short_classes` at line 61

Severity: `serious`
Symbol: `Bool`
Message: Class Bool is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  59: 
  60: @dataclass(frozen=True)
> 61: class Bool:
  62:     """Boolean node."""
  63: 
```
Details:
```json
{
  "line_count": 1,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 7: `suspicious_short_classes` at line 68

Severity: `serious`
Symbol: `AnyValue`
Message: Class AnyValue is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  66: 
  67: @dataclass(frozen=True)
> 68: class AnyValue:
  69:     """Open JSON-compatible value (extension data, claim values)."""
  70: 
```
Details:
```json
{
  "line_count": 1,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 8: `suspicious_short_classes` at line 75

Severity: `serious`
Symbol: `Arr`
Message: Class Arr is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  73: 
  74: @dataclass(frozen=True)
> 75: class Arr:
  76:     """Array node with an item schema."""
  77: 
```
Details:
```json
{
  "line_count": 4,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 9: `suspicious_short_classes` at line 85

Severity: `serious`
Symbol: `Field`
Message: Class Field is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  83: 
  84: @dataclass(frozen=True)
> 85: class Field:
  86:     """One declared member of an object."""
  87: 
```
Details:
```json
{
  "line_count": 4,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 10: `suspicious_short_functions` at line 102

Severity: `minor`
Symbol: `Obj.get`
Message: Function Obj.get is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  100:     doc: str = ""
  101: 
> 102:     def get(self, key: str) -> Optional[Field]:
  103:         """Return the declared field named ``key``."""
  104:         for f in self.fields:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 11: `suspicious_short_functions` at line 110

Severity: `minor`
Symbol: `Obj.order`
Message: Function Obj.order is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  108: 
  109:     @property
> 110:     def order(self) -> list[str]:
  111:         """Canonical member order."""
  112:         return [f.name for f in self.fields]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `suspicious_short_classes` at line 116

Severity: `serious`
Symbol: `MapOf`
Message: Class MapOf is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  114: 
  115: @dataclass(frozen=True)
> 116: class MapOf:
  117:     """Open-keyed mapping whose keys match a pattern and values share a schema."""
  118: 
```
Details:
```json
{
  "line_count": 3,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 13: `suspicious_short_classes` at line 145

Severity: `serious`
Symbol: `Union_`
Message: Class Union_ is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  143: 
  144: @dataclass(frozen=True)
> 145: class Union_:
  146:     """Either a string or an object (sidecar binding targets)."""
  147: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 14: `suspicious_short_functions` at line 155

Severity: `minor`
Symbol: `F`
Message: Function F is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  153: 
  154: 
> 155: def F(name: str, node: Node, required: bool = False, doc: str = "") -> Field:
  156:     """Shorthand constructor for ``Field``."""
  157:     return Field(name, node, required, doc)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 15: `suspicious_short_functions` at line 160

Severity: `minor`
Symbol: `enum`
Message: Function enum is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  158: 
  159: 
> 160: def enum(values: Sequence[str], doc: str = "") -> Str:
  161:     """Shorthand for a vocabulary-constrained string."""
  162:     return Str(enum=tuple(values), doc=doc)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 16: `type_hint_gaps` at line 542

Severity: `minor`
Symbol: `make_order`
Message: Function make_order has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  540: 
  541: 
> 542: def make_order(payload: Optional[dict] = None):
  543:     """Build the serializer ``order`` callback, aware of declared profiles."""
  544:     profiles: dict[str, str] = {}
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 17: `missing_docstrings` at line 551

Severity: `minor`
Symbol: `make_order.order`
Message: Function make_order.order is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  549:                 profiles[decl["key"]] = decl["schema"]
  550: 
> 551:     def order(path: tuple) -> Optional[list[str]]:
  552:         node = node_at(path, profiles)
  553:         if isinstance(node, Union_):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 18: `complexity` at line 562

Severity: `minor`
Symbol: `describe`
Message: Function describe has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  560: 
  561: 
> 562: def describe(node: Any) -> str:
  563:     """Return a short human type description of a node."""
  564:     if isinstance(node, Str):
```
Details:
```json
{
  "complexity": 23,
  "maximum": 12
}
```

### `somnus/model/validate.py`

| Metric | Value |
|---|---:|
| Lines | 832 |
| Code lines | 734 |
| Classes | 3 |
| Functions | 17 |
| Imports | 16 |
| Local dependencies | 8 |
| Missing imports | 0 |
| Max complexity | 106 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Multi-stage validation pipeline: carrier, core, semantic, canon (SPEC Â§19)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import ast
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 51

Severity: `minor`
Symbol: `Resolver.add_payload`
Message: Function Resolver.add_payload has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  49:     open_conflicts: dict = field(default_factory=dict)  # artifact id -> list of conflict kinds
  50: 
> 51:     def add_payload(self, somnus: dict) -> None:
  52:         """Register facts from a parsed payload (check-set member)."""
  53:         aid = somnus.get("id")
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 81

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  79:     try:
  80:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 81:     except ValueError:
  82:         return None
  83: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `missing_docstrings` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 5: `suspicious_short_functions` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 6: `type_hint_gaps` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 7: `missing_docstrings` at line 96

Severity: `minor`
Symbol: `_Run.err`
Message: Function _Run.err is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  94:         self.out: list[Diagnostic] = []
  95: 
> 96:     def err(self, path: tuple, code: str, message: str) -> None:
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 96

Severity: `minor`
Symbol: `_Run.err`
Message: Function _Run.err is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  94:         self.out: list[Diagnostic] = []
  95: 
> 96:     def err(self, path: tuple, code: str, message: str) -> None:
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `missing_docstrings` at line 99

Severity: `minor`
Symbol: `_Run.warn`
Message: Function _Run.warn is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
> 99:     def warn(self, path: tuple, code: str, message: str) -> None:
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `suspicious_short_functions` at line 99

Severity: `minor`
Symbol: `_Run.warn`
Message: Function _Run.warn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
> 99:     def warn(self, path: tuple, code: str, message: str) -> None:
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 11: `missing_docstrings` at line 102

Severity: `minor`
Symbol: `_Run.at`
Message: Function _Run.at is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
> 102:     def at(self, line: int, col: int, code: str, message: str, severity: str = "error") -> None:
  103:         self.out.append(Diagnostic(self.doc.display, line, col, severity, code, "-", message))
  104: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 12: `suspicious_short_functions` at line 102

Severity: `minor`
Symbol: `_Run.at`
Message: Function _Run.at is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
> 102:     def at(self, line: int, col: int, code: str, message: str, severity: str = "error") -> None:
  103:         self.out.append(Diagnostic(self.doc.display, line, col, severity, code, "-", message))
  104: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 13: `complexity` at line 109

Severity: `minor`
Symbol: `walk`
Message: Function walk has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  107: 
  108: 
> 109: def walk(run: _Run, node: Any, value: Any, path: tuple) -> None:
  110:     """Check ``value`` against a schema node, recording E_SCHEMA findings."""
  111:     if isinstance(node, S.Str):
```
Details:
```json
{
  "complexity": 54,
  "maximum": 12
}
```

#### Issue 14: `silent_failures` at line 130

Severity: `serious`
Symbol: `walk`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  128:                 try:
  129:                     date.fromisoformat(value)
> 130:                 except ValueError:
  131:                     ok = False
  132:             if not ok:
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 15: `complexity` at line 278

Severity: `minor`
Symbol: `consistency`
Message: Function consistency has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  276: 
  277: 
> 278: def consistency(run: _Run, somnus: dict) -> None:
  279:     """Intra-document conditional requirements (core level)."""
  280:     P = ("somnus",)
```
Details:
```json
{
  "complexity": 106,
  "maximum": 12
}
```

#### Issue 16: `missing_docstrings` at line 438

Severity: `minor`
Symbol: `find_cycle.visit`
Message: Function find_cycle.visit is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  436:     stack: list[str] = []
  437: 
> 438:     def visit(node: str) -> Optional[list[str]]:
  439:         color[node] = GREY
  440:         stack.append(node)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 17: `complexity` at line 500

Severity: `minor`
Symbol: `marker_regions`
Message: Function marker_regions has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  498: 
  499: 
> 500: def marker_regions(run: _Run, somnus: dict) -> Optional[MarkerScan]:
  501:     """Pair body markers and match them against marker-selector regions."""
  502:     doc = run.doc
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 18: `complexity` at line 563

Severity: `minor`
Symbol: `references`
Message: Function references has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  561: 
  562: 
> 563: def references(run: _Run, somnus: dict, resolver: Resolver) -> None:
  564:     """Resolve every reference against this document, the check set, and the registry."""
  565:     found: list = []
```
Details:
```json
{
  "complexity": 42,
  "maximum": 12
}
```

#### Issue 19: `silent_failures` at line 592

Severity: `serious`
Symbol: `references`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  590:         try:
  591:             kind, _ = ids.parse_urn(ref)
> 592:         except ValueError:
  593:             run.err(path, "E_REFERENCE", f"{ref!r} is not resolvable")
  594:             continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 20: `complexity` at line 618

Severity: `minor`
Symbol: `selectors`
Message: Function selectors has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  616: 
  617: 
> 618: def selectors(run: _Run, somnus: dict) -> None:
  619:     """Resolve non-marker region selectors."""
  620:     doc = run.doc
```
Details:
```json
{
  "complexity": 36,
  "maximum": 12
}
```

#### Issue 21: `silent_failures` at line 652

Severity: `serious`
Symbol: `selectors`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  650:             try:
  651:                 tree = ast.parse("\n".join(doc.body_lines()) + "\n")
> 652:             except SyntaxError as exc:
  653:                 run.err(sp, "E_REGION", f"cannot parse Python source: {exc.msg}")
  654:                 continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 22: `silent_failures` at line 667

Severity: `serious`
Symbol: `selectors`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  665:             try:
  666:                 tree = json.loads(target.read_text(encoding="utf-8"))
> 667:             except (OSError, ValueError) as exc:
  668:                 run.err(sp, "E_REGION", f"primary target is not readable JSON: {exc}")
  669:                 continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 23: `complexity` at line 691

Severity: `minor`
Symbol: `semantic_policies`
Message: Function semantic_policies has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  689: 
  690: 
> 691: def semantic_policies(run: _Run, somnus: dict) -> None:
  692:     """Resources, constraint languages, and required capabilities."""
  693:     P = ("somnus",)
```
Details:
```json
{
  "complexity": 22,
  "maximum": 12
}
```

#### Issue 24: `complexity` at line 760

Severity: `minor`
Symbol: `validate`
Message: Function validate has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  758: 
  759: 
> 760: def validate(doc: Document, level: str = "core", resolver: Optional[Resolver] = None) -> list[Diagnostic]:
  761:     """Run the pipeline up to ``level``; later stages run only when earlier ones pass."""
  762:     if level not in LEVEL_RANK:
```
Details:
```json
{
  "complexity": 23,
  "maximum": 12
}
```

#### Issue 25: `complexity` at line 815

Severity: `minor`
Symbol: `permits_use`
Message: Function permits_use has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  813: 
  814: 
> 815: def permits_use(somnus: dict, use: str, region_id: Optional[str] = None) -> bool:
  816:     """Header-level usage decision (external policy may be stricter)."""
  817:     access = somnus.get("access") if isinstance(somnus.get("access"), dict) else {}
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

### `somnus/model/vocab.py`

| Metric | Value |
|---|---:|
| Lines | 75 |
| Code lines | 68 |
| Classes | 0 |
| Functions | 0 |
| Imports | 1 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Controlled vocabularies of core schema 2.0.0 (SPEC Â§5, Â§7â€“Â§15)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: CATEGORIES = ("research", "engineering", "operations", "governance", "context", "archive")
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

### `somnus/output.py`

| Metric | Value |
|---|---:|
| Lines | 92 |
| Code lines | 69 |
| Classes | 2 |
| Functions | 8 |
| Imports | 4 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 15 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Diagnostics, compiler-style rendering, tables, and process exit codes."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import sys
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 29

Severity: `minor`
Symbol: `Diagnostic.is_error`
Message: Function Diagnostic.is_error is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  27: 
  28:     @property
> 29:     def is_error(self) -> bool:
  30:         """Return True when the diagnostic is an error rather than a warning."""
  31:         return self.severity == "error"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `missing_docstrings` at line 37

Severity: `minor`
Symbol: `SomnusError.__init__`
Message: Function SomnusError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  35:     """Operation refused; carries diagnostics and the exit code to return."""
  36: 
> 37:     def __init__(self, diagnostics: Sequence[Diagnostic] | str, exit_code: int = EXIT_INVALID):
  38:         if isinstance(diagnostics, str):
  39:             diagnostics = [Diagnostic("-", 0, 0, "error", "E_IO", "-", diagnostics)]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `type_hint_gaps` at line 37

Severity: `minor`
Symbol: `SomnusError.__init__`
Message: Function SomnusError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  35:     """Operation refused; carries diagnostics and the exit code to return."""
  36: 
> 37:     def __init__(self, diagnostics: Sequence[Diagnostic] | str, exit_code: int = EXIT_INVALID):
  38:         if isinstance(diagnostics, str):
  39:             diagnostics = [Diagnostic("-", 0, 0, "error", "E_IO", "-", diagnostics)]
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `suspicious_short_functions` at line 58

Severity: `minor`
Symbol: `render`
Message: Function render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  56: 
  57: 
> 58: def render(diagnostics: Iterable[Diagnostic], fmt: Literal["text", "tsv"] = "text") -> str:
  59:     """Render diagnostics sorted by path, line, column; one per line."""
  60:     ordered = sorted(diagnostics, key=lambda d: (d.path, d.line, d.col, d.code, d.field))
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 64

Severity: `minor`
Symbol: `has_errors`
Message: Function has_errors is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  62: 
  63: 
> 64: def has_errors(diagnostics: Iterable[Diagnostic]) -> bool:
  65:     """Return True when any diagnostic is an error."""
  66:     return any(d.is_error for d in diagnostics)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `complexity` at line 69

Severity: `minor`
Symbol: `table`
Message: Function table has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  67: 
  68: 
> 69: def table(headers: Sequence[str], rows: Sequence[Sequence[object]], fmt: Literal["text", "tsv"] = "text",
  70:           max_width: int = 60) -> str:
  71:     """Format rows as an aligned plain-text table or header-first TSV."""
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 8: `missing_docstrings` at line 80

Severity: `minor`
Symbol: `table.line`
Message: Function table.line is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  78:         for i, c in enumerate(r):
  79:             widths[i] = max(widths[i], len(c))
> 80:     def line(values: Sequence[str]) -> str:
  81:         return "  ".join(v.ljust(widths[i]) for i, v in enumerate(values)).rstrip()
  82:     out = [line(headers), line(["-" * w for w in widths])]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 9: `suspicious_short_functions` at line 80

Severity: `minor`
Symbol: `table.line`
Message: Function table.line is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  78:         for i, c in enumerate(r):
  79:             widths[i] = max(widths[i], len(c))
> 80:     def line(values: Sequence[str]) -> str:
  81:         return "  ".join(v.ljust(widths[i]) for i, v in enumerate(values)).rstrip()
  82:     out = [line(headers), line(["-" * w for w in widths])]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 87

Severity: `minor`
Symbol: `emit`
Message: Function emit is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  85: 
  86: 
> 87: def emit(text: str, stream=None) -> None:
  88:     """Write text plus newline to stdout (or stream), skipping empty output."""
  89:     if not text:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 11: `type_hint_gaps` at line 87

Severity: `minor`
Symbol: `emit`
Message: Function emit has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  85: 
  86: 
> 87: def emit(text: str, stream=None) -> None:
  88:     """Write text plus newline to stdout (or stream), skipping empty output."""
  89:     if not text:
```
Details:
```json
{
  "missing_hints": [
    "param:stream"
  ]
}
```

### `somnus/regions.py`

| Metric | Value |
|---|---:|
| Lines | 210 |
| Code lines | 184 |
| Classes | 2 |
| Functions | 5 |
| Imports | 7 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 28 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """In-body region markers: lexical scanning, pairing, and registry sync (SPEC Â§13)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import io
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 37

Severity: `minor`
Symbol: `markdown_code_mask`
Message: Function markdown_code_mask has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  35: 
  36: 
> 37: def markdown_code_mask(lines: Sequence[str]) -> list[bool]:
  38:     """Mark lines inside fenced code (fences included) and indented code blocks."""
  39:     mask = [False] * len(lines)
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 81

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  79:                 if not lines[row - 1][:col].strip():
  80:                     eligible.add(row - 1)
> 81:     except (tokenize.TokenError, IndentationError, SyntaxError):
  82:         return None
  83:     return eligible
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `complexity` at line 103

Severity: `minor`
Symbol: `scan_markers`
Message: Function scan_markers has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  101: 
  102: 
> 103: def scan_markers(lines: Sequence[str], style: tuple, ignore: tuple[int, int] = (-1, -1),
  104:                  host: Optional[str] = None) -> MarkerScan:
  105:     """Scan live region markers, pairing them with a stack.
```
Details:
```json
{
  "complexity": 28,
  "maximum": 12
}
```

#### Issue 5: `complexity` at line 190

Severity: `minor`
Symbol: `sync_registry`
Message: Function sync_registry has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  188: 
  189: 
> 190: def sync_registry(somnus: dict, scan: MarkerScan) -> tuple[list[str], list[str]]:
  191:     """Register unregistered marker ranges; return (added ids, registered-but-missing ids).
  192: 
```
Details:
```json
{
  "complexity": 13,
  "maximum": 12
}
```

### `somnus/yamlsub.py`

| Metric | Value |
|---|---:|
| Lines | 753 |
| Code lines | 650 |
| Classes | 6 |
| Functions | 30 |
| Imports | 5 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 17 |

#### Issue 1: `unused_imports` at line 13

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  11: """
  12: 
> 13: from __future__ import annotations
  14: 
  15: import math
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `suspicious_short_functions` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 4: `type_hint_gaps` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `missing_docstrings` at line 59

Severity: `minor`
Symbol: `_Line`
Message: Class _Line is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  57: 
  58: @dataclass
> 59: class _Line:
  60:     no: int  # 1-based payload line number
  61:     indent: int
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 6: `missing_docstrings` at line 206

Severity: `minor`
Symbol: `_Flow`
Message: Class _Flow is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  204: 
  205: 
> 206: class _Flow:
  207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 7: `missing_docstrings` at line 207

Severity: `minor`
Symbol: `_Flow.__init__`
Message: Function _Flow.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  205: 
  206: class _Flow:
> 207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
  209:         self.i = 0
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `type_hint_gaps` at line 207

Severity: `minor`
Symbol: `_Flow.__init__`
Message: Function _Flow.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  205: 
  206: class _Flow:
> 207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
  209:         self.i = 0
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 9: `missing_docstrings` at line 216

Severity: `minor`
Symbol: `_Flow.err`
Message: Function _Flow.err is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  214:         self.path = path
  215: 
> 216:     def err(self, msg: str) -> YAMLError:
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `suspicious_short_functions` at line 216

Severity: `minor`
Symbol: `_Flow.err`
Message: Function _Flow.err is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  214:         self.path = path
  215: 
> 216:     def err(self, msg: str) -> YAMLError:
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 11: `missing_docstrings` at line 219

Severity: `minor`
Symbol: `_Flow.ws`
Message: Function _Flow.ws is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
> 219:     def ws(self) -> None:
  220:         while self.i < len(self.s) and self.s[self.i] in " \t":
  221:             self.i += 1
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 12: `suspicious_short_functions` at line 219

Severity: `minor`
Symbol: `_Flow.ws`
Message: Function _Flow.ws is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
> 219:     def ws(self) -> None:
  220:         while self.i < len(self.s) and self.s[self.i] in " \t":
  221:             self.i += 1
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 13: `missing_docstrings` at line 223

Severity: `minor`
Symbol: `_Flow.value`
Message: Function _Flow.value is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  221:             self.i += 1
  222: 
> 223:     def value(self, path: Path) -> Any:
  224:         self.ws()
  225:         if self.i >= len(self.s):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 14: `missing_docstrings` at line 247

Severity: `minor`
Symbol: `_Flow.seq`
Message: Function _Flow.seq is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  245:         return _plain_scalar(token, self.line, self.col0 + start + 1, self.lenient)
  246: 
> 247:     def seq(self, path: Path) -> list:
  248:         self.i += 1
  249:         items: list = []
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 15: `missing_docstrings` at line 269

Severity: `minor`
Symbol: `_Flow.key`
Message: Function _Flow.key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  267:                 raise self.err("trailing comma in flow sequence")
  268: 
> 269:     def key(self) -> str:
  270:         self.ws()
  271:         if self.i >= len(self.s):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 16: `missing_docstrings` at line 288

Severity: `minor`
Symbol: `_Flow.mapping`
Message: Function _Flow.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  286:         return token
  287: 
> 288:     def mapping(self, path: Path) -> dict:
  289:         self.i += 1
  290:         result: dict = {}
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 17: `missing_docstrings` at line 326

Severity: `minor`
Symbol: `_Parser`
Message: Class _Parser is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  324: 
  325: 
> 326: class _Parser:
  327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 18: `missing_docstrings` at line 327

Severity: `minor`
Symbol: `_Parser.__init__`
Message: Function _Parser.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  325: 
  326: class _Parser:
> 327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
  329:             text = text[1:]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 19: `type_hint_gaps` at line 327

Severity: `minor`
Symbol: `_Parser.__init__`
Message: Function _Parser.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  325: 
  326: class _Parser:
> 327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
  329:             text = text[1:]
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 20: `missing_docstrings` at line 337

Severity: `minor`
Symbol: `_Parser.peek`
Message: Function _Parser.peek is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  335: 
  336:     # -- line access
> 337:     def peek(self) -> Optional[_Line]:
  338:         if self.pending is not None:
  339:             return self.pending
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 21: `missing_docstrings` at line 360

Severity: `minor`
Symbol: `_Parser.take`
Message: Function _Parser.take is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  358:         return None
  359: 
> 360:     def take(self) -> _Line:
  361:         line = self.peek()
  362:         assert line is not None
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 22: `suspicious_short_functions` at line 360

Severity: `minor`
Symbol: `_Parser.take`
Message: Function _Parser.take is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  358:         return None
  359: 
> 360:     def take(self) -> _Line:
  361:         line = self.peek()
  362:         assert line is not None
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 23: `missing_docstrings` at line 367

Severity: `minor`
Symbol: `_Parser.document`
Message: Function _Parser.document is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  365: 
  366:     # -- entry
> 367:     def document(self) -> Any:
  368:         first = self.peek()
  369:         if first is None:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 24: `missing_docstrings` at line 379

Severity: `minor`
Symbol: `_Parser.block`
Message: Function _Parser.block is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  377:         return value
  378: 
> 379:     def block(self, indent: int, path: Path) -> Any:
  380:         line = self.peek()
  381:         assert line is not None
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 25: `missing_docstrings` at line 386

Severity: `minor`
Symbol: `_Parser.mapping`
Message: Function _Parser.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  384:         return self.mapping(line.indent, path)
  385: 
> 386:     def mapping(self, indent: int, path: Path) -> dict:
  387:         result: dict = {}
  388:         while True:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 26: `missing_docstrings` at line 404

Severity: `minor`
Symbol: `_Parser.value_after_key`
Message: Function _Parser.value_after_key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  402:             result[key] = self.value_after_key(line, indent, rest, rest_col, child)
  403: 
> 404:     def value_after_key(self, line: _Line, indent: int, rest: str, rest_col: int, path: Path) -> Any:
  405:         if rest:
  406:             if rest[0] in "|>":
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 27: `complexity` at line 416

Severity: `minor`
Symbol: `_Parser.sequence`
Message: Function _Parser.sequence has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  414:         raise YAMLError("missing value; null is forbidden", line.no, rest_col)
  415: 
> 416:     def sequence(self, indent: int, path: Path) -> list:
  417:         items: list = []
  418:         while True:
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 28: `missing_docstrings` at line 416

Severity: `minor`
Symbol: `_Parser.sequence`
Message: Function _Parser.sequence is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  414:         raise YAMLError("missing value; null is forbidden", line.no, rest_col)
  415: 
> 416:     def sequence(self, indent: int, path: Path) -> list:
  417:         items: list = []
  418:         while True:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 29: `missing_docstrings` at line 450

Severity: `minor`
Symbol: `_Parser.split_key`
Message: Function _Parser.split_key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  448:             items.append(self.inline(rest, line.no, inner_indent + 1, child))
  449: 
> 450:     def split_key(self, line: _Line) -> tuple[str, str, int, int]:
  451:         c = line.content
  452:         key_col = line.indent + 1
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 30: `missing_docstrings` at line 480

Severity: `minor`
Symbol: `_Parser.inline`
Message: Function _Parser.inline is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  478:         return key, rest, key_col, rest_col
  479: 
> 480:     def inline(self, s: str, line_no: int, col: int, path: Path) -> Any:
  481:         self.spans.setdefault(path, (line_no, col))
  482:         ch = s[0]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 31: `complexity` at line 498

Severity: `minor`
Symbol: `_Parser.block_scalar`
Message: Function _Parser.block_scalar has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  496:         return _plain_scalar(s, line_no, col, self.lenient)
  497: 
> 498:     def block_scalar(self, header: str, line: _Line, parent_indent: int, col: int) -> str:
  499:         m = re.fullmatch(r"([|>])([-+]?)", header)
  500:         if not m:
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 32: `missing_docstrings` at line 498

Severity: `minor`
Symbol: `_Parser.block_scalar`
Message: Function _Parser.block_scalar is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  496:         return _plain_scalar(s, line_no, col, self.lenient)
  497: 
> 498:     def block_scalar(self, header: str, line: _Line, parent_indent: int, col: int) -> str:
  499:         m = re.fullmatch(r"([|>])([-+]?)", header)
  500:         if not m:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 33: `silent_failures` at line 578

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  576:         reader = _read_double if s[0] == '"' else _read_single
  577:         _, end = reader(s, 0, 0, 0)
> 578:     except YAMLError:
  579:         return False
  580:     return s[end : end + 1] == ":" and (end + 1 == len(s) or s[end + 1] == " ")
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 34: `suspicious_short_functions` at line 586

Severity: `minor`
Symbol: `parse`
Message: Function parse is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  584: 
  585: 
> 586: def parse(text: str, *, lenient: bool = False) -> Parsed:
  587:     """Parse a restricted-YAML document, returning data and source spans."""
  588:     parser = _Parser(text, lenient)
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 35: `suspicious_short_functions` at line 594

Severity: `minor`
Symbol: `loads`
Message: Function loads is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  592: 
  593: 
> 594: def loads(text: str, *, lenient: bool = False) -> Any:
  595:     """Parse a restricted-YAML document and return its value."""
  596:     return parse(text, lenient=lenient).data
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 36: `missing_docstrings` at line 662

Severity: `minor`
Symbol: `_Dumper`
Message: Class _Dumper is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  660: 
  661: 
> 662: class _Dumper:
  663:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  664:         self.order = order
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 37: `missing_docstrings` at line 663

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  661: 
  662: class _Dumper:
> 663:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  664:         self.order = order
  665:         self.forbid = forbid
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 38: `suspicious_short_functions` at line 663

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  661: 
  662: class _Dumper:
> 663:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  664:         self.order = order
  665:         self.forbid = forbid
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 39: `type_hint_gaps` at line 663

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  661: 
  662: class _Dumper:
> 663:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  664:         self.order = order
  665:         self.forbid = forbid
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 40: `missing_docstrings` at line 668

Severity: `minor`
Symbol: `_Dumper.keys`
Message: Function _Dumper.keys is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  666:         self.width = width
  667: 
> 668:     def keys(self, d: dict, path: tuple) -> list:
  669:         declared = list(self.order(path) or []) if self.order else []
  670:         known = [k for k in declared if k in d]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 41: `suspicious_short_functions` at line 668

Severity: `minor`
Symbol: `_Dumper.keys`
Message: Function _Dumper.keys is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  666:         self.width = width
  667: 
> 668:     def keys(self, d: dict, path: tuple) -> list:
  669:         declared = list(self.order(path) or []) if self.order else []
  670:         known = [k for k in declared if k in d]
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 42: `missing_docstrings` at line 673

Severity: `minor`
Symbol: `_Dumper.flow`
Message: Function _Dumper.flow is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  671:         return known + [k for k in d if k not in declared]
  672: 
> 673:     def flow(self, items: list) -> str:
  674:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  675: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 43: `suspicious_short_functions` at line 673

Severity: `minor`
Symbol: `_Dumper.flow`
Message: Function _Dumper.flow is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  671:         return known + [k for k in d if k not in declared]
  672: 
> 673:     def flow(self, items: list) -> str:
  674:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  675: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 44: `missing_docstrings` at line 676

Severity: `minor`
Symbol: `_Dumper.mapping`
Message: Function _Dumper.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  674:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  675: 
> 676:     def mapping(self, d: dict, indent: int, path: tuple) -> list[str]:
  677:         lines: list[str] = []
  678:         pad = " " * indent
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 45: `missing_docstrings` at line 694

Severity: `minor`
Symbol: `_Dumper.list_after`
Message: Function _Dumper.list_after is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  692:         return lines
  693: 
> 694:     def list_after(self, head: str, v: list, indent: int, path: tuple) -> list[str]:
  695:         if not v:
  696:             return [head + " []"]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 46: `missing_docstrings` at line 703

Severity: `minor`
Symbol: `_Dumper.sequence`
Message: Function _Dumper.sequence is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  701:         return [head] + self.sequence(v, indent + 2, path)
  702: 
> 703:     def sequence(self, items: list, indent: int, path: tuple) -> list[str]:
  704:         lines: list[str] = []
  705:         pad = " " * indent
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 47: `suspicious_short_functions` at line 729

Severity: `minor`
Symbol: `dumps`
Message: Function dumps is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  727: 
  728: 
> 729: def dumps(value: dict, *, order: Optional[OrderFn] = None, forbid: Optional[str] = None,
  730:           width: int = 88) -> str:
  731:     """Serialize a mapping in canonical form; output always ends with a newline.
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

## Recommended Action Plan

### Serious
- Resolve stubs, placeholder returns, missing imports, suspicious classes, broad handlers, silent failures, test gaps, and dependency cycles before release.

### Minor
- Complete docstrings, type hints, unused import cleanup, duplicate definitions, and complexity reductions.

---

Generated by Python Production Doctor. This tool diagnoses; it does not modify source code.

<style>
.t{background:#141414;border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.45),0 0 0 1px #2a2a2a;margin:22px 0;font-family:Menlo,Monaco,Cascadia Code,Courier New,monospace;overflow:hidden}
.t-hdr{background:#252525;padding:11px 16px;display:flex;align-items:center;border-bottom:1px solid #1e1e1e}
.t-btn{width:13px;height:13px;border-radius:50%;margin-right:8px;flex-shrink:0}.t-btn.r{background:#ff5f57}.t-btn.y{background:#febc2e}.t-btn.g{background:#28c840}
.t-title{color:#888;font-size:12.5px;margin-left:10px;letter-spacing:.4px}.t-tag{margin-left:auto;background:#1e1e1e;border:1px solid #333;color:#777;font-size:10px;padding:2px 8px;border-radius:3px;letter-spacing:1px;text-transform:uppercase}
.t-body{padding:18px 20px;font-size:13px;line-height:1.65;color:#d4d4d4;overflow-x:auto}.prompt{color:#28c840}.dim{color:#777}.info{color:#8ec5fc}.warn{color:#febc2e}.err{color:#ff5f57}.accent{color:#c9a0dc}
</style>

# Python Production Doctor Report

Run ID: `20261011T120504Z`
Project: `C:\Users\trent\OneDrive\Desktop\Treys-Workspace\somnus-metadata\src`
Started: `2026-10-11T12:05:04.905721Z`
Finished: `2026-10-11T12:05:05.467303Z`
Config hash: `ba962456a29c03cea464a25183c1c955f1de718102ef798e14a6522b10426e38`

<div class="t">
  <div class="t-hdr"><div class="t-btn r"></div><div class="t-btn y"></div><div class="t-btn g"></div><span class="t-title">python-production-doctor</span><span class="t-tag">DIAGNOSIS</span></div>
  <div class="t-body">
    <div><span class="prompt">doctor@somnus:~$</span> scan C:\Users\trent\OneDrive\Desktop\Treys-Workspace\somnus-metadata\src</div>
    <div class="out info">files scanned: 46</div>
    <div class="out err">critical: 0</div>
    <div class="out warn">serious: 60</div>
    <div class="out dim">minor: 299 | info: 0</div>
    <div class="out accent">production score: 0/100</div>
  </div>
</div>

## Summary

| Metric | Value |
|---|---:|
| Files scanned | 46 |
| Total issues | 359 |
| Critical issues | 0 |
| Serious issues | 60 |
| Minor issues | 299 |
| Syntax-error files | 0 |
| Missing imports | 0 |
| Dependency cycles | 3 |
| Suspiciously short classes | 11 |
| Suspiciously short functions | 125 |

## Issue Categories

| Category | Count |
|---|---:|
| `broad_exceptions` | 3 |
| `complexity` | 30 |
| `dependency_cycles` | 1 |
| `missing_docstrings` | 65 |
| `security_risks` | 1 |
| `silent_failures` | 42 |
| `stubs` | 2 |
| `suspicious_short_classes` | 11 |
| `suspicious_short_functions` | 125 |
| `type_hint_gaps` | 32 |
| `unused_imports` | 47 |

## Local State Delta

| Delta | Count | Files |
|---|---:|---|
| New | 0 | none |
| Modified | 3 | somnus/document.py, somnus/ids.py, somnus/yamlsub.py |
| Deleted | 0 | none |
| Unchanged | 43 | somnus/__init__.py, somnus/__main__.py, somnus/carriers/__init__.py, somnus/carriers/blockcomment.py, somnus/carriers/linecomment.py, somnus/carriers/markdown.py, somnus/carriers/sidecar.py, somnus/cli.py, somnus/commands/__init__.py, somnus/commands/_common.py, somnus/commands/brief.py, somnus/commands/bump.py |

## Dependency Map

```mermaid
graph TD
    N1["somnus/__init__.py"]
    N2["somnus/__main__.py"]
    N3["somnus/carriers/__init__.py"]
    N4["somnus/carriers/blockcomment.py"]
    N5["somnus/carriers/linecomment.py"]
    N6["somnus/carriers/markdown.py"]
    N7["somnus/carriers/sidecar.py"]
    N8["somnus/cli.py"]
    N9["somnus/commands/__init__.py"]
    N10["somnus/commands/_common.py"]
    N11["somnus/commands/brief.py"]
    N12["somnus/commands/bump.py"]
    N13["somnus/commands/check.py"]
    N14["somnus/commands/edit.py"]
    N15["somnus/commands/fork.py"]
    N16["somnus/commands/index.py"]
    N17["somnus/commands/init.py"]
    N18["somnus/commands/ls.py"]
    N19["somnus/commands/migrate.py"]
    N20["somnus/commands/new.py"]
    N21["somnus/commands/query.py"]
    N22["somnus/commands/regions.py"]
    N23["somnus/commands/schema.py"]
    N24["somnus/commands/stale.py"]
    N25["somnus/commands/stamp.py"]
    N26["somnus/commands/status.py"]
    N27["somnus/config.py"]
    N28["somnus/db/__init__.py"]
    N29["somnus/db/store.py"]
    N30["somnus/document.py"]
    N31["somnus/ids.py"]
    N32["somnus/infer.py"]
    N33["somnus/model/__init__.py"]
    N34["somnus/model/jsonschema_export.py"]
    N35["somnus/model/lifecycle.py"]
    N36["somnus/model/schema.py"]
    N37["somnus/model/validate.py"]
    N38["somnus/model/vocab.py"]
    N39["somnus/output.py"]
    N40["somnus/regions.py"]
    N41["somnus/tui/__init__.py"]
    N42["somnus/tui/app.py"]
    N43["somnus/tui/form.py"]
    N44["somnus/tui/term.py"]
    N45["somnus/tui/widgets.py"]
    N46["somnus/yamlsub.py"]
    N2 --> N8
    N3 --> N4
    N3 --> N5
    N3 --> N6
    N4 --> N3
    N5 --> N3
    N6 --> N3
    N6 --> N40
    N7 --> N3
    N8 --> N1
    N8 --> N33
    N8 --> N39
    N8 --> N10
    N10 --> N1
    N10 --> N1
    N10 --> N28
    N10 --> N32
    N10 --> N37
    N10 --> N39
    N11 --> N1
    N11 --> N10
    N11 --> N39
    N12 --> N10
    N12 --> N35
    N12 --> N39
    N13 --> N1
    N13 --> N10
    N13 --> N37
    N13 --> N39
    N14 --> N10
    N14 --> N39
    N14 --> N42
    N15 --> N1
    N15 --> N1
    N15 --> N10
    N15 --> N35
    N15 --> N39
    N16 --> N10
    N16 --> N39
    N17 --> N1
    N17 --> N1
    N17 --> N10
    N17 --> N28
    N17 --> N39
    N18 --> N10
    N18 --> N28
    N18 --> N39
    N19 --> N1
    N19 --> N1
    N19 --> N6
    N19 --> N10
    N19 --> N27
    N19 --> N32
    N19 --> N33
    N19 --> N33
    N19 --> N37
    N19 --> N39
    N19 --> N40
    N20 --> N1
    N20 --> N1
    N20 --> N10
    N20 --> N28
    N20 --> N35
    N20 --> N39
    N21 --> N10
    N21 --> N28
    N21 --> N39
    N22 --> N10
    N22 --> N35
    N22 --> N39
    N22 --> N40
    N23 --> N1
    N23 --> N1
    N23 --> N10
    N23 --> N33
    N23 --> N39
    N23 --> N34
    N24 --> N1
    N24 --> N10
    N24 --> N39
    N25 --> N1
    N25 --> N10
    N25 --> N39
    N26 --> N1
    N26 --> N10
    N26 --> N35
    N26 --> N39
    N27 --> N33
    N28 --> N29
    N29 --> N1
    N29 --> N1
    N29 --> N33
    N29 --> N37
    N29 --> N39
    N30 --> N1
    N30 --> N3
    N30 --> N7
    N30 --> N36
    N30 --> N39
    N34 --> N1
    N34 --> N33
    N36 --> N1
    N36 --> N33
    N37 --> N1
    N37 --> N7
    N37 --> N30
    N37 --> N33
    N37 --> N33
    N37 --> N39
    N37 --> N40
    N37 --> N30
    N40 --> N31
    N42 --> N10
    N42 --> N28
    N42 --> N35
    N42 --> N39
    N42 --> N43
    N42 --> N44
    N42 --> N45
    N43 --> N33
    N43 --> N37
    N43 --> N39
    N44 --> N45
    C1{"cycle: somnus/carriers/__init__.py -> somnus/carriers/blockcomment.py"}
    C2{"cycle: somnus/carriers/__init__.py -> somnus/carriers/linecomment.py"}
    C3{"cycle: somnus/carriers/__init__.py -> somnus/carriers/markdown.py"}
```

### Missing or Unresolved Imports

| Source | Line | Import | Status |
|---|---:|---|---|
| none | 0 | none | all imports resolved or classified |

### Dependency Cycles

| Cycle |
|---|
| `somnus/carriers/__init__.py -> somnus/carriers/blockcomment.py` |
| `somnus/carriers/__init__.py -> somnus/carriers/linecomment.py` |
| `somnus/carriers/__init__.py -> somnus/carriers/markdown.py` |

## Suspiciously Short Classes

- `somnus/carriers/linecomment.py:105` `HashCarrier`: Class HashCarrier is suspiciously short.
- `somnus/model/schema.py:33` `Str`: Class Str is suspiciously short.
- `somnus/model/schema.py:44` `Int`: Class Int is suspiciously short.
- `somnus/model/schema.py:52` `Num`: Class Num is suspiciously short.
- `somnus/model/schema.py:61` `Bool`: Class Bool is suspiciously short.
- `somnus/model/schema.py:68` `AnyValue`: Class AnyValue is suspiciously short.
- `somnus/model/schema.py:75` `Arr`: Class Arr is suspiciously short.
- `somnus/model/schema.py:85` `Field`: Class Field is suspiciously short.
- `somnus/model/schema.py:116` `MapOf`: Class MapOf is suspiciously short.
- `somnus/model/schema.py:145` `Union_`: Class Union_ is suspiciously short.
- `somnus/tui/form.py:15` `Field`: Class Field is suspiciously short.

## Suspiciously Short Functions

- `somnus/carriers/__init__.py:30` `Envelope.__post_init__`: Function Envelope.__post_init__ is suspiciously short.
- `somnus/carriers/__init__.py:35` `Envelope.payload`: Function Envelope.payload is suspiciously short.
- `somnus/carriers/__init__.py:75` `Carrier.extract`: Function Carrier.extract is suspiciously short.
- `somnus/carriers/__init__.py:79` `Carrier.render`: Function Carrier.render is suspiciously short.
- `somnus/carriers/__init__.py:87` `CarrierError.__init__`: Function CarrierError.__init__ is suspiciously short.
- `somnus/carriers/__init__.py:134` `get`: Function get is suspiciously short.
- `somnus/carriers/__init__.py:141` `is_sidecar_path`: Function is_sidecar_path is suspiciously short.
- `somnus/carriers/__init__.py:146` `sidecar_for`: Function sidecar_for is suspiciously short.
- `somnus/carriers/__init__.py:151` `host_for`: Function host_for is suspiciously short.
- `somnus/carriers/__init__.py:156` `carrier_name_for`: Function carrier_name_for is suspiciously short.
- `somnus/carriers/__init__.py:164` `for_path`: Function for_path is suspiciously short.
- `somnus/carriers/linecomment.py:108` `HashCarrier.__init__`: Function HashCarrier.__init__ is suspiciously short.
- `somnus/carriers/sidecar.py:28` `SidecarCarrier.render`: Function SidecarCarrier.render is suspiciously short.
- `somnus/carriers/sidecar.py:67` `primary_target`: Function primary_target is suspiciously short.
- `somnus/cli.py:38` `build_parser.cmd`: Function build_parser.cmd is suspiciously short.
- `somnus/commands/_common.py:61` `Ctx.actor`: Function Ctx.actor is suspiciously short.
- `somnus/commands/_common.py:66` `Ctx.fmt`: Function Ctx.fmt is suspiciously short.
- `somnus/commands/_common.py:72` `Ctx.color`: Function Ctx.color is suspiciously short.
- `somnus/commands/_common.py:87` `Ctx.table`: Function Ctx.table is suspiciously short.
- `somnus/commands/_common.py:95` `Ctx.registry_exists`: Function Ctx.registry_exists is suspiciously short.
- `somnus/commands/_common.py:99` `Ctx.store`: Function Ctx.store is suspiciously short.
- `somnus/commands/_common.py:103` `Ctx.readonly`: Function Ctx.readonly is suspiciously short.
- `somnus/commands/_common.py:134` `note`: Function note is suspiciously short.
- `somnus/commands/_common.py:139` `path_text`: Function path_text is suspiciously short.
- `somnus/commands/_common.py:144` `unified`: Function unified is suspiciously short.
- `somnus/commands/_common.py:173` `check_text`: Function check_text is suspiciously short.
- `somnus/commands/_common.py:181` `display`: Function display is suspiciously short.
- `somnus/commands/_common.py:189` `refuse`: Function refuse is suspiciously short.
- `somnus/commands/_common.py:228` `inferred_payload`: Function inferred_payload is suspiciously short.
- `somnus/commands/_common.py:240` `is_candidate`: Function is_candidate is suspiciously short.
- `somnus/commands/brief.py:43` `run`: Function run is suspiciously short.
- `somnus/commands/edit.py:12` `run`: Function run is suspiciously short.
- `somnus/commands/migrate.py:37` `MigrationError.__init__`: Function MigrationError.__init__ is suspiciously short.
- `somnus/config.py:79` `Config.db_path`: Function Config.db_path is suspiciously short.
- `somnus/config.py:84` `somnus_home`: Function somnus_home is suspiciously short.
- `somnus/db/store.py:24` `now_iso`: Function now_iso is suspiciously short.
- `somnus/db/store.py:59` `matches_any`: Function matches_any is suspiciously short.
- `somnus/db/store.py:91` `ScanReport.summary`: Function ScanReport.summary is suspiciously short.
- `somnus/db/store.py:140` `Store.__init__`: Function Store.__init__ is suspiciously short.
- `somnus/db/store.py:175` `Store.close`: Function Store.close is suspiciously short.
- `somnus/db/store.py:180` `Store.__enter__`: Function Store.__enter__ is suspiciously short.
- `somnus/db/store.py:183` `Store.__exit__`: Function Store.__exit__ is suspiciously short.
- `somnus/db/store.py:189` `Store.log`: Function Store.log is suspiciously short.
- `somnus/db/store.py:209` `Store.roots`: Function Store.roots is suspiciously short.
- `somnus/document.py:60` `Document.is_sidecar`: Function Document.is_sidecar is suspiciously short.
- `somnus/document.py:65` `Document.newline`: Function Document.newline is suspiciously short.
- `somnus/document.py:70` `Document.payload`: Function Document.payload is suspiciously short.
- `somnus/document.py:77` `Document.display`: Function Document.display is suspiciously short.
- `somnus/document.py:82` `Document.ignore_span`: Function Document.ignore_span is suspiciously short.
- `somnus/document.py:107` `Document.payload_digest`: Function Document.payload_digest is suspiciously short.
- `somnus/document.py:121` `Document.diag`: Function Document.diag is suspiciously short.
- `somnus/document.py:169` `Document.save`: Function Document.save is suspiciously short.
- `somnus/document.py:175` `Document.copy_payload`: Function Document.copy_payload is suspiciously short.
- `somnus/document.py:193` `canonical_yaml`: Function canonical_yaml is suspiciously short.
- `somnus/document.py:330` `new_sidecar_text`: Function new_sidecar_text is suspiciously short.
- `somnus/ids.py:52` `new_artifact_urn`: Function new_artifact_urn is suspiciously short.
- `somnus/ids.py:57` `parse_urn`: Function parse_urn is suspiciously short.
- `somnus/ids.py:65` `is_artifact_urn`: Function is_artifact_urn is suspiciously short.
- `somnus/ids.py:70` `is_example_urn`: Function is_example_urn is suspiciously short.
- `somnus/ids.py:75` `is_external_ref`: Function is_external_ref is suspiciously short.
- `somnus/ids.py:80` `is_reference_string`: Function is_reference_string is suspiciously short.
- `somnus/ids.py:85` `uuid_version`: Function uuid_version is suspiciously short.
- `somnus/ids.py:128` `is_local_id`: Function is_local_id is suspiciously short.
- `somnus/infer.py:140` `infer`: Function infer is suspiciously short.
- `somnus/model/jsonschema_export.py:14` `_Exporter.__init__`: Function _Exporter.__init__ is suspiciously short.
- `somnus/model/jsonschema_export.py:45` `_Exporter.tagged`: Function _Exporter.tagged is suspiciously short.
- `somnus/model/lifecycle.py:27` `is_abandonment`: Function is_abandonment is suspiciously short.
- `somnus/model/lifecycle.py:32` `is_reactivation`: Function is_reactivation is suspiciously short.
- `somnus/model/lifecycle.py:59` `now_utc`: Function now_utc is suspiciously short.
- `somnus/model/schema.py:102` `Obj.get`: Function Obj.get is suspiciously short.
- `somnus/model/schema.py:110` `Obj.order`: Function Obj.order is suspiciously short.
- `somnus/model/schema.py:155` `F`: Function F is suspiciously short.
- `somnus/model/schema.py:160` `enum`: Function enum is suspiciously short.
- `somnus/model/validate.py:92` `_Run.__init__`: Function _Run.__init__ is suspiciously short.
- `somnus/model/validate.py:96` `_Run.err`: Function _Run.err is suspiciously short.
- `somnus/model/validate.py:99` `_Run.warn`: Function _Run.warn is suspiciously short.
- `somnus/model/validate.py:102` `_Run.at`: Function _Run.at is suspiciously short.
- `somnus/output.py:29` `Diagnostic.is_error`: Function Diagnostic.is_error is suspiciously short.
- `somnus/output.py:58` `render`: Function render is suspiciously short.
- `somnus/output.py:64` `has_errors`: Function has_errors is suspiciously short.
- `somnus/output.py:80` `table.line`: Function table.line is suspiciously short.
- `somnus/output.py:87` `emit`: Function emit is suspiciously short.
- `somnus/tui/app.py:27` `first_message`: Function first_message is suspiciously short.
- `somnus/tui/app.py:58` `render_row`: Function render_row is suspiciously short.
- `somnus/tui/app.py:64` `match_row`: Function match_row is suspiciously short.
- `somnus/tui/app.py:283` `BrowserScreen.__init__`: Function BrowserScreen.__init__ is suspiciously short.
- `somnus/tui/form.py:81` `remove_path`: Function remove_path is suspiciously short.
- `somnus/tui/form.py:112` `FormModel.dirty`: Function FormModel.dirty is suspiciously short.
- `somnus/tui/form.py:116` `FormModel.value`: Function FormModel.value is suspiciously short.
- `somnus/tui/form.py:120` `FormModel.text`: Function FormModel.text is suspiciously short.
- `somnus/tui/form.py:124` `FormModel.readonly_rows`: Function FormModel.readonly_rows is suspiciously short.
- `somnus/tui/form.py:146` `FormModel.revert`: Function FormModel.revert is suspiciously short.
- `somnus/tui/form.py:151` `FormModel.revalidate`: Function FormModel.revalidate is suspiciously short.
- `somnus/tui/term.py:53` `decode_char`: Function decode_char is suspiciously short.
- `somnus/tui/term.py:58` `decode_windows_special`: Function decode_windows_special is suspiciously short.
- `somnus/tui/term.py:73` `is_sequence_final`: Function is_sequence_final is suspiciously short.
- `somnus/tui/term.py:78` `frame_updates`: Function frame_updates is suspiciously short.
- `somnus/tui/term.py:91` `usable_width`: Function usable_width is suspiciously short.
- `somnus/tui/term.py:138` `_WindowsConsole.restore`: Function _WindowsConsole.restore is suspiciously short.
- `somnus/tui/term.py:148` `_PosixTty.__init__`: Function _PosixTty.__init__ is suspiciously short.
- `somnus/tui/term.py:160` `_PosixTty.restore`: Function _PosixTty.restore is suspiciously short.
- `somnus/tui/term.py:185` `Terminal.__enter__`: Function Terminal.__enter__ is suspiciously short.
- `somnus/tui/term.py:189` `Terminal.__exit__`: Function Terminal.__exit__ is suspiciously short.
- `somnus/tui/term.py:225` `Terminal.size`: Function Terminal.size is suspiciously short.
- `somnus/tui/term.py:230` `Terminal.invalidate`: Function Terminal.invalidate is suspiciously short.
- `somnus/tui/term.py:248` `Terminal.read_key`: Function Terminal.read_key is suspiciously short.
- `somnus/tui/widgets.py:20` `char_width`: Function char_width is suspiciously short.
- `somnus/tui/widgets.py:27` `strip_styles`: Function strip_styles is suspiciously short.
- `somnus/tui/widgets.py:32` `visible_width`: Function visible_width is suspiciously short.
- `somnus/tui/widgets.py:71` `highlight`: Function highlight is suspiciously short.
- `somnus/tui/widgets.py:104` `is_text_key`: Function is_text_key is suspiciously short.
- `somnus/tui/widgets.py:132` `ListView.visible`: Function ListView.visible is suspiciously short.
- `somnus/tui/widgets.py:137` `ListView.selected`: Function ListView.selected is suspiciously short.
- `somnus/tui/widgets.py:143` `ListView.set_items`: Function ListView.set_items is suspiciously short.
- `somnus/tui/widgets.py:333` `split_widths`: Function split_widths is suspiciously short.
- `somnus/yamlsub.py:34` `YAMLError.__init__`: Function YAMLError.__init__ is suspiciously short.
- `somnus/yamlsub.py:216` `_Flow.err`: Function _Flow.err is suspiciously short.
- `somnus/yamlsub.py:219` `_Flow.ws`: Function _Flow.ws is suspiciously short.
- `somnus/yamlsub.py:360` `_Parser.take`: Function _Parser.take is suspiciously short.
- `somnus/yamlsub.py:590` `parse`: Function parse is suspiciously short.
- `somnus/yamlsub.py:598` `loads`: Function loads is suspiciously short.
- `somnus/yamlsub.py:667` `_Dumper.__init__`: Function _Dumper.__init__ is suspiciously short.
- `somnus/yamlsub.py:672` `_Dumper.keys`: Function _Dumper.keys is suspiciously short.
- `somnus/yamlsub.py:677` `_Dumper.flow`: Function _Dumper.flow is suspiciously short.
- `somnus/yamlsub.py:733` `dumps`: Function dumps is suspiciously short.

## Full Issue Index

| Severity | Category | File | Line | Symbol | Message |
|---|---|---|---:|---|---|
| serious | `dependency_cycles` | `somnus/carriers/__init__.py` | 1 | `somnus/carriers/__init__.py` | Local dependency cycle detected. |
| minor | `unused_imports` | `somnus/carriers/__init__.py` | 8 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/carriers/__init__.py` | 30 | `Envelope.__post_init__` | Function Envelope.__post_init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 30 | `Envelope.__post_init__` | Function Envelope.__post_init__ is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 35 | `Envelope.payload` | Function Envelope.payload is suspiciously short. |
| serious | `stubs` | `somnus/carriers/__init__.py` | 75 | `Carrier.extract` | Function Carrier.extract has a stub implementation. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 75 | `Carrier.extract` | Function Carrier.extract is suspiciously short. |
| serious | `stubs` | `somnus/carriers/__init__.py` | 79 | `Carrier.render` | Function Carrier.render has a stub implementation. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 79 | `Carrier.render` | Function Carrier.render is suspiciously short. |
| minor | `missing_docstrings` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/carriers/__init__.py` | 87 | `CarrierError.__init__` | Function CarrierError.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 134 | `get` | Function get is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 141 | `is_sidecar_path` | Function is_sidecar_path is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 146 | `sidecar_for` | Function sidecar_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 151 | `host_for` | Function host_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 156 | `carrier_name_for` | Function carrier_name_for is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/carriers/__init__.py` | 164 | `for_path` | Function for_path is suspiciously short. |
| minor | `unused_imports` | `somnus/carriers/blockcomment.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/carriers/blockcomment.py` | 16 | `BlockCarrier.__init__` | Function BlockCarrier.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/carriers/blockcomment.py` | 16 | `BlockCarrier.__init__` | Function BlockCarrier.__init__ has incomplete type hints. |
| minor | `complexity` | `somnus/carriers/blockcomment.py` | 56 | `BlockCarrier.extract` | Function BlockCarrier.extract has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/carriers/blockcomment.py` | 61 | `BlockCarrier.extract` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/carriers/linecomment.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/carriers/linecomment.py` | 15 | `preamble_end` | Function preamble_end has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/carriers/linecomment.py` | 40 | `LineCarrier.__init__` | Function LineCarrier.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/carriers/linecomment.py` | 40 | `LineCarrier.__init__` | Function LineCarrier.__init__ has incomplete type hints. |
| minor | `complexity` | `somnus/carriers/linecomment.py` | 53 | `LineCarrier.extract` | Function LineCarrier.extract has high cyclomatic complexity. |
| serious | `suspicious_short_classes` | `somnus/carriers/linecomment.py` | 105 | `HashCarrier` | Class HashCarrier is suspiciously short. |
| minor | `missing_docstrings` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/carriers/linecomment.py` | 108 | `HashCarrier.__init__` | Function HashCarrier.__init__ has incomplete type hints. |
| minor | `unused_imports` | `somnus/carriers/markdown.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/carriers/markdown.py` | 34 | `MarkdownCarrier.extract` | Function MarkdownCarrier.extract has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/carriers/sidecar.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/carriers/sidecar.py` | 28 | `SidecarCarrier.render` | Function SidecarCarrier.render is suspiciously short. |
| minor | `complexity` | `somnus/carriers/sidecar.py` | 38 | `binding_issues` | Function binding_issues has high cyclomatic complexity. |
| minor | `suspicious_short_functions` | `somnus/carriers/sidecar.py` | 67 | `primary_target` | Function primary_target is suspiciously short. |
| minor | `unused_imports` | `somnus/cli.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/cli.py` | 38 | `build_parser.cmd` | Function build_parser.cmd is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/cli.py` | 38 | `build_parser.cmd` | Function build_parser.cmd is suspiciously short. |
| serious | `silent_failures` | `somnus/cli.py` | 130 | `main` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/cli.py` | 141 | `main` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/cli.py` | 144 | `main` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `broad_exceptions` | `somnus/cli.py` | 147 | `main` | Broad exception handler catches Exception. |
| serious | `silent_failures` | `somnus/cli.py` | 147 | `main` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/commands/_common.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| serious | `silent_failures` | `somnus/commands/_common.py` | 34 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 61 | `Ctx.actor` | Function Ctx.actor is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 66 | `Ctx.fmt` | Function Ctx.fmt is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 72 | `Ctx.color` | Function Ctx.color is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 87 | `Ctx.table` | Function Ctx.table is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 95 | `Ctx.registry_exists` | Function Ctx.registry_exists is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 99 | `Ctx.store` | Function Ctx.store is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 103 | `Ctx.readonly` | Function Ctx.readonly is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/commands/_common.py` | 103 | `Ctx.readonly` | Function Ctx.readonly has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 134 | `note` | Function note is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 139 | `path_text` | Function path_text is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 144 | `unified` | Function unified is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 173 | `check_text` | Function check_text is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 181 | `display` | Function display is suspiciously short. |
| serious | `silent_failures` | `somnus/commands/_common.py` | 185 | `display` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 189 | `refuse` | Function refuse is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 228 | `inferred_payload` | Function inferred_payload is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/commands/_common.py` | 240 | `is_candidate` | Function is_candidate is suspiciously short. |
| minor | `complexity` | `somnus/commands/_common.py` | 245 | `walk` | Function walk has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/commands/brief.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/commands/brief.py` | 43 | `run` | Function run is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/commands/brief.py` | 43 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/bump.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/bump.py` | 12 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/check.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/commands/check.py` | 15 | `run` | Function run has high cyclomatic complexity. |
| minor | `type_hint_gaps` | `somnus/commands/check.py` | 15 | `run` | Function run has incomplete type hints. |
| serious | `silent_failures` | `somnus/commands/check.py` | 28 | `run` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/commands/edit.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/commands/edit.py` | 12 | `run` | Function run is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/commands/edit.py` | 12 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/fork.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/fork.py` | 51 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/index.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/index.py` | 11 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/init.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/init.py` | 14 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/ls.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/ls.py` | 10 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/migrate.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/commands/migrate.py` | 37 | `MigrationError.__init__` | Function MigrationError.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/commands/migrate.py` | 37 | `MigrationError.__init__` | Function MigrationError.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/commands/migrate.py` | 37 | `MigrationError.__init__` | Function MigrationError.__init__ has incomplete type hints. |
| serious | `silent_failures` | `somnus/commands/migrate.py` | 59 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/commands/migrate.py` | 69 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/commands/migrate.py` | 95 | `convert_directives` | Function convert_directives has high cyclomatic complexity. |
| minor | `complexity` | `somnus/commands/migrate.py` | 149 | `build_payload` | Function build_payload has high cyclomatic complexity. |
| minor | `type_hint_gaps` | `somnus/commands/migrate.py` | 371 | `run` | Function run has incomplete type hints. |
| serious | `silent_failures` | `somnus/commands/migrate.py` | 379 | `run` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/commands/migrate.py` | 383 | `run` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/commands/new.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/new.py` | 15 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/query.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/query.py` | 18 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/regions.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/commands/regions.py` | 13 | `run` | Function run has high cyclomatic complexity. |
| minor | `type_hint_gaps` | `somnus/commands/regions.py` | 13 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/schema.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/commands/schema.py` | 55 | `run` | Function run has high cyclomatic complexity. |
| minor | `type_hint_gaps` | `somnus/commands/schema.py` | 55 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/stale.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| serious | `silent_failures` | `somnus/commands/stale.py` | 32 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `type_hint_gaps` | `somnus/commands/stale.py` | 59 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/commands/stamp.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/stamp.py` | 35 | `run` | Function run has incomplete type hints. |
| serious | `silent_failures` | `somnus/commands/stamp.py` | 42 | `run` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/commands/status.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `type_hint_gaps` | `somnus/commands/status.py` | 13 | `run` | Function run has incomplete type hints. |
| minor | `unused_imports` | `somnus/config.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/config.py` | 79 | `Config.db_path` | Function Config.db_path is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/config.py` | 84 | `somnus_home` | Function somnus_home is suspiciously short. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `ScanReport` | Imported name appears unused: ScanReport. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `Store` | Imported name appears unused: Store. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `connect_readonly` | Imported name appears unused: connect_readonly. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `glob_regex` | Imported name appears unused: glob_regex. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `matches_any` | Imported name appears unused: matches_any. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `now_iso` | Imported name appears unused: now_iso. |
| minor | `unused_imports` | `somnus/db/__init__.py` | 3 | `run_query` | Imported name appears unused: run_query. |
| minor | `unused_imports` | `somnus/db/store.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 24 | `now_iso` | Function now_iso is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 59 | `matches_any` | Function matches_any is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 91 | `ScanReport.summary` | Function ScanReport.summary is suspiciously short. |
| serious | `silent_failures` | `somnus/db/store.py` | 107 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/db/store.py` | 140 | `Store.__init__` | Function Store.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 175 | `Store.close` | Function Store.close is suspiciously short. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 180 | `Store.__enter__` | Function Store.__enter__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 180 | `Store.__enter__` | Function Store.__enter__ is suspiciously short. |
| minor | `missing_docstrings` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/db/store.py` | 183 | `Store.__exit__` | Function Store.__exit__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 189 | `Store.log` | Function Store.log is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/db/store.py` | 209 | `Store.roots` | Function Store.roots is suspiciously short. |
| minor | `complexity` | `somnus/db/store.py` | 266 | `Store.scan` | Function Store.scan has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/db/store.py` | 333 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/db/store.py` | 346 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/db/store.py` | 538 | `Store` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/document.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 60 | `Document.is_sidecar` | Function Document.is_sidecar is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 65 | `Document.newline` | Function Document.newline is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 70 | `Document.payload` | Function Document.payload is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 77 | `Document.display` | Function Document.display is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 82 | `Document.ignore_span` | Function Document.ignore_span is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 107 | `Document.payload_digest` | Function Document.payload_digest is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 121 | `Document.diag` | Function Document.diag is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 169 | `Document.save` | Function Document.save is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 175 | `Document.copy_payload` | Function Document.copy_payload is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 193 | `canonical_yaml` | Function canonical_yaml is suspiciously short. |
| serious | `silent_failures` | `somnus/document.py` | 201 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/document.py` | 217 | `atomic_write` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `broad_exceptions` | `somnus/document.py` | 220 | `atomic_write` | Broad exception handler catches BaseException. |
| serious | `silent_failures` | `somnus/document.py` | 255 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/document.py` | 330 | `new_sidecar_text` | Function new_sidecar_text is suspiciously short. |
| minor | `unused_imports` | `somnus/ids.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 52 | `new_artifact_urn` | Function new_artifact_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 57 | `parse_urn` | Function parse_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 65 | `is_artifact_urn` | Function is_artifact_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 70 | `is_example_urn` | Function is_example_urn is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 75 | `is_external_ref` | Function is_external_ref is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 80 | `is_reference_string` | Function is_reference_string is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 85 | `uuid_version` | Function uuid_version is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/ids.py` | 128 | `is_local_id` | Function is_local_id is suspiciously short. |
| minor | `unused_imports` | `somnus/infer.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/infer.py` | 97 | `infer_title` | Function infer_title has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/infer.py` | 121 | `infer_title` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/infer.py` | 140 | `infer` | Function infer is suspiciously short. |
| minor | `unused_imports` | `somnus/model/jsonschema_export.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 13 | `_Exporter` | Class _Exporter is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 14 | `_Exporter.__init__` | Function _Exporter.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/jsonschema_export.py` | 14 | `_Exporter.__init__` | Function _Exporter.__init__ is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 18 | `_Exporter.ref` | Function _Exporter.ref is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 29 | `_Exporter.obj` | Function _Exporter.obj is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 45 | `_Exporter.tagged` | Function _Exporter.tagged is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/jsonschema_export.py` | 45 | `_Exporter.tagged` | Function _Exporter.tagged is suspiciously short. |
| minor | `complexity` | `somnus/model/jsonschema_export.py` | 51 | `_Exporter.node` | Function _Exporter.node has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/model/jsonschema_export.py` | 51 | `_Exporter.node` | Function _Exporter.node is missing a meaningful docstring. |
| minor | `unused_imports` | `somnus/model/lifecycle.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 27 | `is_abandonment` | Function is_abandonment is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 32 | `is_reactivation` | Function is_reactivation is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/lifecycle.py` | 59 | `now_utc` | Function now_utc is suspiciously short. |
| serious | `silent_failures` | `somnus/model/lifecycle.py` | 111 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/model/schema.py` | 8 | `annotations` | Imported name appears unused: annotations. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 33 | `Str` | Class Str is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 44 | `Int` | Class Int is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 52 | `Num` | Class Num is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/schema.py` | 61 | `Bool` | Class Bool is missing a meaningful docstring. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 61 | `Bool` | Class Bool is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 68 | `AnyValue` | Class AnyValue is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 75 | `Arr` | Class Arr is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 85 | `Field` | Class Field is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 102 | `Obj.get` | Function Obj.get is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 110 | `Obj.order` | Function Obj.order is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 116 | `MapOf` | Class MapOf is suspiciously short. |
| serious | `suspicious_short_classes` | `somnus/model/schema.py` | 145 | `Union_` | Class Union_ is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 155 | `F` | Function F is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/model/schema.py` | 160 | `enum` | Function enum is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/model/schema.py` | 542 | `make_order` | Function make_order has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/model/schema.py` | 551 | `make_order.order` | Function make_order.order is missing a meaningful docstring. |
| minor | `complexity` | `somnus/model/schema.py` | 562 | `describe` | Function describe has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/model/validate.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/model/validate.py` | 51 | `Resolver.add_payload` | Function Resolver.add_payload has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 81 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/model/validate.py` | 92 | `_Run.__init__` | Function _Run.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 96 | `_Run.err` | Function _Run.err is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 96 | `_Run.err` | Function _Run.err is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 99 | `_Run.warn` | Function _Run.warn is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 99 | `_Run.warn` | Function _Run.warn is suspiciously short. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 102 | `_Run.at` | Function _Run.at is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/model/validate.py` | 102 | `_Run.at` | Function _Run.at is suspiciously short. |
| minor | `complexity` | `somnus/model/validate.py` | 109 | `walk` | Function walk has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 130 | `walk` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 278 | `consistency` | Function consistency has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/model/validate.py` | 438 | `find_cycle.visit` | Function find_cycle.visit is missing a meaningful docstring. |
| minor | `complexity` | `somnus/model/validate.py` | 500 | `marker_regions` | Function marker_regions has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 563 | `references` | Function references has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 592 | `references` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 618 | `selectors` | Function selectors has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/model/validate.py` | 652 | `selectors` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/model/validate.py` | 667 | `selectors` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/model/validate.py` | 691 | `semantic_policies` | Function semantic_policies has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 760 | `validate` | Function validate has high cyclomatic complexity. |
| minor | `complexity` | `somnus/model/validate.py` | 815 | `permits_use` | Function permits_use has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/model/vocab.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `unused_imports` | `somnus/output.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 29 | `Diagnostic.is_error` | Function Diagnostic.is_error is suspiciously short. |
| minor | `missing_docstrings` | `somnus/output.py` | 37 | `SomnusError.__init__` | Function SomnusError.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/output.py` | 37 | `SomnusError.__init__` | Function SomnusError.__init__ has incomplete type hints. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 58 | `render` | Function render is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 64 | `has_errors` | Function has_errors is suspiciously short. |
| minor | `complexity` | `somnus/output.py` | 69 | `table` | Function table has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/output.py` | 80 | `table.line` | Function table.line is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 80 | `table.line` | Function table.line is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/output.py` | 87 | `emit` | Function emit is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/output.py` | 87 | `emit` | Function emit has incomplete type hints. |
| minor | `unused_imports` | `somnus/regions.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `complexity` | `somnus/regions.py` | 37 | `markdown_code_mask` | Function markdown_code_mask has high cyclomatic complexity. |
| serious | `silent_failures` | `somnus/regions.py` | 81 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `complexity` | `somnus/regions.py` | 103 | `scan_markers` | Function scan_markers has high cyclomatic complexity. |
| minor | `complexity` | `somnus/regions.py` | 190 | `sync_registry` | Function sync_registry has high cyclomatic complexity. |
| minor | `unused_imports` | `somnus/tui/app.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/tui/app.py` | 27 | `first_message` | Function first_message is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/app.py` | 58 | `render_row` | Function render_row is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/app.py` | 64 | `match_row` | Function match_row is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/app.py` | 89 | `EditorScreen.__init__` | Function EditorScreen.__init__ is missing a meaningful docstring. |
| serious | `silent_failures` | `somnus/tui/app.py` | 108 | `EditorScreen.run` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 169 | `EditorScreen` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 190 | `EditorScreen.save` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 193 | `EditorScreen.save` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 200 | `EditorScreen.save` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `security_risks` | `somnus/tui/app.py` | 213 | `EditorScreen.edit_body` | High-risk call detected: subprocess.call. |
| serious | `silent_failures` | `somnus/tui/app.py` | 216 | `EditorScreen.edit_body` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 225 | `EditorScreen.reload` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 229 | `EditorScreen.reload` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `missing_docstrings` | `somnus/tui/app.py` | 283 | `BrowserScreen.__init__` | Function BrowserScreen.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/app.py` | 283 | `BrowserScreen.__init__` | Function BrowserScreen.__init__ is suspiciously short. |
| serious | `silent_failures` | `somnus/tui/app.py` | 295 | `BrowserScreen.run` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 316 | `BrowserScreen.reload` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 329 | `BrowserScreen.open_selected` | Exception handler can suppress failure without actionable diagnostics. |
| serious | `silent_failures` | `somnus/tui/app.py` | 332 | `BrowserScreen.open_selected` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `unused_imports` | `somnus/tui/form.py` | 3 | `annotations` | Imported name appears unused: annotations. |
| serious | `suspicious_short_classes` | `somnus/tui/form.py` | 15 | `Field` | Class Field is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 81 | `remove_path` | Function remove_path is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/form.py` | 103 | `FormModel.__init__` | Function FormModel.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 112 | `FormModel.dirty` | Function FormModel.dirty is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 116 | `FormModel.value` | Function FormModel.value is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 120 | `FormModel.text` | Function FormModel.text is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 124 | `FormModel.readonly_rows` | Function FormModel.readonly_rows is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 146 | `FormModel.revert` | Function FormModel.revert is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/form.py` | 151 | `FormModel.revalidate` | Function FormModel.revalidate is suspiciously short. |
| minor | `unused_imports` | `somnus/tui/term.py` | 8 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 53 | `decode_char` | Function decode_char is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 58 | `decode_windows_special` | Function decode_windows_special is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 73 | `is_sequence_final` | Function is_sequence_final is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 78 | `frame_updates` | Function frame_updates is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 91 | `usable_width` | Function usable_width is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/term.py` | 102 | `_WindowsConsole.__init__` | Function _WindowsConsole.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 138 | `_WindowsConsole.restore` | Function _WindowsConsole.restore is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/term.py` | 148 | `_PosixTty.__init__` | Function _PosixTty.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 148 | `_PosixTty.__init__` | Function _PosixTty.__init__ is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 160 | `_PosixTty.restore` | Function _PosixTty.restore is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/term.py` | 177 | `Terminal.__init__` | Function Terminal.__init__ is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/tui/term.py` | 185 | `Terminal.__enter__` | Function Terminal.__enter__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 185 | `Terminal.__enter__` | Function Terminal.__enter__ is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/term.py` | 189 | `Terminal.__exit__` | Function Terminal.__exit__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 189 | `Terminal.__exit__` | Function Terminal.__exit__ is suspiciously short. |
| serious | `broad_exceptions` | `somnus/tui/term.py` | 198 | `Terminal` | Broad exception handler catches BaseException. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 225 | `Terminal.size` | Function Terminal.size is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 230 | `Terminal.invalidate` | Function Terminal.invalidate is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/term.py` | 248 | `Terminal.read_key` | Function Terminal.read_key is suspiciously short. |
| minor | `unused_imports` | `somnus/tui/widgets.py` | 7 | `annotations` | Imported name appears unused: annotations. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 20 | `char_width` | Function char_width is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 27 | `strip_styles` | Function strip_styles is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 32 | `visible_width` | Function visible_width is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 71 | `highlight` | Function highlight is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 104 | `is_text_key` | Function is_text_key is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/widgets.py` | 118 | `ListView.__init__` | Function ListView.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 132 | `ListView.visible` | Function ListView.visible is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 137 | `ListView.selected` | Function ListView.selected is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 143 | `ListView.set_items` | Function ListView.set_items is suspiciously short. |
| minor | `missing_docstrings` | `somnus/tui/widgets.py` | 223 | `Picker.__init__` | Function Picker.__init__ is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/tui/widgets.py` | 284 | `TextInput.__init__` | Function TextInput.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/tui/widgets.py` | 333 | `split_widths` | Function split_widths is suspiciously short. |
| minor | `unused_imports` | `somnus/yamlsub.py` | 13 | `annotations` | Imported name appears unused: annotations. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 34 | `YAMLError.__init__` | Function YAMLError.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 59 | `_Line` | Class _Line is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 206 | `_Flow` | Class _Flow is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 207 | `_Flow.__init__` | Function _Flow.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 207 | `_Flow.__init__` | Function _Flow.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 216 | `_Flow.err` | Function _Flow.err is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 216 | `_Flow.err` | Function _Flow.err is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 219 | `_Flow.ws` | Function _Flow.ws is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 219 | `_Flow.ws` | Function _Flow.ws is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 223 | `_Flow.value` | Function _Flow.value is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 247 | `_Flow.seq` | Function _Flow.seq is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 269 | `_Flow.key` | Function _Flow.key is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 288 | `_Flow.mapping` | Function _Flow.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 326 | `_Parser` | Class _Parser is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 327 | `_Parser.__init__` | Function _Parser.__init__ is missing a meaningful docstring. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 327 | `_Parser.__init__` | Function _Parser.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 337 | `_Parser.peek` | Function _Parser.peek is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 360 | `_Parser.take` | Function _Parser.take is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 360 | `_Parser.take` | Function _Parser.take is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 367 | `_Parser.document` | Function _Parser.document is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 379 | `_Parser.block` | Function _Parser.block is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 386 | `_Parser.mapping` | Function _Parser.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 404 | `_Parser.value_after_key` | Function _Parser.value_after_key is missing a meaningful docstring. |
| minor | `complexity` | `somnus/yamlsub.py` | 416 | `_Parser.sequence` | Function _Parser.sequence has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 416 | `_Parser.sequence` | Function _Parser.sequence is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 450 | `_Parser.split_key` | Function _Parser.split_key is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 480 | `_Parser.inline` | Function _Parser.inline is missing a meaningful docstring. |
| minor | `complexity` | `somnus/yamlsub.py` | 498 | `_Parser.block_scalar` | Function _Parser.block_scalar has high cyclomatic complexity. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 498 | `_Parser.block_scalar` | Function _Parser.block_scalar is missing a meaningful docstring. |
| serious | `silent_failures` | `somnus/yamlsub.py` | 582 | `<module>` | Exception handler can suppress failure without actionable diagnostics. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 590 | `parse` | Function parse is suspiciously short. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 598 | `loads` | Function loads is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 666 | `_Dumper` | Class _Dumper is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 667 | `_Dumper.__init__` | Function _Dumper.__init__ is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 667 | `_Dumper.__init__` | Function _Dumper.__init__ is suspiciously short. |
| minor | `type_hint_gaps` | `somnus/yamlsub.py` | 667 | `_Dumper.__init__` | Function _Dumper.__init__ has incomplete type hints. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 672 | `_Dumper.keys` | Function _Dumper.keys is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 672 | `_Dumper.keys` | Function _Dumper.keys is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 677 | `_Dumper.flow` | Function _Dumper.flow is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 677 | `_Dumper.flow` | Function _Dumper.flow is suspiciously short. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 680 | `_Dumper.mapping` | Function _Dumper.mapping is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 698 | `_Dumper.list_after` | Function _Dumper.list_after is missing a meaningful docstring. |
| minor | `missing_docstrings` | `somnus/yamlsub.py` | 707 | `_Dumper.sequence` | Function _Dumper.sequence is missing a meaningful docstring. |
| minor | `suspicious_short_functions` | `somnus/yamlsub.py` | 733 | `dumps` | Function dumps is suspiciously short. |

## File Diagnostics

### `somnus/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 9 |
| Code lines | 7 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/__main__.py`

| Metric | Value |
|---|---:|
| Lines | 8 |
| Code lines | 5 |
| Classes | 0 |
| Functions | 0 |
| Imports | 2 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/carriers/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 167 |
| Code lines | 123 |
| Classes | 6 |
| Functions | 11 |
| Imports | 7 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 3 |

#### Issue 1: `dependency_cycles` at line 1

Severity: `serious`
Symbol: `somnus/carriers/__init__.py`
Message: Local dependency cycle detected.
Remediation: Break the cycle by moving shared contracts into a lower-level module or inverting the import boundary.

Evidence:
```text
No source evidence available.
```
Details:
```json
{
  "cycle": [
    "somnus/carriers/__init__.py",
    "somnus/carriers/blockcomment.py"
  ]
}
```

#### Issue 2: `unused_imports` at line 8

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  6: """
  7: 
> 8: from __future__ import annotations
  9: 
  10: from dataclasses import dataclass, field
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 3: `missing_docstrings` at line 30

Severity: `minor`
Symbol: `Envelope.__post_init__`
Message: Function Envelope.__post_init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  28:     mask_end: int = -1
  29: 
> 30:     def __post_init__(self) -> None:
  31:         if self.mask_start < 0:
  32:             self.mask_start, self.mask_end = self.start, self.end
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `suspicious_short_functions` at line 30

Severity: `minor`
Symbol: `Envelope.__post_init__`
Message: Function Envelope.__post_init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  28:     mask_end: int = -1
  29: 
> 30:     def __post_init__(self) -> None:
  31:         if self.mask_start < 0:
  32:             self.mask_start, self.mask_end = self.start, self.end
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 35

Severity: `minor`
Symbol: `Envelope.payload`
Message: Function Envelope.payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  33: 
  34:     @property
> 35:     def payload(self) -> str:
  36:         """Payload YAML text with a trailing newline."""
  37:         return "\n".join(self.payload_lines) + "\n"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 75

Severity: `minor`
Symbol: `Carrier.extract`
Message: Function Carrier.extract is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  73:     region_style: tuple
  74: 
> 75:     def extract(self, lines: list[str]) -> Extraction:
  76:         """Locate the envelope."""
  77:         ...
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `stubs` at line 75

Severity: `serious`
Symbol: `Carrier.extract`
Message: Function Carrier.extract has a stub implementation.
Remediation: Replace pass, ellipsis, or NotImplementedError with a real diagnostic path or domain exception.

Evidence:
```text
  73:     region_style: tuple
  74: 
> 75:     def extract(self, lines: list[str]) -> Extraction:
  76:         """Locate the envelope."""
  77:         ...
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 79

Severity: `minor`
Symbol: `Carrier.render`
Message: Function Carrier.render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  77:         ...
  78: 
> 79:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  80:         """Return the splice that writes ``payload`` into the file."""
  81:         ...
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `stubs` at line 79

Severity: `serious`
Symbol: `Carrier.render`
Message: Function Carrier.render has a stub implementation.
Remediation: Replace pass, ellipsis, or NotImplementedError with a real diagnostic path or domain exception.

Evidence:
```text
  77:         ...
  78: 
> 79:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  80:         """Return the splice that writes ``payload`` into the file."""
  81:         ...
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `missing_docstrings` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 11: `suspicious_short_functions` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 12: `type_hint_gaps` at line 87

Severity: `minor`
Symbol: `CarrierError.__init__`
Message: Function CarrierError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  85:     """The carrier cannot place the envelope without altering host semantics."""
  86: 
> 87:     def __init__(self, code: str, message: str, line: int = 1):
  88:         self.code = code
  89:         self.line = line
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 13: `suspicious_short_functions` at line 134

Severity: `minor`
Symbol: `get`
Message: Function get is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  132: 
  133: 
> 134: def get(name: str) -> Carrier:
  135:     """Return the carrier registered under ``name``."""
  136:     if not _CACHE:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 14: `suspicious_short_functions` at line 141

Severity: `minor`
Symbol: `is_sidecar_path`
Message: Function is_sidecar_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  139: 
  140: 
> 141: def is_sidecar_path(path: Path) -> bool:
  142:     """Return True for ``*.somnus.yaml`` sidecar files."""
  143:     return path.name.endswith(SIDECAR_SUFFIX)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 15: `suspicious_short_functions` at line 146

Severity: `minor`
Symbol: `sidecar_for`
Message: Function sidecar_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  144: 
  145: 
> 146: def sidecar_for(path: Path) -> Path:
  147:     """Return the sidecar path for a host file."""
  148:     return path.with_name(path.name + SIDECAR_SUFFIX)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 16: `suspicious_short_functions` at line 151

Severity: `minor`
Symbol: `host_for`
Message: Function host_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  149: 
  150: 
> 151: def host_for(sidecar: Path) -> Path:
  152:     """Return the host path a sidecar file describes by name."""
  153:     return sidecar.with_name(sidecar.name[: -len(SIDECAR_SUFFIX)])
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 17: `suspicious_short_functions` at line 156

Severity: `minor`
Symbol: `carrier_name_for`
Message: Function carrier_name_for is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  154: 
  155: 
> 156: def carrier_name_for(path: Path) -> Optional[str]:
  157:     """Return the embedded carrier name for a path, or None when a sidecar is required."""
  158:     if is_sidecar_path(path):
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 18: `suspicious_short_functions` at line 164

Severity: `minor`
Symbol: `for_path`
Message: Function for_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  162: 
  163: 
> 164: def for_path(path: Path) -> Optional[Carrier]:
  165:     """Return the embedded carrier for a path, or None when a sidecar is required."""
  166:     name = carrier_name_for(path)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

### `somnus/carriers/blockcomment.py`

| Metric | Value |
|---|---:|
| Lines | 105 |
| Code lines | 92 |
| Classes | 1 |
| Functions | 4 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 13 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Block-comment carriers: CSS ``/* */`` and XML/HTML/SVG ``<!-- -->`` (SPEC Â§17.4â€“Â§17.5)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 16

Severity: `minor`
Symbol: `BlockCarrier.__init__`
Message: Function BlockCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  14:     """Envelope delimited by a block-comment opener and closer line."""
  15: 
> 16:     def __init__(self, name: str, opener: str, closer: str, forbidden: str, forbid: str, region_style: tuple):
  17:         self.name = name
  18:         self.capability = "somnus-adapter-block-comment@1"
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `type_hint_gaps` at line 16

Severity: `minor`
Symbol: `BlockCarrier.__init__`
Message: Function BlockCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  14:     """Envelope delimited by a block-comment opener and closer line."""
  15: 
> 16:     def __init__(self, name: str, opener: str, closer: str, forbidden: str, forbid: str, region_style: tuple):
  17:         self.name = name
  18:         self.capability = "somnus-adapter-block-comment@1"
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 4: `complexity` at line 56

Severity: `minor`
Symbol: `BlockCarrier.extract`
Message: Function BlockCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  54:         return s.startswith("/*") and s.endswith("*/") and s != self.opener
  55: 
> 56:     def extract(self, lines: list[str]) -> Extraction:
  57:         """Scan the leading area (after declarations) for one envelope."""
  58:         result = Extraction()
```
Details:
```json
{
  "complexity": 13,
  "maximum": 12
}
```

#### Issue 5: `silent_failures` at line 61

Severity: `serious`
Symbol: `BlockCarrier.extract`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  59:         try:
  60:             i = self.preamble_end(lines)
> 61:         except CarrierError:
  62:             i = 0
  63:         found: list[Envelope] = []
```
Details:
```json
{
  "handler_body_length": 1
}
```

### `somnus/carriers/linecomment.py`

| Metric | Value |
|---|---:|
| Lines | 109 |
| Code lines | 93 |
| Classes | 2 |
| Functions | 5 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 17 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Comment-prefixed carriers: ``# ``, ``% ``, ``// ``, ``-- `` (SPEC Â§17.3, Â§17.5)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 15

Severity: `minor`
Symbol: `preamble_end`
Message: Function preamble_end has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  13: 
  14: 
> 15: def preamble_end(host: str, lines: list[str]) -> int:
  16:     """Return the index of the first line after mandatory host preamble lines."""
  17:     i = 0
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 3: `missing_docstrings` at line 40

Severity: `minor`
Symbol: `LineCarrier.__init__`
Message: Function LineCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  38:     forbid: Optional[str] = None
  39: 
> 40:     def __init__(self, host: str, prefix: str, capability: str, name: Optional[str] = None):
  41:         self.host = host
  42:         self.prefix = prefix
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `type_hint_gaps` at line 40

Severity: `minor`
Symbol: `LineCarrier.__init__`
Message: Function LineCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  38:     forbid: Optional[str] = None
  39: 
> 40:     def __init__(self, host: str, prefix: str, capability: str, name: Optional[str] = None):
  41:         self.host = host
  42:         self.prefix = prefix
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `complexity` at line 53

Severity: `minor`
Symbol: `LineCarrier.extract`
Message: Function LineCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  51:         return line.lstrip().startswith(self.bare)
  52: 
> 53:     def extract(self, lines: list[str]) -> Extraction:
  54:         """Scan the leading comment area for exactly one envelope."""
  55:         result = Extraction()
```
Details:
```json
{
  "complexity": 14,
  "maximum": 12
}
```

#### Issue 6: `suspicious_short_classes` at line 105

Severity: `serious`
Symbol: `HashCarrier`
Message: Class HashCarrier is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  103: 
  104: 
> 105: class HashCarrier(LineCarrier):
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 1,
  "public_method_count": 0
}
```

#### Issue 7: `missing_docstrings` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `type_hint_gaps` at line 108

Severity: `minor`
Symbol: `HashCarrier.__init__`
Message: Function HashCarrier.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  106:     """``# `` carrier for Python, shell, PowerShell, R, TOML, and YAML hosts."""
  107: 
> 108:     def __init__(self, host: str):
  109:         super().__init__(host, "# ", "somnus-adapter-hash-comment@1", host)
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

### `somnus/carriers/markdown.py`

| Metric | Value |
|---|---:|
| Lines | 106 |
| Code lines | 94 |
| Classes | 1 |
| Functions | 3 |
| Imports | 5 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 21 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Markdown carriers: YAML frontmatter and the hidden HTML comment envelope (SPEC Â§17.1â€“Â§17.2)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 34

Severity: `minor`
Symbol: `MarkdownCarrier.extract`
Message: Function MarkdownCarrier.extract has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  32:     region_style = ("markdown",)
  33: 
> 34:     def extract(self, lines: list[str]) -> Extraction:
  35:         """Find the unique frontmatter ``somnus`` block or HTML envelope."""
  36:         result = Extraction()
```
Details:
```json
{
  "complexity": 21,
  "maximum": 12
}
```

### `somnus/carriers/sidecar.py`

| Metric | Value |
|---|---:|
| Lines | 72 |
| Code lines | 58 |
| Classes | 1 |
| Functions | 4 |
| Imports | 4 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 16 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Detached sidecar bindings: ``<file>.somnus.yaml`` (SPEC Â§17.6)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 28

Severity: `minor`
Symbol: `SidecarCarrier.render`
Message: Function SidecarCarrier.render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  26:         return Extraction(Envelope("sidecar", 0, end, lines[:end], 0))
  27: 
> 28:     def render(self, lines: list[str], payload: str, envelope: Optional[Envelope], style: Optional[str] = None) -> Splice:
  29:         """Replace the whole sidecar content."""
  30:         body = payload.rstrip("\n").split("\n")
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 3: `complexity` at line 38

Severity: `minor`
Symbol: `binding_issues`
Message: Function binding_issues has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  36: 
  37: 
> 38: def binding_issues(somnus: Any, sidecar_path: Path) -> list[tuple[tuple, str]]:
  39:     """Check the primary binding contract; return (field path, message) pairs."""
  40:     problems: list[tuple[tuple, str]] = []
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

#### Issue 4: `suspicious_short_functions` at line 67

Severity: `minor`
Symbol: `primary_target`
Message: Function primary_target is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  65: 
  66: 
> 67: def primary_target(somnus: Any, sidecar_path: Path) -> Optional[Path]:
  68:     """Return the resolved primary target path of a sidecar, when it is a relative locator."""
  69:     for b in somnus.get("bindings", []) if isinstance(somnus, dict) else []:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

### `somnus/cli.py`

| Metric | Value |
|---|---:|
| Lines | 156 |
| Code lines | 124 |
| Classes | 0 |
| Functions | 3 |
| Imports | 10 |
| Local dependencies | 4 |
| Missing imports | 0 |
| Max complexity | 10 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Argument parsing and lazy command dispatch for the ``somnus`` CLI (SPEC Â§20)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import argparse
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 38

Severity: `minor`
Symbol: `build_parser.cmd`
Message: Function build_parser.cmd is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  36:     sub = parser.add_subparsers(dest="command", metavar="<command>")
  37: 
> 38:     def cmd(name: str, help_text: str) -> argparse.ArgumentParser:
  39:         return sub.add_parser(name, help=help_text, description=help_text, parents=[common])
  40: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `suspicious_short_functions` at line 38

Severity: `minor`
Symbol: `build_parser.cmd`
Message: Function build_parser.cmd is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  36:     sub = parser.add_subparsers(dest="command", metavar="<command>")
  37: 
> 38:     def cmd(name: str, help_text: str) -> argparse.ArgumentParser:
  39:         return sub.add_parser(name, help=help_text, description=help_text, parents=[common])
  40: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `silent_failures` at line 130

Severity: `serious`
Symbol: `main`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  128:     try:
  129:         args = parser.parse_args(argv)
> 130:     except SystemExit as exc:
  131:         return 0 if exc.code in (0, None) else EXIT_USAGE
  132:     if not args.command:
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 5: `silent_failures` at line 141

Severity: `serious`
Symbol: `main`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  139:     try:
  140:         return int(module.run(args, ctx))
> 141:     except SomnusError as exc:
  142:         ctx.diagnostics(exc.diagnostics)
  143:         return exc.exit_code
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 6: `silent_failures` at line 144

Severity: `serious`
Symbol: `main`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  142:         ctx.diagnostics(exc.diagnostics)
  143:         return exc.exit_code
> 144:     except KeyboardInterrupt:
  145:         note("interrupted")
  146:         return EXIT_INVALID
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 7: `broad_exceptions` at line 147

Severity: `serious`
Symbol: `main`
Message: Broad exception handler catches Exception.
Remediation: Catch specific domain exceptions or convert known library exceptions at the boundary.

Evidence:
```text
  145:         note("interrupted")
  146:         return EXIT_INVALID
> 147:     except Exception as exc:  # noqa: BLE001 - last-resort boundary: report, never hide
  148:         if args.debug:
  149:             traceback.print_exc()
```
Details:
```json
{
  "handler": "Exception"
}
```

#### Issue 8: `silent_failures` at line 147

Severity: `serious`
Symbol: `main`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  145:         note("interrupted")
  146:         return EXIT_INVALID
> 147:     except Exception as exc:  # noqa: BLE001 - last-resort boundary: report, never hide
  148:         if args.debug:
  149:             traceback.print_exc()
```
Details:
```json
{
  "handler_body_length": 2
}
```

### `somnus/commands/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 1 |
| Code lines | 1 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/commands/_common.py`

| Metric | Value |
|---|---:|
| Lines | 272 |
| Code lines | 218 |
| Classes | 1 |
| Functions | 23 |
| Imports | 14 |
| Local dependencies | 6 |
| Missing imports | 0 |
| Max complexity | 16 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Shared command context: configuration, output, registry access, and header commits."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import difflib
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `silent_failures` at line 34

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  32:             return False
  33:         return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
> 34:     except (AttributeError, OSError):
  35:         return False
  36: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 3: `suspicious_short_functions` at line 61

Severity: `minor`
Symbol: `Ctx.actor`
Message: Function Ctx.actor is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  59: 
  60:     @property
> 61:     def actor(self) -> str:
  62:         """Actor name recorded in the event ledger."""
  63:         return self.cfg.actor
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 66

Severity: `minor`
Symbol: `Ctx.fmt`
Message: Function Ctx.fmt is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  64: 
  65:     @property
> 66:     def fmt(self) -> str:
  67:         """Output format: ``text`` or ``tsv``."""
  68:         return "tsv" if self.tsv else "text"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 72

Severity: `minor`
Symbol: `Ctx.color`
Message: Function Ctx.color is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  70:     # ------------------------------------------------------------- output
  71:     @property
> 72:     def color(self) -> bool:
  73:         """Whether ANSI color is used on stdout."""
  74:         if self._color is None:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 87

Severity: `minor`
Symbol: `Ctx.table`
Message: Function Ctx.table is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  85:         emit(text)
  86: 
> 87:     def table(self, headers: Sequence[str], rows: Sequence[Sequence[object]]) -> None:
  88:         """Print an aligned table (or TSV with a header row)."""
  89:         if rows or self.tsv:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 95

Severity: `minor`
Symbol: `Ctx.registry_exists`
Message: Function Ctx.registry_exists is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  93: 
  94:     # ------------------------------------------------------------- registry
> 95:     def registry_exists(self) -> bool:
  96:         """True when the global registry database exists."""
  97:         return self.cfg.db_path.exists()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 99

Severity: `minor`
Symbol: `Ctx.store`
Message: Function Ctx.store is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  97:         return self.cfg.db_path.exists()
  98: 
> 99:     def store(self) -> Store:
  100:         """Open the registry for writing; it must already exist."""
  101:         return Store.open(self.cfg.db_path, actor=self.actor, create=False)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 103

Severity: `minor`
Symbol: `Ctx.readonly`
Message: Function Ctx.readonly is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  101:         return Store.open(self.cfg.db_path, actor=self.actor, create=False)
  102: 
> 103:     def readonly(self):
  104:         """Open the registry read-only."""
  105:         return connect_readonly(self.cfg.db_path)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 10: `type_hint_gaps` at line 103

Severity: `minor`
Symbol: `Ctx.readonly`
Message: Function Ctx.readonly has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  101:         return Store.open(self.cfg.db_path, actor=self.actor, create=False)
  102: 
> 103:     def readonly(self):
  104:         """Open the registry read-only."""
  105:         return connect_readonly(self.cfg.db_path)
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 11: `suspicious_short_functions` at line 134

Severity: `minor`
Symbol: `note`
Message: Function note is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  132: 
  133: 
> 134: def note(message: str) -> None:
  135:     """Write an informational line to stderr."""
  136:     sys.stderr.write(message.rstrip("\n") + "\n")
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `suspicious_short_functions` at line 139

Severity: `minor`
Symbol: `path_text`
Message: Function path_text is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  137: 
  138: 
> 139: def path_text(path: Path) -> str:
  140:     """Absolute POSIX-style path for ledger rows."""
  141:     return str(Path(path).resolve()).replace("\\", "/")
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 13: `suspicious_short_functions` at line 144

Severity: `minor`
Symbol: `unified`
Message: Function unified is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  142: 
  143: 
> 144: def unified(old: str, new: str, path: str, old_label: Optional[str] = None) -> str:
  145:     """Unified diff of two texts."""
  146:     lines = difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 14: `suspicious_short_functions` at line 173

Severity: `minor`
Symbol: `check_text`
Message: Function check_text is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  171: 
  172: 
> 173: def check_text(meta_path: Path, text: str) -> None:
  174:     """Refuse text whose envelope does not pass core validation."""
  175:     candidate = D.from_text(meta_path, text)
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 15: `suspicious_short_functions` at line 181

Severity: `minor`
Symbol: `display`
Message: Function display is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  179: 
  180: 
> 181: def display(path: Path) -> str:
  182:     """Path as shown in diagnostics (relative to cwd when possible)."""
  183:     try:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 16: `silent_failures` at line 185

Severity: `serious`
Symbol: `display`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  183:     try:
  184:         return os.path.relpath(Path(path), Path.cwd()).replace("\\", "/")
> 185:     except ValueError:
  186:         return str(path).replace("\\", "/")
  187: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 17: `suspicious_short_functions` at line 189

Severity: `minor`
Symbol: `refuse`
Message: Function refuse is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  187: 
  188: 
> 189: def refuse(path: Path | str, code: str, message: str, field_path: str = "-") -> SomnusError:
  190:     """Build a refusal error anchored at a file."""
  191:     shown = path if isinstance(path, str) else display(path)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 18: `suspicious_short_functions` at line 228

Severity: `minor`
Symbol: `inferred_payload`
Message: Function inferred_payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  226: 
  227: 
> 228: def inferred_payload(cfg: config.Config, path: Path, lines: Sequence[str], *, type_: Optional[str] = None,
  229:                      title: Optional[str] = None, status: str = "draft",
  230:                      created_at: Optional[str] = None) -> dict:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 19: `suspicious_short_functions` at line 240

Severity: `minor`
Symbol: `is_candidate`
Message: Function is_candidate is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  238: 
  239: 
> 240: def is_candidate(path: Path) -> bool:
  241:     """A file that can carry metadata (embedded carrier or sidecar)."""
  242:     return carriers.is_sidecar_path(path) or carriers.for_path(path) is not None
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 20: `complexity` at line 245

Severity: `minor`
Symbol: `walk`
Message: Function walk has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  243: 
  244: 
> 245: def walk(roots: Iterable[Path], exclude: Sequence[str]) -> Iterator[Path]:
  246:     """Yield candidate files under ``roots`` honoring exclude globs (hosts with sidecars yield the sidecar)."""
  247:     patterns = [glob_regex(p) for p in exclude]
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

### `somnus/commands/brief.py`

| Metric | Value |
|---|---:|
| Lines | 46 |
| Code lines | 35 |
| Classes | 0 |
| Functions | 1 |
| Imports | 4 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 1 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus brief``: a Markdown cheat sheet for agent instruction files."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from somnus import CORE_SCHEMA
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 43

Severity: `minor`
Symbol: `run`
Message: Function run is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  41: 
  42: 
> 43: def run(args, ctx: Ctx) -> int:
  44:     """Print the cheat sheet."""
  45:     emit(BRIEF)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 3: `type_hint_gaps` at line 43

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  41: 
  42: 
> 43: def run(args, ctx: Ctx) -> int:
  44:     """Print the cheat sheet."""
  45:     emit(BRIEF)
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/bump.py`

| Metric | Value |
|---|---:|
| Lines | 23 |
| Code lines | 18 |
| Classes | 0 |
| Functions | 1 |
| Imports | 5 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 2 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus bump``: new revision; resolves revision conflicts."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 12

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  10: 
  11: 
> 12: def run(args, ctx: Ctx) -> int:
  13:     """Increment the revision, stamp ``time.updated_at``, and re-index."""
  14:     path = Path(args.path).resolve()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/check.py`

| Metric | Value |
|---|---:|
| Lines | 48 |
| Code lines | 42 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 4 |
| Missing imports | 0 |
| Max complexity | 25 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus check``: run the validation pipeline and print diagnostics."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 15

Severity: `minor`
Symbol: `run`
Message: Function run has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  13: 
  14: 
> 15: def run(args, ctx: Ctx) -> int:
  16:     """Validate named files, walked directories, or every configured root."""
  17:     explicit = [Path(p).resolve() for p in args.paths]
```
Details:
```json
{
  "complexity": 25,
  "maximum": 12
}
```

#### Issue 3: `type_hint_gaps` at line 15

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  13: 
  14: 
> 15: def run(args, ctx: Ctx) -> int:
  16:     """Validate named files, walked directories, or every configured root."""
  17:     explicit = [Path(p).resolve() for p in args.paths]
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

#### Issue 4: `silent_failures` at line 28

Severity: `serious`
Symbol: `run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  26:         try:
  27:             doc = D.load(path)
> 28:         except SomnusError as exc:
  29:             diags.extend(exc.diagnostics)
  30:             continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

### `somnus/commands/edit.py`

| Metric | Value |
|---|---:|
| Lines | 18 |
| Code lines | 12 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 4 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus edit``: terminal UI (document browser, or header editor for one file)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import sys
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 12

Severity: `minor`
Symbol: `run`
Message: Function run is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  10: 
  11: 
> 12: def run(args, ctx: Ctx) -> int:
  13:     """Launch the full-screen UI; requires an interactive terminal."""
  14:     if not (sys.stdin.isatty() and sys.stdout.isatty()):
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 3: `type_hint_gaps` at line 12

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  10: 
  11: 
> 12: def run(args, ctx: Ctx) -> int:
  13:     """Launch the full-screen UI; requires an interactive terminal."""
  14:     if not (sys.stdin.isatty() and sys.stdout.isatty()):
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/fork.py`

| Metric | Value |
|---|---:|
| Lines | 89 |
| Code lines | 80 |
| Classes | 0 |
| Functions | 2 |
| Imports | 9 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 12 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus fork``: new artifact (UUIDv7, revision 1) derived from an existing revision."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 51

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  49: 
  50: 
> 51: def run(args, ctx: Ctx) -> int:
  52:     """Write the fork next to the parent (or at ``--out``) and record lineage."""
  53:     path = Path(args.path).resolve()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/index.py`

| Metric | Value |
|---|---:|
| Lines | 22 |
| Code lines | 17 |
| Classes | 0 |
| Functions | 1 |
| Imports | 4 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 8 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus index``: reconcile roots into the registry."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 11

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  9: 
  10: 
> 11: def run(args, ctx: Ctx) -> int:
  12:     """Scan the named roots, or every registered root (falling back to configured roots)."""
  13:     with ctx.store() as st:
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/init.py`

| Metric | Value |
|---|---:|
| Lines | 41 |
| Code lines | 36 |
| Classes | 0 |
| Functions | 1 |
| Imports | 7 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 12 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus init``: create $SOMNUS_HOME, config.toml, and the registry; register roots."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 14

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  12: 
  13: 
> 14: def run(args, ctx: Ctx) -> int:
  15:     """Initialize the global home; idempotent."""
  16:     home = config.somnus_home()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/ls.py`

| Metric | Value |
|---|---:|
| Lines | 20 |
| Code lines | 16 |
| Classes | 0 |
| Functions | 1 |
| Imports | 4 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 2 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus ls``: list present artifacts."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from somnus.commands._common import Ctx
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 10

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  8: 
  9: 
> 10: def run(args, ctx: Ctx) -> int:
  11:     """Filter the ``docs`` view."""
  12:     conn = ctx.readonly()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/migrate.py`

| Metric | Value |
|---|---:|
| Lines | 404 |
| Code lines | 356 |
| Classes | 1 |
| Functions | 5 |
| Imports | 17 |
| Local dependencies | 11 |
| Missing imports | 0 |
| Max complexity | 91 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus migrate``: upgrade v0.1 hybrid documents to core 2.0.0 (SPEC Â§22)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 37

Severity: `minor`
Symbol: `MigrationError.__init__`
Message: Function MigrationError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  35:     """Migration refused; the file is left untouched."""
  36: 
> 37:     def __init__(self, line: int, message: str):
  38:         super().__init__(message)
  39:         self.line = line
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `suspicious_short_functions` at line 37

Severity: `minor`
Symbol: `MigrationError.__init__`
Message: Function MigrationError.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  35:     """Migration refused; the file is left untouched."""
  36: 
> 37:     def __init__(self, line: int, message: str):
  38:         super().__init__(message)
  39:         self.line = line
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 4: `type_hint_gaps` at line 37

Severity: `minor`
Symbol: `MigrationError.__init__`
Message: Function MigrationError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  35:     """Migration refused; the file is left untouched."""
  36: 
> 37:     def __init__(self, line: int, message: str):
  38:         super().__init__(message)
  39:         self.line = line
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `silent_failures` at line 59

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  57:             datetime.fromisoformat(value.replace("Z", "+00:00"))
  58:             return value
> 59:         except ValueError:
  60:             return None
  61:     return None
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 6: `silent_failures` at line 69

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  67:             datetime.strptime(value, "%Y-%m-%d")
  68:             return value
> 69:         except ValueError:
  70:             return None
  71:     return None
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 7: `complexity` at line 95

Severity: `minor`
Symbol: `convert_directives`
Message: Function convert_directives has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  93: 
  94: 
> 95: def convert_directives(lines: list[str], offset: int) -> tuple[list[str], list[dict], list[dict]]:
  96:     """Replace live ``:::submatter`` directives with marker pairs.
  97: 
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 8: `complexity` at line 149

Severity: `minor`
Symbol: `build_payload`
Message: Function build_payload has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  147: 
  148: 
> 149: def build_payload(legacy: dict, cfg: Config, path: Path, regions: list[dict], directives: list[dict]) -> dict:
  150:     """Map a lenient-parsed v0.1 header to a core 2.0.0 payload (SPEC Â§22 steps 1â€“8)."""
  151:     rest = copy.deepcopy(legacy)
```
Details:
```json
{
  "complexity": 91,
  "maximum": 12
}
```

#### Issue 9: `type_hint_gaps` at line 371

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  369: 
  370: 
> 371: def run(args, ctx: Ctx) -> int:
  372:     """Dry-run diff by default; ``--write`` writes after core validation."""
  373:     status = EXIT_OK
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

#### Issue 10: `silent_failures` at line 379

Severity: `serious`
Symbol: `run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  377:         try:
  378:             result = plan(path, ctx.cfg)
> 379:         except MigrationError as exc:
  380:             ctx.diagnostics([Diagnostic(shown, exc.line, 1, "error", "E_SCHEMA", "-", str(exc))])
  381:             status = EXIT_INVALID
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 11: `silent_failures` at line 383

Severity: `serious`
Symbol: `run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  381:             status = EXIT_INVALID
  382:             continue
> 383:         except SomnusError as exc:
  384:             ctx.diagnostics(exc.diagnostics)
  385:             status = max(status, exc.exit_code)
```
Details:
```json
{
  "handler_body_length": 3
}
```

### `somnus/commands/new.py`

| Metric | Value |
|---|---:|
| Lines | 44 |
| Code lines | 39 |
| Classes | 0 |
| Functions | 1 |
| Imports | 8 |
| Local dependencies | 6 |
| Missing imports | 0 |
| Max complexity | 9 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus new``: scaffold a conformant Markdown artifact."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 15

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  13: 
  14: 
> 15: def run(args, ctx: Ctx) -> int:
  16:     """Create ``<slug>.md`` with a fresh UUIDv7 at revision 1."""
  17:     title = args.title.strip()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/query.py`

| Metric | Value |
|---|---:|
| Lines | 28 |
| Code lines | 23 |
| Classes | 0 |
| Functions | 1 |
| Imports | 4 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 6 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus q``: read-only registry queries."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from somnus.commands._common import Ctx
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 18

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  16: 
  17: 
> 18: def run(args, ctx: Ctx) -> int:
  19:     """Run SQL or a shortcut (default ``--docs``) against a read-only connection."""
  20:     chosen = next((k for k in SHORTCUTS if getattr(args, k)), None)
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/regions.py`

| Metric | Value |
|---|---:|
| Lines | 57 |
| Code lines | 52 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 4 |
| Missing imports | 0 |
| Max complexity | 23 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus regions``: audit body markers against ``knowledge.regions``; optionally register them."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 13

Severity: `minor`
Symbol: `run`
Message: Function run has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  11: 
  12: 
> 13: def run(args, ctx: Ctx) -> int:
  14:     """Print the marker table; with ``--sync`` register unregistered markers (diff unless ``--write``)."""
  15:     path = Path(args.path).resolve()
```
Details:
```json
{
  "complexity": 23,
  "maximum": 12
}
```

#### Issue 3: `type_hint_gaps` at line 13

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  11: 
  12: 
> 13: def run(args, ctx: Ctx) -> int:
  14:     """Print the marker table; with ``--sync`` register unregistered markers (diff unless ``--write``)."""
  15:     path = Path(args.path).resolve()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/schema.py`

| Metric | Value |
|---|---:|
| Lines | 85 |
| Code lines | 74 |
| Classes | 0 |
| Functions | 2 |
| Imports | 10 |
| Local dependencies | 6 |
| Missing imports | 0 |
| Max complexity | 15 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus schema``: field documentation, or JSON Schema Draft 2020-12 export."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import json
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 55

Severity: `minor`
Symbol: `run`
Message: Function run has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  53: 
  54: 
> 55: def run(args, ctx: Ctx) -> int:
  56:     """Print documentation for one field (default: the payload root) or export JSON Schema."""
  57:     if args.json_schema:
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 3: `type_hint_gaps` at line 55

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  53: 
  54: 
> 55: def run(args, ctx: Ctx) -> int:
  56:     """Print documentation for one field (default: the payload root) or export JSON Schema."""
  57:     if args.json_schema:
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/stale.py`

| Metric | Value |
|---|---:|
| Lines | 67 |
| Code lines | 60 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 2 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus stale``: stale drafts, unresolved replacements, missing files, near-duplicates, open conflicts."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import difflib
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `silent_failures` at line 32

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  30:         try:
  31:             refs = yamlsub.parse(header).data["somnus"]["lifecycle"].get("replacement_refs", [])
> 32:         except (yamlsub.YAMLError, KeyError, TypeError) as exc:
  33:             rows.append(["unreadable-header", aid, title, str(exc)])
  34:             continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 3: `type_hint_gaps` at line 59

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  57: 
  58: 
> 59: def run(args, ctx: Ctx) -> int:
  60:     """Print one row per finding (report only; exit 0)."""
  61:     conn = ctx.readonly()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/commands/stamp.py`

| Metric | Value |
|---|---:|
| Lines | 56 |
| Code lines | 49 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 7 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus stamp``: infer and inject a header into unmanaged files."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 35

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  33: 
  34: 
> 35: def run(args, ctx: Ctx) -> int:
  36:     """Dry-run diff by default; ``--write`` applies atomically."""
  37:     status = EXIT_OK
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

#### Issue 3: `silent_failures` at line 42

Severity: `serious`
Symbol: `run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  40:         try:
  41:             plan = _plan(path, args, ctx)
> 42:         except SomnusError as exc:
  43:             ctx.diagnostics(exc.diagnostics)
  44:             status = max(status, exc.exit_code)
```
Details:
```json
{
  "handler_body_length": 3
}
```

### `somnus/commands/status.py`

| Metric | Value |
|---|---:|
| Lines | 36 |
| Code lines | 31 |
| Classes | 0 |
| Functions | 1 |
| Imports | 6 |
| Local dependencies | 4 |
| Missing imports | 0 |
| Max complexity | 5 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """``somnus status``: validated lifecycle transition (new revision)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from pathlib import Path
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `type_hint_gaps` at line 13

Severity: `minor`
Symbol: `run`
Message: Function run has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  11: 
  12: 
> 13: def run(args, ctx: Ctx) -> int:
  14:     """Apply one permitted transition and write the new revision."""
  15:     path = Path(args.path).resolve()
```
Details:
```json
{
  "missing_hints": [
    "param:args"
  ]
}
```

### `somnus/config.py`

| Metric | Value |
|---|---:|
| Lines | 176 |
| Code lines | 151 |
| Classes | 2 |
| Functions | 4 |
| Imports | 8 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 11 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Hierarchical configuration: CLI flag > nearest .somnus.toml > $SOMNUS_HOME/config.toml > defaults."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 79

Severity: `minor`
Symbol: `Config.db_path`
Message: Function Config.db_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  77: 
  78:     @property
> 79:     def db_path(self) -> Path:
  80:         """Location of the global registry database."""
  81:         return self.home / "somnus.db"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 84

Severity: `minor`
Symbol: `somnus_home`
Message: Function somnus_home is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  82: 
  83: 
> 84: def somnus_home() -> Path:
  85:     """Return $SOMNUS_HOME, defaulting to ~/.somnus."""
  86:     env = os.environ.get("SOMNUS_HOME")
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

### `somnus/db/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 5 |
| Code lines | 3 |
| Classes | 0 |
| Functions | 0 |
| Imports | 1 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 0 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `ScanReport`
Message: Imported name appears unused: ScanReport.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 2: `unused_imports` at line 3

Severity: `minor`
Symbol: `Store`
Message: Imported name appears unused: Store.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 3: `unused_imports` at line 3

Severity: `minor`
Symbol: `connect_readonly`
Message: Imported name appears unused: connect_readonly.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 4: `unused_imports` at line 3

Severity: `minor`
Symbol: `glob_regex`
Message: Imported name appears unused: glob_regex.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 5: `unused_imports` at line 3

Severity: `minor`
Symbol: `matches_any`
Message: Imported name appears unused: matches_any.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 6: `unused_imports` at line 3

Severity: `minor`
Symbol: `now_iso`
Message: Imported name appears unused: now_iso.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

#### Issue 7: `unused_imports` at line 3

Severity: `minor`
Symbol: `run_query`
Message: Imported name appears unused: run_query.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry (SPEC Â§18)."""
  2: 
> 3: from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query
  4: 
  5: __all__ = ["ScanReport", "Store", "connect_readonly", "glob_regex", "matches_any", "now_iso", "run_query"]
```
Details:
```json
{
  "module": "somnus.db.store",
  "raw": "from somnus.db.store import ScanReport, Store, connect_readonly, glob_regex, matches_any, now_iso, run_query"
}
```

### `somnus/db/store.py`

| Metric | Value |
|---|---:|
| Lines | 675 |
| Code lines | 589 |
| Classes | 2 |
| Functions | 23 |
| Imports | 15 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 17 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Global SQLite registry: open/migrate, indexing, conflicts, and read-only queries (SPEC Â§18)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import difflib
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 24

Severity: `minor`
Symbol: `now_iso`
Message: Function now_iso is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  22: 
  23: 
> 24: def now_iso() -> str:
  25:     """Current UTC instant as an RFC 3339 timestamp with a ``Z`` offset."""
  26:     return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 59

Severity: `minor`
Symbol: `matches_any`
Message: Function matches_any is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  57: 
  58: 
> 59: def matches_any(rel_path: str, patterns: Sequence[re.Pattern]) -> bool:
  60:     """True when a POSIX relative path matches any compiled glob."""
  61:     return any(p.match(rel_path) for p in patterns)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 91

Severity: `minor`
Symbol: `ScanReport.summary`
Message: Function ScanReport.summary is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  89:     diagnostics: list[Diagnostic] = field(default_factory=list)
  90: 
> 91:     def summary(self) -> str:
  92:         """One-line plain-English summary."""
  93:         return (f"scanned {self.scanned}, indexed {self.indexed}, unchanged {self.unchanged}, "
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 5: `silent_failures` at line 107

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  105:     try:
  106:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 107:     except ValueError:
  108:         return None
  109: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 6: `missing_docstrings` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 7: `suspicious_short_functions` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 8: `type_hint_gaps` at line 140

Severity: `minor`
Symbol: `Store.__init__`
Message: Function Store.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  138:     """Connection to the global registry with indexing and query helpers."""
  139: 
> 140:     def __init__(self, conn: sqlite3.Connection, path: Path, actor: str):
  141:         self.conn = conn
  142:         self.path = path
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 9: `suspicious_short_functions` at line 175

Severity: `minor`
Symbol: `Store.close`
Message: Function Store.close is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  173:         self.conn.commit()
  174: 
> 175:     def close(self) -> None:
  176:         """Commit pending work and close the connection."""
  177:         self.conn.commit()
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 10: `missing_docstrings` at line 180

Severity: `minor`
Symbol: `Store.__enter__`
Message: Function Store.__enter__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  178:         self.conn.close()
  179: 
> 180:     def __enter__(self) -> "Store":
  181:         return self
  182: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 11: `suspicious_short_functions` at line 180

Severity: `minor`
Symbol: `Store.__enter__`
Message: Function Store.__enter__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  178:         self.conn.close()
  179: 
> 180:     def __enter__(self) -> "Store":
  181:         return self
  182: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `missing_docstrings` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 13: `suspicious_short_functions` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 14: `type_hint_gaps` at line 183

Severity: `minor`
Symbol: `Store.__exit__`
Message: Function Store.__exit__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  181:         return self
  182: 
> 183:     def __exit__(self, exc_type, exc, tb) -> None:
  184:         if exc_type is not None:
  185:             self.conn.rollback()
```
Details:
```json
{
  "missing_hints": [
    "param:exc_type",
    "param:exc",
    "param:tb"
  ]
}
```

#### Issue 15: `suspicious_short_functions` at line 189

Severity: `minor`
Symbol: `Store.log`
Message: Function Store.log is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  187: 
  188:     # ------------------------------------------------------------- ledger
> 189:     def log(self, action: str, artifact_id: Optional[str] = None, revision: Optional[int] = None,
  190:             path: Optional[str] = None, detail: Optional[str] = None) -> None:
  191:         """Append one row to the append-only event ledger."""
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 16: `suspicious_short_functions` at line 209

Severity: `minor`
Symbol: `Store.roots`
Message: Function Store.roots is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  207:         return cur.lastrowid
  208: 
> 209:     def roots(self) -> list[tuple[int, Path]]:
  210:         """Registered roots as ``(id, path)``."""
  211:         return [(r[0], Path(r[1])) for r in self.conn.execute("SELECT id, path FROM roots ORDER BY path")]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 17: `complexity` at line 266

Severity: `minor`
Symbol: `Store.scan`
Message: Function Store.scan has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  264: 
  265:     # ------------------------------------------------------------- indexing
> 266:     def scan(self, roots: Optional[Iterable[Path]] = None, exclude: Sequence[str] = (),
  267:              full: bool = False) -> ScanReport:
  268:         """Reconcile roots (default: all registered) into the registry."""
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 18: `silent_failures` at line 333

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  331:                 hst = host.stat()
  332:                 mtime, size = max(mtime, hst.st_mtime), size + hst.st_size
> 333:         except OSError as exc:
  334:             report.diagnostics.append(Diagnostic(str(file_path), 0, 0, "error", "E_IO", "-", exc.strerror or str(exc)))
  335:             report.invalid += 1
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 19: `silent_failures` at line 346

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  344:         try:
  345:             doc = D.load(file_path)
> 346:         except SomnusError as exc:
  347:             report.diagnostics.extend(exc.diagnostics)
  348:             report.invalid += 1
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 20: `silent_failures` at line 538

Severity: `serious`
Symbol: `Store`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  536:             try:
  537:                 authority = yamlsub.parse(header).data["somnus"]["authority"]
> 538:             except (yamlsub.YAMLError, KeyError, TypeError) as exc:
  539:                 report.diagnostics.append(Diagnostic("-", 0, 0, "error", "E_AUTHORITY", "-",
  540:                                                      f"stored header for {aid} is unreadable; authority overlap"
```
Details:
```json
{
  "handler_body_length": 2
}
```

### `somnus/document.py`

| Metric | Value |
|---|---:|
| Lines | 332 |
| Code lines | 280 |
| Classes | 1 |
| Functions | 19 |
| Imports | 13 |
| Local dependencies | 5 |
| Missing imports | 0 |
| Max complexity | 8 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Document loading and atomic saving with byte preservation (SPEC Â§16.3, Â§17)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 60

Severity: `minor`
Symbol: `Document.is_sidecar`
Message: Function Document.is_sidecar is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  58:     # ------------------------------------------------------------- properties
  59:     @property
> 60:     def is_sidecar(self) -> bool:
  61:         """True when metadata lives in a ``.somnus.yaml`` sidecar."""
  62:         return self.carrier is SIDECAR
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 65

Severity: `minor`
Symbol: `Document.newline`
Message: Function Document.newline is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  63: 
  64:     @property
> 65:     def newline(self) -> str:
  66:         """Line ending used for lines the tool writes."""
  67:         return _dominant_newline(self.endings)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 70

Severity: `minor`
Symbol: `Document.payload`
Message: Function Document.payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  68: 
  69:     @property
> 70:     def payload(self) -> Optional[dict]:
  71:         """The ``somnus`` mapping, when it parsed."""
  72:         if isinstance(self.data, dict) and isinstance(self.data.get("somnus"), dict):
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 77

Severity: `minor`
Symbol: `Document.display`
Message: Function Document.display is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  75: 
  76:     @property
> 77:     def display(self) -> str:
  78:         """Path shown in diagnostics."""
  79:         return _display(self.meta_path)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 82

Severity: `minor`
Symbol: `Document.ignore_span`
Message: Function Document.ignore_span is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  80: 
  81:     @property
> 82:     def ignore_span(self) -> tuple[int, int]:
  83:         """0-based [start, end) span hidden from body scans."""
  84:         if self.envelope is None or self.is_sidecar:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 107

Severity: `minor`
Symbol: `Document.payload_digest`
Message: Function Document.payload_digest is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  105:         return hashlib.sha256(data.encode("utf-8")).hexdigest()
  106: 
> 107:     def payload_digest(self) -> str:
  108:         """SHA-256 of the canonical serialization of the payload."""
  109:         return hashlib.sha256(canonical_yaml(self.data or {}).encode("utf-8")).hexdigest()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 121

Severity: `minor`
Symbol: `Document.diag`
Message: Function Document.diag is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  119:         return (self.envelope.payload_start + line, col + self.envelope.col_offset)
  120: 
> 121:     def diag(self, path: tuple, code: str, message: str, severity: str = "error",
  122:              line: Optional[int] = None, col: Optional[int] = None) -> Diagnostic:
  123:         """Build a diagnostic anchored at a payload path (or explicit position)."""
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 169

Severity: `minor`
Symbol: `Document.save`
Message: Function Document.save is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  167:                                           "refusing to write: content outside the envelope would change")])
  168: 
> 169:     def save(self, payload: dict, style: Optional[str] = None) -> str:
  170:         """Atomically write ``payload`` into the envelope; return the new text."""
  171:         text = self.render(payload, style)
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 175

Severity: `minor`
Symbol: `Document.copy_payload`
Message: Function Document.copy_payload is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  173:         return text
  174: 
> 175:     def copy_payload(self) -> dict:
  176:         """Deep copy of the current payload (empty dict when unparsed)."""
  177:         return copy.deepcopy(self.payload or {})
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 11: `suspicious_short_functions` at line 193

Severity: `minor`
Symbol: `canonical_yaml`
Message: Function canonical_yaml is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  191: 
  192: 
> 193: def canonical_yaml(root: dict, forbid: Optional[str] = None) -> str:
  194:     """Serialize a root mapping in canonical order."""
  195:     return yamlsub.dumps(root, order=make_order(root), forbid=forbid)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `silent_failures` at line 201

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  199:     try:
  200:         return os.path.relpath(path, Path.cwd()).replace("\\", "/")
> 201:     except ValueError:
  202:         return str(path).replace("\\", "/")
  203: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 13: `silent_failures` at line 217

Severity: `serious`
Symbol: `atomic_write`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  215:             try:
  216:                 os.chmod(tmp, path.stat().st_mode)
> 217:             except OSError:
  218:                 pass
  219:         os.replace(tmp, path)
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 14: `broad_exceptions` at line 220

Severity: `serious`
Symbol: `atomic_write`
Message: Broad exception handler catches BaseException.
Remediation: Catch specific domain exceptions or convert known library exceptions at the boundary.

Evidence:
```text
  218:                 pass
  219:         os.replace(tmp, path)
> 220:     except BaseException:
  221:         if os.path.exists(tmp):
  222:             os.unlink(tmp)
```
Details:
```json
{
  "handler": "BaseException"
}
```

#### Issue 15: `silent_failures` at line 255

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  253:     try:
  254:         parsed = yamlsub.parse(env.payload, lenient=lenient)
> 255:     except yamlsub.YAMLError as exc:
  256:         doc.issues.append(Diagnostic(doc.display, env.payload_start + exc.line, exc.col + env.col_offset,
  257:                                      "error", "E_YAML", "-", exc.message))
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 16: `suspicious_short_functions` at line 330

Severity: `minor`
Symbol: `new_sidecar_text`
Message: Function new_sidecar_text is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  328: 
  329: 
> 330: def new_sidecar_text(payload: dict) -> str:
  331:     """Canonical text for a brand-new sidecar file."""
  332:     return canonical_yaml({"somnus": payload})
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

### `somnus/ids.py`

| Metric | Value |
|---|---:|
| Lines | 130 |
| Code lines | 100 |
| Classes | 0 |
| Functions | 12 |
| Imports | 9 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 6 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Identifier minting and parsing: RFC 9562 UUIDv7, Somnus URNs, slugs."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import os
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 52

Severity: `minor`
Symbol: `new_artifact_urn`
Message: Function new_artifact_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  50: 
  51: 
> 52: def new_artifact_urn() -> str:
  53:     """Return a freshly minted ``urn:somnus:artifact:<uuidv7>``."""
  54:     return f"urn:somnus:artifact:{uuid7()}"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 57

Severity: `minor`
Symbol: `parse_urn`
Message: Function parse_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  55: 
  56: 
> 57: def parse_urn(urn: str) -> tuple[str, str]:
  58:     """Split a Somnus URN into (kind, key); raise ValueError when malformed."""
  59:     m = SOMNUS_URN_RE.match(urn)
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 65

Severity: `minor`
Symbol: `is_artifact_urn`
Message: Function is_artifact_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  63: 
  64: 
> 65: def is_artifact_urn(value: str) -> bool:
  66:     """Return True for a lowercase ``urn:somnus:artifact:<uuid>``."""
  67:     return bool(ARTIFACT_URN_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 70

Severity: `minor`
Symbol: `is_example_urn`
Message: Function is_example_urn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  68: 
  69: 
> 70: def is_example_urn(value: str) -> bool:
  71:     """Return True for a fixture-only ``urn:somnus:example:*`` identifier."""
  72:     return bool(EXAMPLE_URN_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 75

Severity: `minor`
Symbol: `is_external_ref`
Message: Function is_external_ref is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  73: 
  74: 
> 75: def is_external_ref(value: str) -> bool:
  76:     """Return True for DOI, HTTP(S), or non-Somnus URN references."""
  77:     return bool(EXTERNAL_REF_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 80

Severity: `minor`
Symbol: `is_reference_string`
Message: Function is_reference_string is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  78: 
  79: 
> 80: def is_reference_string(value: str) -> bool:
  81:     """Return True when ``value`` is a Somnus URN or an external reference."""
  82:     return bool(SOMNUS_URN_RE.match(value)) or is_external_ref(value)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 85

Severity: `minor`
Symbol: `uuid_version`
Message: Function uuid_version is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  83: 
  84: 
> 85: def uuid_version(urn: str) -> Optional[int]:
  86:     """Return the UUID version nibble of an artifact URN, or None."""
  87:     m = ARTIFACT_URN_RE.match(urn)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 128

Severity: `minor`
Symbol: `is_local_id`
Message: Function is_local_id is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  126: 
  127: 
> 128: def is_local_id(value: str) -> bool:
  129:     """Return True for a valid local region/claim/relation identifier."""
  130:     return bool(LOCAL_ID_RE.match(value))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

### `somnus/infer.py`

| Metric | Value |
|---|---:|
| Lines | 145 |
| Code lines | 126 |
| Classes | 1 |
| Functions | 3 |
| Imports | 6 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 18 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Heuristic title and classification inference for ``somnus stamp``."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import ast
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 97

Severity: `minor`
Symbol: `infer_title`
Message: Function infer_title has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  95: 
  96: 
> 97: def infer_title(path: Path, lines: Sequence[str]) -> str:
  98:     """Infer a human title from headings, TeX titles, docstrings, or the filename."""
  99:     suffix = path.suffix.lower()
```
Details:
```json
{
  "complexity": 18,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 121

Severity: `serious`
Symbol: `infer_title`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  119:         try:
  120:             doc = ast.get_docstring(ast.parse("\n".join(lines) + "\n"))
> 121:         except SyntaxError:
  122:             doc = None
  123:         if doc and doc.strip():
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `suspicious_short_functions` at line 140

Severity: `minor`
Symbol: `infer`
Message: Function infer is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  138: 
  139: 
> 140: def infer(path: Path, lines: Sequence[str], type_override: Optional[str] = None,
  141:           title_override: Optional[str] = None) -> Inference:
  142:     """Infer title and classification defaults for an unmanaged file."""
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

### `somnus/model/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 1 |
| Code lines | 1 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/model/jsonschema_export.py`

| Metric | Value |
|---|---:|
| Lines | 115 |
| Code lines | 103 |
| Classes | 1 |
| Functions | 6 |
| Imports | 4 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 22 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Export the declarative schema tree as JSON Schema Draft 2020-12 (interchange only; never stored)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: from typing import Any
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 13

Severity: `minor`
Symbol: `_Exporter`
Message: Class _Exporter is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  11: 
  12: 
> 13: class _Exporter:
  14:     def __init__(self) -> None:
  15:         self.defs: dict[str, Any] = {}
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 3: `missing_docstrings` at line 14

Severity: `minor`
Symbol: `_Exporter.__init__`
Message: Function _Exporter.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  12: 
  13: class _Exporter:
> 14:     def __init__(self) -> None:
  15:         self.defs: dict[str, Any] = {}
  16:         self._names: dict[int, str] = {}
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `suspicious_short_functions` at line 14

Severity: `minor`
Symbol: `_Exporter.__init__`
Message: Function _Exporter.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  12: 
  13: class _Exporter:
> 14:     def __init__(self) -> None:
  15:         self.defs: dict[str, Any] = {}
  16:         self._names: dict[int, str] = {}
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 5: `missing_docstrings` at line 18

Severity: `minor`
Symbol: `_Exporter.ref`
Message: Function _Exporter.ref is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  16:         self._names: dict[int, str] = {}
  17: 
> 18:     def ref(self, node: S.Obj | S.Tagged) -> dict:
  19:         key = id(node)
  20:         if key not in self._names:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 6: `missing_docstrings` at line 29

Severity: `minor`
Symbol: `_Exporter.obj`
Message: Function _Exporter.obj is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  27:         return {"$ref": f"#/$defs/{self._names[key]}"}
  28: 
> 29:     def obj(self, node: S.Obj, tag: tuple[str, str] | None = None) -> dict:
  30:         props: dict[str, Any] = {}
  31:         for f in node.fields:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 7: `missing_docstrings` at line 45

Severity: `minor`
Symbol: `_Exporter.tagged`
Message: Function _Exporter.tagged is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  43:         return out
  44: 
> 45:     def tagged(self, node: S.Tagged) -> dict:
  46:         out: dict[str, Any] = {"oneOf": [self.obj(v, (node.tag, k)) for k, v in node.variants.items()]}
  47:         if node.doc:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 45

Severity: `minor`
Symbol: `_Exporter.tagged`
Message: Function _Exporter.tagged is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  43:         return out
  44: 
> 45:     def tagged(self, node: S.Tagged) -> dict:
  46:         out: dict[str, Any] = {"oneOf": [self.obj(v, (node.tag, k)) for k, v in node.variants.items()]}
  47:         if node.doc:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 9: `complexity` at line 51

Severity: `minor`
Symbol: `_Exporter.node`
Message: Function _Exporter.node has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  49:         return out
  50: 
> 51:     def node(self, node: Any) -> dict:
  52:         if isinstance(node, S.Str):
  53:             out: dict[str, Any] = {"type": "string"}
```
Details:
```json
{
  "complexity": 22,
  "maximum": 12
}
```

#### Issue 10: `missing_docstrings` at line 51

Severity: `minor`
Symbol: `_Exporter.node`
Message: Function _Exporter.node is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  49:         return out
  50: 
> 51:     def node(self, node: Any) -> dict:
  52:         if isinstance(node, S.Str):
  53:             out: dict[str, Any] = {"type": "string"}
```
Details:
```json
{
  "entity_type": "function"
}
```

### `somnus/model/lifecycle.py`

| Metric | Value |
|---|---:|
| Lines | 112 |
| Code lines | 93 |
| Classes | 0 |
| Functions | 6 |
| Imports | 4 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 12 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Lifecycle transition state machine (SPEC Â§7)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 27

Severity: `minor`
Symbol: `is_abandonment`
Message: Function is_abandonment is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  25: 
  26: 
> 27: def is_abandonment(current: str, target: str) -> bool:
  28:     """Work abandoned before it became current."""
  29:     return target == "archived" and current in ABANDONABLE
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 32

Severity: `minor`
Symbol: `is_reactivation`
Message: Function is_reactivation is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  30: 
  31: 
> 32: def is_reactivation(current: str, target: str) -> bool:
  33:     """A retired artifact returned to active use."""
  34:     return target == "active" and current in REACTIVATABLE
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 59

Severity: `minor`
Symbol: `now_utc`
Message: Function now_utc is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  57: 
  58: 
> 59: def now_utc() -> str:
  60:     """Current instant as an RFC 3339 UTC timestamp with seconds precision."""
  61:     return datetime.now(timezone.utc).replace(microsecond=0).isoformat()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `silent_failures` at line 111

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  109:     try:
  110:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 111:     except ValueError:
  112:         return None
```
Details:
```json
{
  "handler_body_length": 1
}
```

### `somnus/model/schema.py`

| Metric | Value |
|---|---:|
| Lines | 601 |
| Code lines | 503 |
| Classes | 11 |
| Functions | 9 |
| Imports | 5 |
| Local dependencies | 2 |
| Missing imports | 0 |
| Max complexity | 23 |

#### Issue 1: `unused_imports` at line 8

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  6: """
  7: 
> 8: from __future__ import annotations
  9: 
  10: from dataclasses import dataclass, field
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_classes` at line 33

Severity: `serious`
Symbol: `Str`
Message: Class Str is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  31: 
  32: @dataclass(frozen=True)
> 33: class Str:
  34:     """String node; optional vocabulary, full-match pattern, or format."""
  35: 
```
Details:
```json
{
  "line_count": 5,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 3: `suspicious_short_classes` at line 44

Severity: `serious`
Symbol: `Int`
Message: Class Int is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  42: 
  43: @dataclass(frozen=True)
> 44: class Int:
  45:     """Integer node (booleans are not integers)."""
  46: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 4: `suspicious_short_classes` at line 52

Severity: `serious`
Symbol: `Num`
Message: Class Num is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  50: 
  51: @dataclass(frozen=True)
> 52: class Num:
  53:     """Finite number node (integer or decimal)."""
  54: 
```
Details:
```json
{
  "line_count": 3,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 5: `missing_docstrings` at line 61

Severity: `minor`
Symbol: `Bool`
Message: Class Bool is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  59: 
  60: @dataclass(frozen=True)
> 61: class Bool:
  62:     """Boolean node."""
  63: 
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 6: `suspicious_short_classes` at line 61

Severity: `serious`
Symbol: `Bool`
Message: Class Bool is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  59: 
  60: @dataclass(frozen=True)
> 61: class Bool:
  62:     """Boolean node."""
  63: 
```
Details:
```json
{
  "line_count": 1,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 7: `suspicious_short_classes` at line 68

Severity: `serious`
Symbol: `AnyValue`
Message: Class AnyValue is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  66: 
  67: @dataclass(frozen=True)
> 68: class AnyValue:
  69:     """Open JSON-compatible value (extension data, claim values)."""
  70: 
```
Details:
```json
{
  "line_count": 1,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 8: `suspicious_short_classes` at line 75

Severity: `serious`
Symbol: `Arr`
Message: Class Arr is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  73: 
  74: @dataclass(frozen=True)
> 75: class Arr:
  76:     """Array node with an item schema."""
  77: 
```
Details:
```json
{
  "line_count": 4,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 9: `suspicious_short_classes` at line 85

Severity: `serious`
Symbol: `Field`
Message: Class Field is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  83: 
  84: @dataclass(frozen=True)
> 85: class Field:
  86:     """One declared member of an object."""
  87: 
```
Details:
```json
{
  "line_count": 4,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 10: `suspicious_short_functions` at line 102

Severity: `minor`
Symbol: `Obj.get`
Message: Function Obj.get is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  100:     doc: str = ""
  101: 
> 102:     def get(self, key: str) -> Optional[Field]:
  103:         """Return the declared field named ``key``."""
  104:         for f in self.fields:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 11: `suspicious_short_functions` at line 110

Severity: `minor`
Symbol: `Obj.order`
Message: Function Obj.order is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  108: 
  109:     @property
> 110:     def order(self) -> list[str]:
  111:         """Canonical member order."""
  112:         return [f.name for f in self.fields]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 12: `suspicious_short_classes` at line 116

Severity: `serious`
Symbol: `MapOf`
Message: Class MapOf is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  114: 
  115: @dataclass(frozen=True)
> 116: class MapOf:
  117:     """Open-keyed mapping whose keys match a pattern and values share a schema."""
  118: 
```
Details:
```json
{
  "line_count": 3,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 13: `suspicious_short_classes` at line 145

Severity: `serious`
Symbol: `Union_`
Message: Class Union_ is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  143: 
  144: @dataclass(frozen=True)
> 145: class Union_:
  146:     """Either a string or an object (sidecar binding targets)."""
  147: 
```
Details:
```json
{
  "line_count": 2,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 14: `suspicious_short_functions` at line 155

Severity: `minor`
Symbol: `F`
Message: Function F is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  153: 
  154: 
> 155: def F(name: str, node: Node, required: bool = False, doc: str = "") -> Field:
  156:     """Shorthand constructor for ``Field``."""
  157:     return Field(name, node, required, doc)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 15: `suspicious_short_functions` at line 160

Severity: `minor`
Symbol: `enum`
Message: Function enum is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  158: 
  159: 
> 160: def enum(values: Sequence[str], doc: str = "") -> Str:
  161:     """Shorthand for a vocabulary-constrained string."""
  162:     return Str(enum=tuple(values), doc=doc)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 16: `type_hint_gaps` at line 542

Severity: `minor`
Symbol: `make_order`
Message: Function make_order has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  540: 
  541: 
> 542: def make_order(payload: Optional[dict] = None):
  543:     """Build the serializer ``order`` callback, aware of declared profiles."""
  544:     profiles: dict[str, str] = {}
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 17: `missing_docstrings` at line 551

Severity: `minor`
Symbol: `make_order.order`
Message: Function make_order.order is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  549:                 profiles[decl["key"]] = decl["schema"]
  550: 
> 551:     def order(path: tuple) -> Optional[list[str]]:
  552:         node = node_at(path, profiles)
  553:         if isinstance(node, Union_):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 18: `complexity` at line 562

Severity: `minor`
Symbol: `describe`
Message: Function describe has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  560: 
  561: 
> 562: def describe(node: Any) -> str:
  563:     """Return a short human type description of a node."""
  564:     if isinstance(node, Str):
```
Details:
```json
{
  "complexity": 23,
  "maximum": 12
}
```

### `somnus/model/validate.py`

| Metric | Value |
|---|---:|
| Lines | 832 |
| Code lines | 734 |
| Classes | 3 |
| Functions | 17 |
| Imports | 16 |
| Local dependencies | 8 |
| Missing imports | 0 |
| Max complexity | 106 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Multi-stage validation pipeline: carrier, core, semantic, canon (SPEC Â§19)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import ast
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 51

Severity: `minor`
Symbol: `Resolver.add_payload`
Message: Function Resolver.add_payload has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  49:     open_conflicts: dict = field(default_factory=dict)  # artifact id -> list of conflict kinds
  50: 
> 51:     def add_payload(self, somnus: dict) -> None:
  52:         """Register facts from a parsed payload (check-set member)."""
  53:         aid = somnus.get("id")
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 81

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  79:     try:
  80:         return datetime.fromisoformat(value.replace("Z", "+00:00"))
> 81:     except ValueError:
  82:         return None
  83: 
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `missing_docstrings` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 5: `suspicious_short_functions` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 6: `type_hint_gaps` at line 92

Severity: `minor`
Symbol: `_Run.__init__`
Message: Function _Run.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  90:     """Accumulates diagnostics for one document."""
  91: 
> 92:     def __init__(self, doc: Document):
  93:         self.doc = doc
  94:         self.out: list[Diagnostic] = []
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 7: `missing_docstrings` at line 96

Severity: `minor`
Symbol: `_Run.err`
Message: Function _Run.err is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  94:         self.out: list[Diagnostic] = []
  95: 
> 96:     def err(self, path: tuple, code: str, message: str) -> None:
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 96

Severity: `minor`
Symbol: `_Run.err`
Message: Function _Run.err is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  94:         self.out: list[Diagnostic] = []
  95: 
> 96:     def err(self, path: tuple, code: str, message: str) -> None:
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `missing_docstrings` at line 99

Severity: `minor`
Symbol: `_Run.warn`
Message: Function _Run.warn is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
> 99:     def warn(self, path: tuple, code: str, message: str) -> None:
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `suspicious_short_functions` at line 99

Severity: `minor`
Symbol: `_Run.warn`
Message: Function _Run.warn is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  97:         self.out.append(self.doc.diag(path, code, message))
  98: 
> 99:     def warn(self, path: tuple, code: str, message: str) -> None:
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 11: `missing_docstrings` at line 102

Severity: `minor`
Symbol: `_Run.at`
Message: Function _Run.at is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
> 102:     def at(self, line: int, col: int, code: str, message: str, severity: str = "error") -> None:
  103:         self.out.append(Diagnostic(self.doc.display, line, col, severity, code, "-", message))
  104: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 12: `suspicious_short_functions` at line 102

Severity: `minor`
Symbol: `_Run.at`
Message: Function _Run.at is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  100:         self.out.append(self.doc.diag(path, code, message, severity="warning"))
  101: 
> 102:     def at(self, line: int, col: int, code: str, message: str, severity: str = "error") -> None:
  103:         self.out.append(Diagnostic(self.doc.display, line, col, severity, code, "-", message))
  104: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 13: `complexity` at line 109

Severity: `minor`
Symbol: `walk`
Message: Function walk has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  107: 
  108: 
> 109: def walk(run: _Run, node: Any, value: Any, path: tuple) -> None:
  110:     """Check ``value`` against a schema node, recording E_SCHEMA findings."""
  111:     if isinstance(node, S.Str):
```
Details:
```json
{
  "complexity": 54,
  "maximum": 12
}
```

#### Issue 14: `silent_failures` at line 130

Severity: `serious`
Symbol: `walk`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  128:                 try:
  129:                     date.fromisoformat(value)
> 130:                 except ValueError:
  131:                     ok = False
  132:             if not ok:
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 15: `complexity` at line 278

Severity: `minor`
Symbol: `consistency`
Message: Function consistency has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  276: 
  277: 
> 278: def consistency(run: _Run, somnus: dict) -> None:
  279:     """Intra-document conditional requirements (core level)."""
  280:     P = ("somnus",)
```
Details:
```json
{
  "complexity": 106,
  "maximum": 12
}
```

#### Issue 16: `missing_docstrings` at line 438

Severity: `minor`
Symbol: `find_cycle.visit`
Message: Function find_cycle.visit is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  436:     stack: list[str] = []
  437: 
> 438:     def visit(node: str) -> Optional[list[str]]:
  439:         color[node] = GREY
  440:         stack.append(node)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 17: `complexity` at line 500

Severity: `minor`
Symbol: `marker_regions`
Message: Function marker_regions has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  498: 
  499: 
> 500: def marker_regions(run: _Run, somnus: dict) -> Optional[MarkerScan]:
  501:     """Pair body markers and match them against marker-selector regions."""
  502:     doc = run.doc
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 18: `complexity` at line 563

Severity: `minor`
Symbol: `references`
Message: Function references has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  561: 
  562: 
> 563: def references(run: _Run, somnus: dict, resolver: Resolver) -> None:
  564:     """Resolve every reference against this document, the check set, and the registry."""
  565:     found: list = []
```
Details:
```json
{
  "complexity": 42,
  "maximum": 12
}
```

#### Issue 19: `silent_failures` at line 592

Severity: `serious`
Symbol: `references`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  590:         try:
  591:             kind, _ = ids.parse_urn(ref)
> 592:         except ValueError:
  593:             run.err(path, "E_REFERENCE", f"{ref!r} is not resolvable")
  594:             continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 20: `complexity` at line 618

Severity: `minor`
Symbol: `selectors`
Message: Function selectors has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  616: 
  617: 
> 618: def selectors(run: _Run, somnus: dict) -> None:
  619:     """Resolve non-marker region selectors."""
  620:     doc = run.doc
```
Details:
```json
{
  "complexity": 36,
  "maximum": 12
}
```

#### Issue 21: `silent_failures` at line 652

Severity: `serious`
Symbol: `selectors`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  650:             try:
  651:                 tree = ast.parse("\n".join(doc.body_lines()) + "\n")
> 652:             except SyntaxError as exc:
  653:                 run.err(sp, "E_REGION", f"cannot parse Python source: {exc.msg}")
  654:                 continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 22: `silent_failures` at line 667

Severity: `serious`
Symbol: `selectors`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  665:             try:
  666:                 tree = json.loads(target.read_text(encoding="utf-8"))
> 667:             except (OSError, ValueError) as exc:
  668:                 run.err(sp, "E_REGION", f"primary target is not readable JSON: {exc}")
  669:                 continue
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 23: `complexity` at line 691

Severity: `minor`
Symbol: `semantic_policies`
Message: Function semantic_policies has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  689: 
  690: 
> 691: def semantic_policies(run: _Run, somnus: dict) -> None:
  692:     """Resources, constraint languages, and required capabilities."""
  693:     P = ("somnus",)
```
Details:
```json
{
  "complexity": 22,
  "maximum": 12
}
```

#### Issue 24: `complexity` at line 760

Severity: `minor`
Symbol: `validate`
Message: Function validate has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  758: 
  759: 
> 760: def validate(doc: Document, level: str = "core", resolver: Optional[Resolver] = None) -> list[Diagnostic]:
  761:     """Run the pipeline up to ``level``; later stages run only when earlier ones pass."""
  762:     if level not in LEVEL_RANK:
```
Details:
```json
{
  "complexity": 23,
  "maximum": 12
}
```

#### Issue 25: `complexity` at line 815

Severity: `minor`
Symbol: `permits_use`
Message: Function permits_use has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  813: 
  814: 
> 815: def permits_use(somnus: dict, use: str, region_id: Optional[str] = None) -> bool:
  816:     """Header-level usage decision (external policy may be stricter)."""
  817:     access = somnus.get("access") if isinstance(somnus.get("access"), dict) else {}
```
Details:
```json
{
  "complexity": 16,
  "maximum": 12
}
```

### `somnus/model/vocab.py`

| Metric | Value |
|---|---:|
| Lines | 75 |
| Code lines | 68 |
| Classes | 0 |
| Functions | 0 |
| Imports | 1 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Controlled vocabularies of core schema 2.0.0 (SPEC Â§5, Â§7â€“Â§15)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: CATEGORIES = ("research", "engineering", "operations", "governance", "context", "archive")
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

### `somnus/output.py`

| Metric | Value |
|---|---:|
| Lines | 92 |
| Code lines | 69 |
| Classes | 2 |
| Functions | 8 |
| Imports | 4 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 15 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Diagnostics, compiler-style rendering, tables, and process exit codes."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import sys
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 29

Severity: `minor`
Symbol: `Diagnostic.is_error`
Message: Function Diagnostic.is_error is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  27: 
  28:     @property
> 29:     def is_error(self) -> bool:
  30:         """Return True when the diagnostic is an error rather than a warning."""
  31:         return self.severity == "error"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `missing_docstrings` at line 37

Severity: `minor`
Symbol: `SomnusError.__init__`
Message: Function SomnusError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  35:     """Operation refused; carries diagnostics and the exit code to return."""
  36: 
> 37:     def __init__(self, diagnostics: Sequence[Diagnostic] | str, exit_code: int = EXIT_INVALID):
  38:         if isinstance(diagnostics, str):
  39:             diagnostics = [Diagnostic("-", 0, 0, "error", "E_IO", "-", diagnostics)]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 4: `type_hint_gaps` at line 37

Severity: `minor`
Symbol: `SomnusError.__init__`
Message: Function SomnusError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  35:     """Operation refused; carries diagnostics and the exit code to return."""
  36: 
> 37:     def __init__(self, diagnostics: Sequence[Diagnostic] | str, exit_code: int = EXIT_INVALID):
  38:         if isinstance(diagnostics, str):
  39:             diagnostics = [Diagnostic("-", 0, 0, "error", "E_IO", "-", diagnostics)]
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `suspicious_short_functions` at line 58

Severity: `minor`
Symbol: `render`
Message: Function render is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  56: 
  57: 
> 58: def render(diagnostics: Iterable[Diagnostic], fmt: Literal["text", "tsv"] = "text") -> str:
  59:     """Render diagnostics sorted by path, line, column; one per line."""
  60:     ordered = sorted(diagnostics, key=lambda d: (d.path, d.line, d.col, d.code, d.field))
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 64

Severity: `minor`
Symbol: `has_errors`
Message: Function has_errors is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  62: 
  63: 
> 64: def has_errors(diagnostics: Iterable[Diagnostic]) -> bool:
  65:     """Return True when any diagnostic is an error."""
  66:     return any(d.is_error for d in diagnostics)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `complexity` at line 69

Severity: `minor`
Symbol: `table`
Message: Function table has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  67: 
  68: 
> 69: def table(headers: Sequence[str], rows: Sequence[Sequence[object]], fmt: Literal["text", "tsv"] = "text",
  70:           max_width: int = 60) -> str:
  71:     """Format rows as an aligned plain-text table or header-first TSV."""
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 8: `missing_docstrings` at line 80

Severity: `minor`
Symbol: `table.line`
Message: Function table.line is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  78:         for i, c in enumerate(r):
  79:             widths[i] = max(widths[i], len(c))
> 80:     def line(values: Sequence[str]) -> str:
  81:         return "  ".join(v.ljust(widths[i]) for i, v in enumerate(values)).rstrip()
  82:     out = [line(headers), line(["-" * w for w in widths])]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 9: `suspicious_short_functions` at line 80

Severity: `minor`
Symbol: `table.line`
Message: Function table.line is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  78:         for i, c in enumerate(r):
  79:             widths[i] = max(widths[i], len(c))
> 80:     def line(values: Sequence[str]) -> str:
  81:         return "  ".join(v.ljust(widths[i]) for i, v in enumerate(values)).rstrip()
  82:     out = [line(headers), line(["-" * w for w in widths])]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 87

Severity: `minor`
Symbol: `emit`
Message: Function emit is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  85: 
  86: 
> 87: def emit(text: str, stream=None) -> None:
  88:     """Write text plus newline to stdout (or stream), skipping empty output."""
  89:     if not text:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 11: `type_hint_gaps` at line 87

Severity: `minor`
Symbol: `emit`
Message: Function emit has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  85: 
  86: 
> 87: def emit(text: str, stream=None) -> None:
  88:     """Write text plus newline to stdout (or stream), skipping empty output."""
  89:     if not text:
```
Details:
```json
{
  "missing_hints": [
    "param:stream"
  ]
}
```

### `somnus/regions.py`

| Metric | Value |
|---|---:|
| Lines | 210 |
| Code lines | 184 |
| Classes | 2 |
| Functions | 5 |
| Imports | 7 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 28 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """In-body region markers: lexical scanning, pairing, and registry sync (SPEC Â§13)."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import io
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `complexity` at line 37

Severity: `minor`
Symbol: `markdown_code_mask`
Message: Function markdown_code_mask has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  35: 
  36: 
> 37: def markdown_code_mask(lines: Sequence[str]) -> list[bool]:
  38:     """Mark lines inside fenced code (fences included) and indented code blocks."""
  39:     mask = [False] * len(lines)
```
Details:
```json
{
  "complexity": 17,
  "maximum": 12
}
```

#### Issue 3: `silent_failures` at line 81

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  79:                 if not lines[row - 1][:col].strip():
  80:                     eligible.add(row - 1)
> 81:     except (tokenize.TokenError, IndentationError, SyntaxError):
  82:         return None
  83:     return eligible
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 4: `complexity` at line 103

Severity: `minor`
Symbol: `scan_markers`
Message: Function scan_markers has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  101: 
  102: 
> 103: def scan_markers(lines: Sequence[str], style: tuple, ignore: tuple[int, int] = (-1, -1),
  104:                  host: Optional[str] = None) -> MarkerScan:
  105:     """Scan live region markers, pairing them with a stack.
```
Details:
```json
{
  "complexity": 28,
  "maximum": 12
}
```

#### Issue 5: `complexity` at line 190

Severity: `minor`
Symbol: `sync_registry`
Message: Function sync_registry has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  188: 
  189: 
> 190: def sync_registry(somnus: dict, scan: MarkerScan) -> tuple[list[str], list[str]]:
  191:     """Register unregistered marker ranges; return (added ids, registered-but-missing ids).
  192: 
```
Details:
```json
{
  "complexity": 13,
  "maximum": 12
}
```

### `somnus/tui/__init__.py`

| Metric | Value |
|---|---:|
| Lines | 1 |
| Code lines | 1 |
| Classes | 0 |
| Functions | 0 |
| Imports | 0 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 0 |

No issues detected in this file.

### `somnus/tui/app.py`

| Metric | Value |
|---|---:|
| Lines | 365 |
| Code lines | 317 |
| Classes | 2 |
| Functions | 20 |
| Imports | 15 |
| Local dependencies | 7 |
| Missing imports | 0 |
| Max complexity | 11 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Full-screen document browser and header editor behind ``somnus edit``."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 27

Severity: `minor`
Symbol: `first_message`
Message: Function first_message is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  25: 
  26: 
> 27: def first_message(exc: SomnusError) -> str:
  28:     """First diagnostic of ``exc`` as one line."""
  29:     if not exc.diagnostics:
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 58

Severity: `minor`
Symbol: `render_row`
Message: Function render_row is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  56: 
  57: 
> 58: def render_row(row: Sequence[Any]) -> str:
  59:     """List label for a registry row."""
  60:     title = row[1] or "(untitled)"
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 64

Severity: `minor`
Symbol: `match_row`
Message: Function match_row is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  62: 
  63: 
> 64: def match_row(row: Sequence[Any]) -> str:
  65:     """Text a registry row is filtered on (every column)."""
  66:     return " ".join("" if v is None else str(v) for v in row)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `missing_docstrings` at line 89

Severity: `minor`
Symbol: `EditorScreen.__init__`
Message: Function EditorScreen.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  87:     """Header editor for one loaded document."""
  88: 
> 89:     def __init__(self, ctx: Ctx, screen: Terminal, doc: Any) -> None:
  90:         self.ctx = ctx
  91:         self.screen = screen
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 6: `silent_failures` at line 108

Severity: `serious`
Symbol: `EditorScreen.run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  106:             try:
  107:                 key = self.screen.read_key()
> 108:             except EOFError:
  109:                 return
  110:             if not self.handle(key):
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 7: `silent_failures` at line 169

Severity: `serious`
Symbol: `EditorScreen`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  167:         try:
  168:             self.form.apply(self.overlay_field, overlay.value)
> 169:         except ValueError as exc:
  170:             self.message = str(exc)
  171:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 8: `silent_failures` at line 190

Severity: `serious`
Symbol: `EditorScreen.save`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  188:         try:
  189:             commit(self.doc, payload)
> 190:         except SomnusError as exc:
  191:             self.message = f"not saved: {first_message(exc)}"
  192:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 9: `silent_failures` at line 193

Severity: `serious`
Symbol: `EditorScreen.save`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  191:             self.message = f"not saved: {first_message(exc)}"
  192:             return
> 193:         except OSError as exc:
  194:             self.message = f"not saved: {exc}"
  195:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 10: `silent_failures` at line 200

Severity: `serious`
Symbol: `EditorScreen.save`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  198:             self.ctx.record("edit", self.doc.path, payload["id"], payload["revision"],
  199:                             "header edited in TUI", resolve=("revision",))
> 200:         except SomnusError as exc:
  201:             note += f"; registry not updated: {first_message(exc)}"
  202:         self.screen.invalidate()
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 11: `security_risks` at line 213

Severity: `serious`
Symbol: `EditorScreen.edit_body`
Message: High-risk call detected: subprocess.call.
Remediation: Replace dynamic execution or shell invocation with typed APIs and constrained inputs.

Evidence:
```text
  211:         try:
  212:             with self.screen.suspended():
> 213:                 code = subprocess.call(argv)
  214:         except TerminalError:
  215:             raise
```
Details:
```json
{
  "call": "subprocess.call"
}
```

#### Issue 12: `silent_failures` at line 216

Severity: `serious`
Symbol: `EditorScreen.edit_body`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  214:         except TerminalError:
  215:             raise
> 216:         except OSError as exc:
  217:             self.message = f"cannot run {argv[0]}: {exc}"
  218:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 13: `silent_failures` at line 225

Severity: `serious`
Symbol: `EditorScreen.reload`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  223:         try:
  224:             doc = load_valid(self.doc.path)
> 225:         except SomnusError as exc:
  226:             self.stale = True
  227:             self.message = f"reload failed: {first_message(exc)}"
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 14: `silent_failures` at line 229

Severity: `serious`
Symbol: `EditorScreen.reload`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  227:             self.message = f"reload failed: {first_message(exc)}"
  228:             return
> 229:         except OSError as exc:
  230:             self.stale = True
  231:             self.message = f"reload failed: {exc}"
```
Details:
```json
{
  "handler_body_length": 3
}
```

#### Issue 15: `missing_docstrings` at line 283

Severity: `minor`
Symbol: `BrowserScreen.__init__`
Message: Function BrowserScreen.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  281:     """Filterable registry list with a detail pane; enter opens the header editor."""
  282: 
> 283:     def __init__(self, ctx: Ctx, screen: Terminal, rows: Sequence[tuple]) -> None:
  284:         self.ctx = ctx
  285:         self.screen = screen
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 16: `suspicious_short_functions` at line 283

Severity: `minor`
Symbol: `BrowserScreen.__init__`
Message: Function BrowserScreen.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  281:     """Filterable registry list with a detail pane; enter opens the header editor."""
  282: 
> 283:     def __init__(self, ctx: Ctx, screen: Terminal, rows: Sequence[tuple]) -> None:
  284:         self.ctx = ctx
  285:         self.screen = screen
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 17: `silent_failures` at line 295

Severity: `serious`
Symbol: `BrowserScreen.run`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  293:             try:
  294:                 key = self.screen.read_key()
> 295:             except EOFError:
  296:                 return
  297:             if not self.handle(key):
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 18: `silent_failures` at line 316

Severity: `serious`
Symbol: `BrowserScreen.reload`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  314:         try:
  315:             rows = load_rows(self.ctx)
> 316:         except SomnusError as exc:
  317:             self.message = f"reload failed: {first_message(exc)}"
  318:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 19: `silent_failures` at line 329

Severity: `serious`
Symbol: `BrowserScreen.open_selected`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  327:         try:
  328:             doc = load_valid(Path(row[6]))
> 329:         except SomnusError as exc:
  330:             self.message = f"cannot edit {row[6]}: {first_message(exc)}"
  331:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

#### Issue 20: `silent_failures` at line 332

Severity: `serious`
Symbol: `BrowserScreen.open_selected`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  330:             self.message = f"cannot edit {row[6]}: {first_message(exc)}"
  331:             return
> 332:         except OSError as exc:
  333:             self.message = f"cannot edit {row[6]}: {exc}"
  334:             return
```
Details:
```json
{
  "handler_body_length": 2
}
```

### `somnus/tui/form.py`

| Metric | Value |
|---|---:|
| Lines | 162 |
| Code lines | 130 |
| Classes | 2 |
| Functions | 14 |
| Imports | 7 |
| Local dependencies | 3 |
| Missing imports | 0 |
| Max complexity | 8 |

#### Issue 1: `unused_imports` at line 3

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  1: """Header form model: editable field definitions, payload edits, validation, dirty tracking."""
  2: 
> 3: from __future__ import annotations
  4: 
  5: import copy
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_classes` at line 15

Severity: `serious`
Symbol: `Field`
Message: Class Field is suspiciously short.
Remediation: Verify the class has real responsibility, merge it into its owner, or expand the contract with production behavior.

Evidence:
```text
  13: 
  14: @dataclass(frozen=True)
> 15: class Field:
  16:     """One editable header field; ``kind`` is ``text``, ``optional``, ``choice``, or ``tags``."""
  17: 
```
Details:
```json
{
  "line_count": 4,
  "method_count": 0,
  "public_method_count": 0
}
```

#### Issue 3: `suspicious_short_functions` at line 81

Severity: `minor`
Symbol: `remove_path`
Message: Function remove_path is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  79: 
  80: 
> 81: def remove_path(payload: dict, path: str) -> None:
  82:     """Delete dotted ``path`` when present."""
  83:     *parents, leaf = path.split(".")
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 4: `missing_docstrings` at line 103

Severity: `minor`
Symbol: `FormModel.__init__`
Message: Function FormModel.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  101:     """Working copy of a payload with field-level edits and live validation."""
  102: 
> 103:     def __init__(self, payload: dict,
  104:                  validator: Callable[[dict], Sequence[Diagnostic]] = validate_payload) -> None:
  105:         self.original = copy.deepcopy(payload)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 5: `suspicious_short_functions` at line 112

Severity: `minor`
Symbol: `FormModel.dirty`
Message: Function FormModel.dirty is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  110: 
  111:     @property
> 112:     def dirty(self) -> bool:
  113:         """True when the working payload differs from the loaded one."""
  114:         return self.payload != self.original
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 116

Severity: `minor`
Symbol: `FormModel.value`
Message: Function FormModel.value is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  114:         return self.payload != self.original
  115: 
> 116:     def value(self, path: str) -> Any:
  117:         """Current value at dotted ``path`` (None when absent)."""
  118:         return get_path(self.payload, path)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `suspicious_short_functions` at line 120

Severity: `minor`
Symbol: `FormModel.text`
Message: Function FormModel.text is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  118:         return get_path(self.payload, path)
  119: 
> 120:     def text(self, field: Field) -> str:
  121:         """Current value of ``field`` as editable text."""
  122:         return format_value(self.value(field.path))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 8: `suspicious_short_functions` at line 124

Severity: `minor`
Symbol: `FormModel.readonly_rows`
Message: Function FormModel.readonly_rows is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  122:         return format_value(self.value(field.path))
  123: 
> 124:     def readonly_rows(self) -> list[tuple[str, str]]:
  125:         """``(label, text)`` for fields shown but never edited here."""
  126:         return [(label, format_value(get_path(self.payload, path))) for path, label in READONLY]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 146

Severity: `minor`
Symbol: `FormModel.revert`
Message: Function FormModel.revert is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  144:         self.revalidate()
  145: 
> 146:     def revert(self) -> None:
  147:         """Discard every edit."""
  148:         self.payload = copy.deepcopy(self.original)
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 151

Severity: `minor`
Symbol: `FormModel.revalidate`
Message: Function FormModel.revalidate is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  149:         self.revalidate()
  150: 
> 151:     def revalidate(self) -> None:
  152:         """Recompute ``errors`` from the validator."""
  153:         self.errors = [d for d in self._validator(self.payload) if d.is_error]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

### `somnus/tui/term.py`

| Metric | Value |
|---|---:|
| Lines | 289 |
| Code lines | 223 |
| Classes | 4 |
| Functions | 20 |
| Imports | 14 |
| Local dependencies | 1 |
| Missing imports | 0 |
| Max complexity | 6 |

#### Issue 1: `unused_imports` at line 8

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  6: """
  7: 
> 8: from __future__ import annotations
  9: 
  10: import codecs
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 53

Severity: `minor`
Symbol: `decode_char`
Message: Function decode_char is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  51: 
  52: 
> 53: def decode_char(ch: str) -> str:
  54:     """Normalize one non-prefixed input character to a key name (or the character itself)."""
  55:     return _PLAIN.get(ch, ch)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 58

Severity: `minor`
Symbol: `decode_windows_special`
Message: Function decode_windows_special is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  56: 
  57: 
> 58: def decode_windows_special(second: str) -> str:
  59:     """Key name for the character following a ``\\x00``/``\\xe0`` prefix; "" when unknown."""
  60:     return _WINDOWS_SPECIAL.get(second, "")
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 73

Severity: `minor`
Symbol: `is_sequence_final`
Message: Function is_sequence_final is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  71: 
  72: 
> 73: def is_sequence_final(ch: str) -> bool:
  74:     """True for a CSI/SS3 final byte (``@`` through ``~``)."""
  75:     return "\x40" <= ch <= "\x7e"
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 78

Severity: `minor`
Symbol: `frame_updates`
Message: Function frame_updates is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  76: 
  77: 
> 78: def frame_updates(prev: Sequence[str], lines: Sequence[str], cols: int,
  79:                   rows: int) -> tuple[list[str], list[tuple[int, str]]]:
  80:     """Normalize ``lines`` into a full frame and list the ``(row, text)`` pairs that changed.
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 91

Severity: `minor`
Symbol: `usable_width`
Message: Function usable_width is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  89: 
  90: 
> 91: def usable_width(cols: int) -> int:
  92:     """Width that callers should render to, matching ``frame_updates`` clipping."""
  93:     return max(1, cols - 1)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `missing_docstrings` at line 102

Severity: `minor`
Symbol: `_WindowsConsole.__init__`
Message: Function _WindowsConsole.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  100:     """Saves console modes, enables VT output, and restores the saved modes."""
  101: 
> 102:     def __init__(self) -> None:
  103:         import ctypes
  104:         from ctypes import wintypes
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 138

Severity: `minor`
Symbol: `_WindowsConsole.restore`
Message: Function _WindowsConsole.restore is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  136:             raise TerminalError("console does not support virtual terminal sequences")
  137: 
> 138:     def restore(self) -> None:
  139:         """Put back every recorded console mode."""
  140:         while self._saved:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 9: `missing_docstrings` at line 148

Severity: `minor`
Symbol: `_PosixTty.__init__`
Message: Function _PosixTty.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  146:     """Saves termios attributes of stdin, enters raw mode, and restores them."""
  147: 
> 148:     def __init__(self, fd: int) -> None:
  149:         self.fd = fd
  150:         self._saved: Optional[list] = None
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `suspicious_short_functions` at line 148

Severity: `minor`
Symbol: `_PosixTty.__init__`
Message: Function _PosixTty.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  146:     """Saves termios attributes of stdin, enters raw mode, and restores them."""
  147: 
> 148:     def __init__(self, fd: int) -> None:
  149:         self.fd = fd
  150:         self._saved: Optional[list] = None
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 11: `suspicious_short_functions` at line 160

Severity: `minor`
Symbol: `_PosixTty.restore`
Message: Function _PosixTty.restore is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  158:             raise TerminalError(f"cannot enter raw mode: {exc}") from exc
  159: 
> 160:     def restore(self) -> None:
  161:         """Restore the recorded attributes (no-op when none were recorded)."""
  162:         saved, self._saved = self._saved, None
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 12: `missing_docstrings` at line 177

Severity: `minor`
Symbol: `Terminal.__init__`
Message: Function Terminal.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  175:     """
  176: 
> 177:     def __init__(self, stream: Optional[TextIO] = None) -> None:
  178:         self._out = stream or sys.stdout
  179:         self._prev: list[str] = []
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 13: `missing_docstrings` at line 185

Severity: `minor`
Symbol: `Terminal.__enter__`
Message: Function Terminal.__enter__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  183: 
  184:     # ------------------------------------------------------------- lifecycle
> 185:     def __enter__(self) -> "Terminal":
  186:         self._enter()
  187:         return self
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 14: `suspicious_short_functions` at line 185

Severity: `minor`
Symbol: `Terminal.__enter__`
Message: Function Terminal.__enter__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  183: 
  184:     # ------------------------------------------------------------- lifecycle
> 185:     def __enter__(self) -> "Terminal":
  186:         self._enter()
  187:         return self
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 15: `missing_docstrings` at line 189

Severity: `minor`
Symbol: `Terminal.__exit__`
Message: Function Terminal.__exit__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  187:         return self
  188: 
> 189:     def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
  190:         self._leave()
  191: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 16: `suspicious_short_functions` at line 189

Severity: `minor`
Symbol: `Terminal.__exit__`
Message: Function Terminal.__exit__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  187:         return self
  188: 
> 189:     def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
  190:         self._leave()
  191: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 17: `broad_exceptions` at line 198

Severity: `serious`
Symbol: `Terminal`
Message: Broad exception handler catches BaseException.
Remediation: Catch specific domain exceptions or convert known library exceptions at the boundary.

Evidence:
```text
  196:             modes.enable()
  197:             self._write(ENTER_SCREEN)
> 198:         except BaseException:
  199:             self._leave()
  200:             raise
```
Details:
```json
{
  "handler": "BaseException"
}
```

#### Issue 18: `suspicious_short_functions` at line 225

Severity: `minor`
Symbol: `Terminal.size`
Message: Function Terminal.size is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  223:         self._out.flush()
  224: 
> 225:     def size(self) -> tuple[int, int]:
  226:         """Current ``(columns, rows)``."""
  227:         cols, rows = shutil.get_terminal_size()
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 19: `suspicious_short_functions` at line 230

Severity: `minor`
Symbol: `Terminal.invalidate`
Message: Function Terminal.invalidate is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  228:         return cols, rows
  229: 
> 230:     def invalidate(self) -> None:
  231:         """Forget the previous frame so the next ``draw`` repaints everything."""
  232:         self._prev = []
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 20: `suspicious_short_functions` at line 248

Severity: `minor`
Symbol: `Terminal.read_key`
Message: Function Terminal.read_key is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  246: 
  247:     # ------------------------------------------------------------- input
> 248:     def read_key(self) -> str:
  249:         """Block for one key and return its normalized name ("" for unrecognized sequences)."""
  250:         if os.name == "nt":
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

### `somnus/tui/widgets.py`

| Metric | Value |
|---|---:|
| Lines | 350 |
| Code lines | 293 |
| Classes | 3 |
| Functions | 20 |
| Imports | 4 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 12 |

#### Issue 1: `unused_imports` at line 7

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  5: """
  6: 
> 7: from __future__ import annotations
  8: 
  9: import re
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `suspicious_short_functions` at line 20

Severity: `minor`
Symbol: `char_width`
Message: Function char_width is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  18: 
  19: 
> 20: def char_width(ch: str) -> int:
  21:     """Terminal cells occupied by one character (0 for combining marks, 2 for wide CJK)."""
  22:     if unicodedata.combining(ch):
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 3: `suspicious_short_functions` at line 27

Severity: `minor`
Symbol: `strip_styles`
Message: Function strip_styles is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  25: 
  26: 
> 27: def strip_styles(text: str) -> str:
  28:     """Remove SGR style sequences."""
  29:     return _SGR.sub("", text)
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 4: `suspicious_short_functions` at line 32

Severity: `minor`
Symbol: `visible_width`
Message: Function visible_width is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  30: 
  31: 
> 32: def visible_width(text: str) -> int:
  33:     """Visible cell width of ``text``, ignoring SGR sequences."""
  34:     return sum(char_width(ch) for ch in strip_styles(text))
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 5: `suspicious_short_functions` at line 71

Severity: `minor`
Symbol: `highlight`
Message: Function highlight is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  69: 
  70: 
> 71: def highlight(text: str, width: int) -> str:
  72:     """Render ``text`` as a full-width reverse-video row."""
  73:     return REVERSE + fit(text, width) + RESET
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 6: `suspicious_short_functions` at line 104

Severity: `minor`
Symbol: `is_text_key`
Message: Function is_text_key is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  102: 
  103: 
> 104: def is_text_key(key: str) -> bool:
  105:     """True when ``key`` is a single printable character."""
  106:     return len(key) == 1 and key.isprintable()
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 7: `missing_docstrings` at line 118

Severity: `minor`
Symbol: `ListView.__init__`
Message: Function ListView.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  116:     """
  117: 
> 118:     def __init__(self, items: Sequence[Any], render_item: Callable[[Any], str] = str,
  119:                  match_text: Optional[Callable[[Any], str]] = None) -> None:
  120:         self.items: list[Any] = list(items)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `suspicious_short_functions` at line 132

Severity: `minor`
Symbol: `ListView.visible`
Message: Function ListView.visible is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  130:     # ------------------------------------------------------------- state
  131:     @property
> 132:     def visible(self) -> list[Any]:
  133:         """Items that pass the current filter, in order."""
  134:         return [self.items[i] for i in self._visible]
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 9: `suspicious_short_functions` at line 137

Severity: `minor`
Symbol: `ListView.selected`
Message: Function ListView.selected is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  135: 
  136:     @property
> 137:     def selected(self) -> Optional[Any]:
  138:         """The highlighted item, or None when nothing is visible."""
  139:         if not self._visible:
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 10: `suspicious_short_functions` at line 143

Severity: `minor`
Symbol: `ListView.set_items`
Message: Function ListView.set_items is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  141:         return self.items[self._visible[self.index]]
  142: 
> 143:     def set_items(self, items: Sequence[Any]) -> None:
  144:         """Replace the items, keeping the filter and (where possible) the cursor position."""
  145:         self.items = list(items)
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 11: `missing_docstrings` at line 223

Severity: `minor`
Symbol: `Picker.__init__`
Message: Function Picker.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  221:     """
  222: 
> 223:     def __init__(self, title: str, choices: Sequence[str], current: Optional[str] = None) -> None:
  224:         self.title = title
  225:         self.choices = list(choices)
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 12: `missing_docstrings` at line 284

Severity: `minor`
Symbol: `TextInput.__init__`
Message: Function TextInput.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  282:     """Single-line editor. Enter sets ``done``; esc sets ``cancelled`` and ``done``."""
  283: 
> 284:     def __init__(self, label: str, value: str = "") -> None:
  285:         self.label = label
  286:         self.value = value
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 13: `suspicious_short_functions` at line 333

Severity: `minor`
Symbol: `split_widths`
Message: Function split_widths is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  331: 
  332: 
> 333: def split_widths(width: int, ratio: float = 0.5, sep: str = SEP) -> tuple[int, int]:
  334:     """Left and right column widths for ``split``."""
  335:     inner = max(0, width - visible_width(sep))
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

### `somnus/yamlsub.py`

| Metric | Value |
|---|---:|
| Lines | 757 |
| Code lines | 653 |
| Classes | 6 |
| Functions | 30 |
| Imports | 5 |
| Local dependencies | 0 |
| Missing imports | 0 |
| Max complexity | 22 |

#### Issue 1: `unused_imports` at line 13

Severity: `minor`
Symbol: `annotations`
Message: Imported name appears unused: annotations.
Remediation: Remove the import or use it in a visible code path.

Evidence:
```text
  11: """
  12: 
> 13: from __future__ import annotations
  14: 
  15: import math
```
Details:
```json
{
  "module": "__future__",
  "raw": "from __future__ import annotations"
}
```

#### Issue 2: `missing_docstrings` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 3: `suspicious_short_functions` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 4: `type_hint_gaps` at line 34

Severity: `minor`
Symbol: `YAMLError.__init__`
Message: Function YAMLError.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  32:     """Restricted-YAML violation with a 1-based payload line and column."""
  33: 
> 34:     def __init__(self, message: str, line: int, col: int = 1):
  35:         self.message = message
  36:         self.line = line
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 5: `missing_docstrings` at line 59

Severity: `minor`
Symbol: `_Line`
Message: Class _Line is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  57: 
  58: @dataclass
> 59: class _Line:
  60:     no: int  # 1-based payload line number
  61:     indent: int
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 6: `missing_docstrings` at line 206

Severity: `minor`
Symbol: `_Flow`
Message: Class _Flow is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  204: 
  205: 
> 206: class _Flow:
  207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 7: `missing_docstrings` at line 207

Severity: `minor`
Symbol: `_Flow.__init__`
Message: Function _Flow.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  205: 
  206: class _Flow:
> 207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
  209:         self.i = 0
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 8: `type_hint_gaps` at line 207

Severity: `minor`
Symbol: `_Flow.__init__`
Message: Function _Flow.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  205: 
  206: class _Flow:
> 207:     def __init__(self, s: str, line: int, col0: int, lenient: bool, spans: dict, path: Path):
  208:         self.s = s
  209:         self.i = 0
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 9: `missing_docstrings` at line 216

Severity: `minor`
Symbol: `_Flow.err`
Message: Function _Flow.err is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  214:         self.path = path
  215: 
> 216:     def err(self, msg: str) -> YAMLError:
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 10: `suspicious_short_functions` at line 216

Severity: `minor`
Symbol: `_Flow.err`
Message: Function _Flow.err is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  214:         self.path = path
  215: 
> 216:     def err(self, msg: str) -> YAMLError:
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 11: `missing_docstrings` at line 219

Severity: `minor`
Symbol: `_Flow.ws`
Message: Function _Flow.ws is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
> 219:     def ws(self) -> None:
  220:         while self.i < len(self.s) and self.s[self.i] in " \t":
  221:             self.i += 1
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 12: `suspicious_short_functions` at line 219

Severity: `minor`
Symbol: `_Flow.ws`
Message: Function _Flow.ws is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  217:         return YAMLError(msg, self.line, self.col0 + self.i + 1)
  218: 
> 219:     def ws(self) -> None:
  220:         while self.i < len(self.s) and self.s[self.i] in " \t":
  221:             self.i += 1
```
Details:
```json
{
  "line_count": 2,
  "minimum": 5
}
```

#### Issue 13: `missing_docstrings` at line 223

Severity: `minor`
Symbol: `_Flow.value`
Message: Function _Flow.value is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  221:             self.i += 1
  222: 
> 223:     def value(self, path: Path) -> Any:
  224:         self.ws()
  225:         if self.i >= len(self.s):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 14: `missing_docstrings` at line 247

Severity: `minor`
Symbol: `_Flow.seq`
Message: Function _Flow.seq is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  245:         return _plain_scalar(token, self.line, self.col0 + start + 1, self.lenient)
  246: 
> 247:     def seq(self, path: Path) -> list:
  248:         self.i += 1
  249:         items: list = []
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 15: `missing_docstrings` at line 269

Severity: `minor`
Symbol: `_Flow.key`
Message: Function _Flow.key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  267:                 raise self.err("trailing comma in flow sequence")
  268: 
> 269:     def key(self) -> str:
  270:         self.ws()
  271:         if self.i >= len(self.s):
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 16: `missing_docstrings` at line 288

Severity: `minor`
Symbol: `_Flow.mapping`
Message: Function _Flow.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  286:         return token
  287: 
> 288:     def mapping(self, path: Path) -> dict:
  289:         self.i += 1
  290:         result: dict = {}
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 17: `missing_docstrings` at line 326

Severity: `minor`
Symbol: `_Parser`
Message: Class _Parser is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  324: 
  325: 
> 326: class _Parser:
  327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 18: `missing_docstrings` at line 327

Severity: `minor`
Symbol: `_Parser.__init__`
Message: Function _Parser.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  325: 
  326: class _Parser:
> 327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
  329:             text = text[1:]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 19: `type_hint_gaps` at line 327

Severity: `minor`
Symbol: `_Parser.__init__`
Message: Function _Parser.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  325: 
  326: class _Parser:
> 327:     def __init__(self, text: str, lenient: bool):
  328:         if text.startswith("\ufeff"):
  329:             text = text[1:]
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 20: `missing_docstrings` at line 337

Severity: `minor`
Symbol: `_Parser.peek`
Message: Function _Parser.peek is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  335: 
  336:     # -- line access
> 337:     def peek(self) -> Optional[_Line]:
  338:         if self.pending is not None:
  339:             return self.pending
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 21: `missing_docstrings` at line 360

Severity: `minor`
Symbol: `_Parser.take`
Message: Function _Parser.take is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  358:         return None
  359: 
> 360:     def take(self) -> _Line:
  361:         line = self.peek()
  362:         assert line is not None
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 22: `suspicious_short_functions` at line 360

Severity: `minor`
Symbol: `_Parser.take`
Message: Function _Parser.take is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  358:         return None
  359: 
> 360:     def take(self) -> _Line:
  361:         line = self.peek()
  362:         assert line is not None
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 23: `missing_docstrings` at line 367

Severity: `minor`
Symbol: `_Parser.document`
Message: Function _Parser.document is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  365: 
  366:     # -- entry
> 367:     def document(self) -> Any:
  368:         first = self.peek()
  369:         if first is None:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 24: `missing_docstrings` at line 379

Severity: `minor`
Symbol: `_Parser.block`
Message: Function _Parser.block is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  377:         return value
  378: 
> 379:     def block(self, indent: int, path: Path) -> Any:
  380:         line = self.peek()
  381:         assert line is not None
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 25: `missing_docstrings` at line 386

Severity: `minor`
Symbol: `_Parser.mapping`
Message: Function _Parser.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  384:         return self.mapping(line.indent, path)
  385: 
> 386:     def mapping(self, indent: int, path: Path) -> dict:
  387:         result: dict = {}
  388:         while True:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 26: `missing_docstrings` at line 404

Severity: `minor`
Symbol: `_Parser.value_after_key`
Message: Function _Parser.value_after_key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  402:             result[key] = self.value_after_key(line, indent, rest, rest_col, child)
  403: 
> 404:     def value_after_key(self, line: _Line, indent: int, rest: str, rest_col: int, path: Path) -> Any:
  405:         if rest:
  406:             if rest[0] in "|>":
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 27: `complexity` at line 416

Severity: `minor`
Symbol: `_Parser.sequence`
Message: Function _Parser.sequence has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  414:         raise YAMLError("missing value; null is forbidden", line.no, rest_col)
  415: 
> 416:     def sequence(self, indent: int, path: Path) -> list:
  417:         items: list = []
  418:         while True:
```
Details:
```json
{
  "complexity": 15,
  "maximum": 12
}
```

#### Issue 28: `missing_docstrings` at line 416

Severity: `minor`
Symbol: `_Parser.sequence`
Message: Function _Parser.sequence is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  414:         raise YAMLError("missing value; null is forbidden", line.no, rest_col)
  415: 
> 416:     def sequence(self, indent: int, path: Path) -> list:
  417:         items: list = []
  418:         while True:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 29: `missing_docstrings` at line 450

Severity: `minor`
Symbol: `_Parser.split_key`
Message: Function _Parser.split_key is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  448:             items.append(self.inline(rest, line.no, inner_indent + 1, child))
  449: 
> 450:     def split_key(self, line: _Line) -> tuple[str, str, int, int]:
  451:         c = line.content
  452:         key_col = line.indent + 1
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 30: `missing_docstrings` at line 480

Severity: `minor`
Symbol: `_Parser.inline`
Message: Function _Parser.inline is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  478:         return key, rest, key_col, rest_col
  479: 
> 480:     def inline(self, s: str, line_no: int, col: int, path: Path) -> Any:
  481:         self.spans.setdefault(path, (line_no, col))
  482:         ch = s[0]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 31: `complexity` at line 498

Severity: `minor`
Symbol: `_Parser.block_scalar`
Message: Function _Parser.block_scalar has high cyclomatic complexity.
Remediation: Split validation, collection, and rendering paths into named units with typed result objects.

Evidence:
```text
  496:         return _plain_scalar(s, line_no, col, self.lenient)
  497: 
> 498:     def block_scalar(self, header: str, line: _Line, parent_indent: int, col: int) -> str:
  499:         m = re.fullmatch(r"([|>])([-+]?)", header)
  500:         if not m:
```
Details:
```json
{
  "complexity": 22,
  "maximum": 12
}
```

#### Issue 32: `missing_docstrings` at line 498

Severity: `minor`
Symbol: `_Parser.block_scalar`
Message: Function _Parser.block_scalar is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  496:         return _plain_scalar(s, line_no, col, self.lenient)
  497: 
> 498:     def block_scalar(self, header: str, line: _Line, parent_indent: int, col: int) -> str:
  499:         m = re.fullmatch(r"([|>])([-+]?)", header)
  500:         if not m:
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 33: `silent_failures` at line 582

Severity: `serious`
Symbol: `<module>`
Message: Exception handler can suppress failure without actionable diagnostics.
Remediation: Log structured context, raise a domain-specific error, or return a structured failure result.

Evidence:
```text
  580:         reader = _read_double if s[0] == '"' else _read_single
  581:         _, end = reader(s, 0, 0, 0)
> 582:     except YAMLError:
  583:         return False
  584:     return s[end : end + 1] == ":" and (end + 1 == len(s) or s[end + 1] == " ")
```
Details:
```json
{
  "handler_body_length": 1
}
```

#### Issue 34: `suspicious_short_functions` at line 590

Severity: `minor`
Symbol: `parse`
Message: Function parse is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  588: 
  589: 
> 590: def parse(text: str, *, lenient: bool = False) -> Parsed:
  591:     """Parse a restricted-YAML document, returning data and source spans."""
  592:     parser = _Parser(text, lenient)
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

#### Issue 35: `suspicious_short_functions` at line 598

Severity: `minor`
Symbol: `loads`
Message: Function loads is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  596: 
  597: 
> 598: def loads(text: str, *, lenient: bool = False) -> Any:
  599:     """Parse a restricted-YAML document and return its value."""
  600:     return parse(text, lenient=lenient).data
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 36: `missing_docstrings` at line 666

Severity: `minor`
Symbol: `_Dumper`
Message: Class _Dumper is missing a meaningful docstring.
Remediation: Add purpose, origin, and operational contract to the class docstring.

Evidence:
```text
  664: 
  665: 
> 666: class _Dumper:
  667:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  668:         self.order = order
```
Details:
```json
{
  "entity_type": "class"
}
```

#### Issue 37: `missing_docstrings` at line 667

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  665: 
  666: class _Dumper:
> 667:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  668:         self.order = order
  669:         self.forbid = forbid
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 38: `suspicious_short_functions` at line 667

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  665: 
  666: class _Dumper:
> 667:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  668:         self.order = order
  669:         self.forbid = forbid
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 39: `type_hint_gaps` at line 667

Severity: `minor`
Symbol: `_Dumper.__init__`
Message: Function _Dumper.__init__ has incomplete type hints.
Remediation: Add explicit parameter and return type hints.

Evidence:
```text
  665: 
  666: class _Dumper:
> 667:     def __init__(self, order: Optional[OrderFn], forbid: Optional[str], width: int):
  668:         self.order = order
  669:         self.forbid = forbid
```
Details:
```json
{
  "missing_hints": [
    "return"
  ]
}
```

#### Issue 40: `missing_docstrings` at line 672

Severity: `minor`
Symbol: `_Dumper.keys`
Message: Function _Dumper.keys is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  670:         self.width = width
  671: 
> 672:     def keys(self, d: dict, path: tuple) -> list:
  673:         declared = list(self.order(path) or []) if self.order else []
  674:         known = [k for k in declared if k in d]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 41: `suspicious_short_functions` at line 672

Severity: `minor`
Symbol: `_Dumper.keys`
Message: Function _Dumper.keys is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  670:         self.width = width
  671: 
> 672:     def keys(self, d: dict, path: tuple) -> list:
  673:         declared = list(self.order(path) or []) if self.order else []
  674:         known = [k for k in declared if k in d]
```
Details:
```json
{
  "line_count": 3,
  "minimum": 5
}
```

#### Issue 42: `missing_docstrings` at line 677

Severity: `minor`
Symbol: `_Dumper.flow`
Message: Function _Dumper.flow is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  675:         return known + [k for k in d if k not in declared]
  676: 
> 677:     def flow(self, items: list) -> str:
  678:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  679: 
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 43: `suspicious_short_functions` at line 677

Severity: `minor`
Symbol: `_Dumper.flow`
Message: Function _Dumper.flow is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  675:         return known + [k for k in d if k not in declared]
  676: 
> 677:     def flow(self, items: list) -> str:
  678:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  679: 
```
Details:
```json
{
  "line_count": 1,
  "minimum": 5
}
```

#### Issue 44: `missing_docstrings` at line 680

Severity: `minor`
Symbol: `_Dumper.mapping`
Message: Function _Dumper.mapping is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  678:         return "[" + ", ".join(_scalar(v, self.forbid) for v in items) + "]"
  679: 
> 680:     def mapping(self, d: dict, indent: int, path: tuple) -> list[str]:
  681:         lines: list[str] = []
  682:         pad = " " * indent
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 45: `missing_docstrings` at line 698

Severity: `minor`
Symbol: `_Dumper.list_after`
Message: Function _Dumper.list_after is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  696:         return lines
  697: 
> 698:     def list_after(self, head: str, v: list, indent: int, path: tuple) -> list[str]:
  699:         if not v:
  700:             return [head + " []"]
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 46: `missing_docstrings` at line 707

Severity: `minor`
Symbol: `_Dumper.sequence`
Message: Function _Dumper.sequence is missing a meaningful docstring.
Remediation: Add Args and Returns blocks for non-trivial signatures and state side effects for private methods.

Evidence:
```text
  705:         return [head] + self.sequence(v, indent + 2, path)
  706: 
> 707:     def sequence(self, items: list, indent: int, path: tuple) -> list[str]:
  708:         lines: list[str] = []
  709:         pad = " " * indent
```
Details:
```json
{
  "entity_type": "function"
}
```

#### Issue 47: `suspicious_short_functions` at line 733

Severity: `minor`
Symbol: `dumps`
Message: Function dumps is suspiciously short.
Remediation: Confirm this is a real adapter or expand it until the control path is auditable.

Evidence:
```text
  731: 
  732: 
> 733: def dumps(value: dict, *, order: Optional[OrderFn] = None, forbid: Optional[str] = None,
  734:           width: int = 88) -> str:
  735:     """Serialize a mapping in canonical form; output always ends with a newline.
```
Details:
```json
{
  "line_count": 4,
  "minimum": 5
}
```

## Recommended Action Plan

### Serious
- Resolve stubs, placeholder returns, missing imports, suspicious classes, broad handlers, silent failures, test gaps, and dependency cycles before release.

### Minor
- Complete docstrings, type hints, unused import cleanup, duplicate definitions, and complexity reductions.

---

Generated by Python Production Doctor. This tool diagnoses; it does not modify source code.
